-- MySQL dump 10.13  Distrib 8.4.11, for Linux (x86_64)
--
-- Host: localhost    Database: fashion_ecom
-- ------------------------------------------------------
-- Server version	8.4.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cat_category`
--

DROP TABLE IF EXISTS `cat_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_category` (
  `cat_category_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toÃ n cá»¥c cá»§a Danh má»¥c',
  `cat_category_parent_id` char(36) DEFAULT NULL COMMENT 'KhÃ³a ngoáº¡i trá» vá» chÃ­nh báº£ng nÃ y Ä‘á»ƒ táº¡o cáº¥u trÃºc cÃ¢y 3 cáº¥p',
  `cat_category_code` varchar(20) NOT NULL COMMENT 'MÃ£ danh má»¥c dÃ¹ng cho SEO hoáº·c tÃ¬m kiáº¿m nhanh',
  `cat_category_name` varchar(255) NOT NULL COMMENT 'TÃªn danh má»¥c (VÃ­ dá»¥: Ão SÆ¡ Mi Nam)',
  `cat_category_slug` varchar(255) DEFAULT NULL COMMENT 'URL slug SEO',
  `cat_category_description` text COMMENT 'Mo ta danh muc (cho SEO)',
  `cat_category_icon` varchar(255) DEFAULT NULL COMMENT 'Icon SVG path',
  `cat_category_banner` varchar(255) DEFAULT NULL COMMENT 'Banner image path',
  `cat_category_sort` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Thu tu hien thi',
  `cat_category_status` tinyint NOT NULL DEFAULT '1' COMMENT 'Tráº¡ng thÃ¡i: 0: áº¨n, 1: Hiá»ƒn thá»‹',
  PRIMARY KEY (`cat_category_id`),
  UNIQUE KEY `uix_catcategory_catcategorycode` (`cat_category_code`),
  UNIQUE KEY `uix_catcategory_catcategoryslug` (`cat_category_slug`),
  KEY `ix_catcategory_catcategoryparentid` (`cat_category_parent_id`),
  CONSTRAINT `fk_catcategory_parent` FOREIGN KEY (`cat_category_parent_id`) REFERENCES `cat_category` (`cat_category_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Danh má»¥c phÃ¢n loáº¡i sáº£n pháº©m Ä‘a cáº¥p';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_category`
--

LOCK TABLES `cat_category` WRITE;
/*!40000 ALTER TABLE `cat_category` DISABLE KEYS */;
INSERT INTO `cat_category` VALUES ('c0000000-0000-0000-0000-000000000003',NULL,'QUAN-JEANS','Quan Jeans','quan-jeans','Quan jeans nam nu, skinny, slim fit, straight',NULL,NULL,3.0000,1),('dafc5826-a473-11f1-b5ab-6ed8ca3651ef',NULL,'AO-POLO','Ão Polo','ao-polo','Ão polo nam cao cáº¥p nhiá»u kiá»ƒu dÃ¡ng',NULL,NULL,1.0000,1),('dafc5d60-a473-11f1-b5ab-6ed8ca3651ef',NULL,'AO-THUN','Ão Thun','ao-thun','Ão thun nam thá»ƒ thao & lifestyle',NULL,NULL,2.0000,1),('dafc60a8-a473-11f1-b5ab-6ed8ca3651ef',NULL,'QUAN-SHORT','Quáº§n Short','quan-short','Quáº§n short nam Ä‘Å©i, giÃ³, khaki',NULL,NULL,3.0000,1),('dafc626d-a473-11f1-b5ab-6ed8ca3651ef',NULL,'QUAN-AU','Quáº§n Ã‚u','quan-au','Quáº§n Ã¢u, jeans, kaki nam cao cáº¥p',NULL,NULL,4.0000,1),('dafc6418-a473-11f1-b5ab-6ed8ca3651ef',NULL,'AO-KHOAC','Ão KhoÃ¡c','ao-khoac','Ão khoÃ¡c giÃ³, bomber, phao, da lá»™n',NULL,NULL,5.0000,1),('dafc65cb-a473-11f1-b5ab-6ed8ca3651ef',NULL,'AO-SOMI','Ão SÆ¡ Mi','ao-so-mi','Ão sÆ¡ mi nam dÃ i tay, ngáº¯n tay',NULL,NULL,6.0000,1),('dafc6794-a473-11f1-b5ab-6ed8ca3651ef',NULL,'AO-NI','Ão Ná»‰/Hoodie','ao-ni','Ão ná»‰, hoodie, len nam giá»¯ áº¥m',NULL,NULL,7.0000,1),('dafc694f-a473-11f1-b5ab-6ed8ca3651ef',NULL,'PHU-KIEN','Phá»¥ Kiá»‡n','phu-kien','Tháº¯t lÆ°ng, phá»¥ kiá»‡n da Torano',NULL,NULL,8.0000,1);
/*!40000 ALTER TABLE `cat_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_color`
--

DROP TABLE IF EXISTS `cat_color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_color` (
  `cat_color_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID mau sac',
  `cat_color_name` varchar(50) NOT NULL COMMENT 'Ten mau (Den, Trang, Navy...)',
  `cat_color_hex` varchar(7) NOT NULL COMMENT 'Ma HEX (#1a1a1a)',
  `cat_color_sort` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Thu tu sap xep',
  `cat_color_status` tinyint NOT NULL DEFAULT '1' COMMENT '0: An, 1: Active',
  PRIMARY KEY (`cat_color_id`),
  UNIQUE KEY `uix_catcolor_catcolorname` (`cat_color_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Danh muc mau sac san pham';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_color`
--

LOCK TABLES `cat_color` WRITE;
/*!40000 ALTER TABLE `cat_color` DISABLE KEYS */;
INSERT INTO `cat_color` VALUES ('44087f4f-a429-11f1-b5ab-6ed8ca3651ef','Äen','#1a1a1a',1.0000,1),('440884a3-a429-11f1-b5ab-6ed8ca3651ef','Xanh Navy','#1e3a5f',2.0000,1),('4408856c-a429-11f1-b5ab-6ed8ca3651ef','Tráº¯ng','#f5f5f5',3.0000,1),('440886a4-a429-11f1-b5ab-6ed8ca3651ef','XÃ¡m','#808080',4.0000,1),('44088740-a429-11f1-b5ab-6ed8ca3651ef','Be','#c8ad7f',5.0000,1),('4408879c-a429-11f1-b5ab-6ed8ca3651ef','NÃ¢u','#8b5e3c',6.0000,1),('440887f3-a429-11f1-b5ab-6ed8ca3651ef','Xanh rÃªu','#4a6741',7.0000,1),('44088848-a429-11f1-b5ab-6ed8ca3651ef','Äá» Ä‘áº­m','#8b2500',8.0000,1),('ff4e0701-a41d-11f1-b0a9-762043079894','Den','#1a1a1a',1.0000,1),('ff4e0bae-a41d-11f1-b0a9-762043079894','Trang','#ffffff',2.0000,1),('ff4e0cdb-a41d-11f1-b0a9-762043079894','Kem','#f5f0e1',3.0000,1),('ff4e0d4d-a41d-11f1-b0a9-762043079894','Do Ca Ro','#c0392b',4.0000,1),('ff4e0daa-a41d-11f1-b0a9-762043079894','Xanh Ca Ro','#2980b9',5.0000,1),('ff4e0e08-a41d-11f1-b0a9-762043079894','Xanh Dam','#1a3c5e',6.0000,1),('ff4e0e54-a41d-11f1-b0a9-762043079894','Xanh Nhe','#5dade2',7.0000,1),('ff4e0ea0-a41d-11f1-b0a9-762043079894','Nau','#6d4c41',8.0000,1),('ff4e0efb-a41d-11f1-b0a9-762043079894','Xam','#808080',9.0000,1);
/*!40000 ALTER TABLE `cat_color` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_product`
--

DROP TABLE IF EXISTS `cat_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_product` (
  `cat_product_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toÃ n cá»¥c cá»§a Sáº£n pháº©m gá»‘c',
  `cat_category_id` char(36) NOT NULL COMMENT 'KhÃ³a ngoáº¡i trá» tá»›i danh má»¥c chÃ­nh',
  `cat_product_code` varchar(20) NOT NULL COMMENT 'MÃ£ sáº£n pháº©m dÃ¹ng ná»™i bá»™',
  `cat_product_name` varchar(255) NOT NULL COMMENT 'TÃªn sáº£n pháº©m hiá»ƒn thá»‹ trÃªn Web',
  `cat_product_slug` varchar(255) DEFAULT NULL COMMENT 'URL slug cho SEO (VD: ao-polo-nam-cao-cap)',
  `cat_product_description` text COMMENT 'MÃ´ táº£ chi tiáº¿t sáº£n pháº©m (LÆ°u HTML Rich Text)',
  `cat_product_short_desc` text COMMENT 'Mo ta ngan hien thi duoi title',
  `cat_product_seo_title` varchar(60) DEFAULT NULL COMMENT 'SEO Title (max 60 ky tu)',
  `cat_product_seo_desc` varchar(160) DEFAULT NULL COMMENT 'Meta Description (max 160 ky tu)',
  `cat_product_brand` varchar(100) DEFAULT NULL COMMENT 'Thuong hieu san pham',
  `cat_product_origin` varchar(100) DEFAULT NULL,
  `cat_product_material` varchar(255) DEFAULT NULL,
  `cat_product_packaging_type` varchar(50) DEFAULT NULL,
  `cat_product_condition` varchar(20) DEFAULT 'new',
  `cat_product_weight` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `cat_product_length` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `cat_product_width` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `cat_product_height` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `cat_product_pre_order` tinyint NOT NULL DEFAULT '0',
  `cat_product_pre_order_days` int NOT NULL DEFAULT '7',
  `cat_product_is_featured` tinyint NOT NULL DEFAULT '0' COMMENT '1: Noi bat, 0: Thuong',
  `cat_product_is_new` tinyint NOT NULL DEFAULT '1' COMMENT '1: Moi, 0: Khong',
  `cat_product_tags` text COMMENT 'Tags JSON array',
  `cat_product_status` tinyint NOT NULL DEFAULT '1' COMMENT 'Tráº¡ng thÃ¡i: 0: NhÃ¡p, 1: Äang bÃ¡n, 2: áº¨n/Ngá»«ng bÃ¡n',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'NgÃ y giá» táº¡o sáº£n pháº©m',
  `modified_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Ngay cap nhat',
  PRIMARY KEY (`cat_product_id`),
  UNIQUE KEY `uix_catproduct_catproductcode` (`cat_product_code`),
  UNIQUE KEY `uix_catproduct_catproductslug` (`cat_product_slug`),
  KEY `ix_catproduct_catcategoryid` (`cat_category_id`),
  FULLTEXT KEY `ftx_cat_product_name_code` (`cat_product_name`,`cat_product_code`),
  CONSTRAINT `fk_catproduct_catcategory` FOREIGN KEY (`cat_category_id`) REFERENCES `cat_category` (`cat_category_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Danh má»¥c Sáº£n pháº©m gá»‘c (chÆ°a phÃ¢n loáº¡i mÃ u/size)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_product`
--

LOCK TABLES `cat_product` WRITE;
/*!40000 ALTER TABLE `cat_product` DISABLE KEYS */;
INSERT INTO `cat_product` VALUES ('442959ab-a429-11f1-b5ab-6ed8ca3651ef','441309c4-a429-11f1-b5ab-6ed8ca3651ef','GSTP643','Ão polo trÆ¡n bo káº» thÃªu logo ngá»±c GSTP643','ao-polo-tron-bo-ke-theu-logo-nguc-4-gstp643',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,1,NULL,1,'2026-08-30 04:14:16','2026-08-30 04:14:16'),('443add33-a429-11f1-b5ab-6ed8ca3651ef','441309c4-a429-11f1-b5ab-6ed8ca3651ef','GSTP042','Ão polo káº» bo tay phá»‘i mÃ u GSTP042','ao-polo-ke-bo-tay-phoi-mau-2-gstp042',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,1,NULL,1,'2026-08-30 04:14:17','2026-08-30 04:14:17'),('444b4854-a429-11f1-b5ab-6ed8ca3651ef','441309c4-a429-11f1-b5ab-6ed8ca3651ef','ESTP038','Ão Polo trÆ¡n basic thÃªu logo ngá»±c ESTP038','ao-polo-tron-basic-den-theu-logo-nguc-estp038',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,1,NULL,1,'2026-08-30 04:14:17','2026-08-30 04:14:17'),('445f2d99-a429-11f1-b5ab-6ed8ca3651ef','441309c4-a429-11f1-b5ab-6ed8ca3651ef','GSTP047','Ão polo can phá»‘i thÃªu logo Ä‘áº¡i bÃ ng GSTP047','ao-polo-can-phoi-theu-logo-nguc-3-gstp047',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,1,NULL,1,'2026-08-30 04:14:17','2026-08-30 04:14:17'),('446b28ca-a429-11f1-b5ab-6ed8ca3651ef','441309c4-a429-11f1-b5ab-6ed8ca3651ef','GWTP502','Ão Polo dÃ i tay basic thÃªu logo ngá»±c GWTP502','ao-polo-dai-tay-basic-theu-logo-nguc-3-gwtp502',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,1,NULL,1,'2026-08-30 04:14:17','2026-08-30 04:14:17'),('447e2728-a429-11f1-b5ab-6ed8ca3651ef','44130dbb-a429-11f1-b5ab-6ed8ca3651ef','GSTS018','Ão T shirt trÆ¡n in thá»ƒ thao GSTS018','ao-t-shirt-tron-in-phan-quang-3-gsts018',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:17','2026-08-30 04:14:17'),('449161c8-a429-11f1-b5ab-6ed8ca3651ef','44130dbb-a429-11f1-b5ab-6ed8ca3651ef','GSTS017','Ão T shirt trÆ¡n in thá»ƒ thao GSTS017','ao-t-shirt-tron-in-logo-phan-quang-4-gsts017',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:17','2026-08-30 04:14:17'),('449f622a-a429-11f1-b5ab-6ed8ca3651ef','44130dbb-a429-11f1-b5ab-6ed8ca3651ef','GSTS006','Ão T shirt trÆ¡n in logo ngá»±c GSTS006','ao-t-shirt-tron-in-logo-nguc-2-gsts006',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:17','2026-08-30 04:14:17'),('44b19bd4-a429-11f1-b5ab-6ed8ca3651ef','44130dbb-a429-11f1-b5ab-6ed8ca3651ef','FSTS002','Ão T shirt thá»ƒ thao basic FSTS002','ao-t-shirt-the-thao-basic-5-fsts002',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:17','2026-08-30 04:14:17'),('44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','44130dbb-a429-11f1-b5ab-6ed8ca3651ef','FSTS001','Ão T shirt trÆ¡n in logo ngá»±c FSTS001','ao-t-shirt-tron-in-logo-nguc-8-fsts001',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:17','2026-08-30 04:14:17'),('44d43b41-a429-11f1-b5ab-6ed8ca3651ef','44130dbb-a429-11f1-b5ab-6ed8ca3651ef','FSTS026','Ão T shirt há»a tiáº¿t in logo Horse ngá»±c FSTS026','ao-t-shirt-hoa-tiet-in-logo-horse-nguc-6-fsts026',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:18','2026-08-30 04:14:18'),('44e7e709-a429-11f1-b5ab-6ed8ca3651ef','44130f74-a429-11f1-b5ab-6ed8ca3651ef','FSBI001','Quáº§n short Ä‘Å©i cáº¡p chun basic FSBI001','quan-short-dui-cap-chun-basic-gap-gau-fsbi001',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:18','2026-08-30 04:14:18'),('44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','44130f74-a429-11f1-b5ab-6ed8ca3651ef','FSBK012','Quáº§n short khaki cáº¡p thÆ°á»ng basic FSBK012','quan-short-khaki-cap-thuong-basic-fsbk012',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:18','2026-08-30 04:14:18'),('450dcece-a429-11f1-b5ab-6ed8ca3651ef','44130f74-a429-11f1-b5ab-6ed8ca3651ef','BW600','Quáº§n Short giÃ³ thá»ƒ thao Ä‘á»¥c lá»— sÆ°á»n BW600','quan-short-gio-the-thao-duc-lo-suon-bw600',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:18','2026-08-30 04:14:18'),('45292f7e-a429-11f1-b5ab-6ed8ca3651ef','44130f74-a429-11f1-b5ab-6ed8ca3651ef','FSBW001','Quáº§n short giÃ³ basic phá»‘i chun cáº¡p FSBW001','quan-short-gio-basic-phoi-chun-cap-fsbw001',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:18','2026-08-30 04:14:18'),('45373472-a429-11f1-b5ab-6ed8ca3651ef','44130f74-a429-11f1-b5ab-6ed8ca3651ef','FSBK015','Quáº§n Short Khaki chiáº¿t eo gáº¥u LV FSBK015','quan-short-khaki-chiet-eo-gau-lv-fsbk015',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:18','2026-08-30 04:14:18'),('4549436c-a429-11f1-b5ab-6ed8ca3651ef','44130f74-a429-11f1-b5ab-6ed8ca3651ef','FSBK010','Quáº§n short khaki cáº¡p chun basic FSBK010','quan-short-khaki-cap-chun-basic-fsbk010',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:18','2026-08-30 04:14:18'),('455b462f-a429-11f1-b5ab-6ed8ca3651ef','44131021-a429-11f1-b5ab-6ed8ca3651ef','GABT892','Quáº§n Ã¢u slimfit trÆ¡n cáº¡p chun gáº¥u LV GABT892','quan-au-slimfit-tron-cap-chun-tui-cheo-theu-logo-5-gabt892',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:18','2026-08-30 04:14:18'),('4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','44131021-a429-11f1-b5ab-6ed8ca3651ef','GABT891','Quáº§n Ã¢u regularfit trÆ¡n tÃºi chÃ©o thÃªu logo GABT891','quan-au-regularfit-tron-tui-cheo-theu-logo-3-gabt891',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:19','2026-08-30 04:14:19'),('4580ed89-a429-11f1-b5ab-6ed8ca3651ef','44131021-a429-11f1-b5ab-6ed8ca3651ef','DABT900','Quáº§n Ã¢u slim-fit cáº¡p trÆ¡n DABT900','quan-au-slimfit-cap-tron-5-dabt900',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:19','2026-08-30 04:14:19'),('458d7ca5-a429-11f1-b5ab-6ed8ca3651ef','44131021-a429-11f1-b5ab-6ed8ca3651ef','EABJ012','Quáº§n Jeans basic slim EABJ012','quan-jeans-basic-slim-eabj012',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:19','2026-08-30 04:14:19'),('459abd94-a429-11f1-b5ab-6ed8ca3651ef','44131021-a429-11f1-b5ab-6ed8ca3651ef','FABK001','Quáº§n kaki dÃ i basic cáº¡p tender FABK001','quan-kaki-dai-basic-cap-tender-5-fabk001',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:19','2026-08-30 04:14:19'),('45af322a-a429-11f1-b5ab-6ed8ca3651ef','44131021-a429-11f1-b5ab-6ed8ca3651ef','GABJ302','Quáº§n Jeans basic relaxedfit GABJ302','quan-jeans-basic-relaxedfit-1-gabj302',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,1,0,NULL,1,'2026-08-30 04:14:19','2026-08-30 04:14:19'),('45be08bd-a429-11f1-b5ab-6ed8ca3651ef','441310bb-a429-11f1-b5ab-6ed8ca3651ef','GWCW505','Ão khoÃ¡c giÃ³ 2 lá»›p cá»• báº» thÃªu logo GWCW505','ao-khoac-gio-2-lop-co-be-theu-logo-1-gwcw505',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,1,0,NULL,1,'2026-08-30 04:14:19','2026-08-30 04:14:19'),('45d315eb-a429-11f1-b5ab-6ed8ca3651ef','441310bb-a429-11f1-b5ab-6ed8ca3651ef','GWCW051','Ão khoÃ¡c bá»™ giÃ³ 2 lá»›p can phá»‘i mÅ© liá»n GWCW051','ao-khoac-gio-2-lop-can-phoi-mu-lien-3-gwcw051',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:19','2026-08-30 04:14:19'),('45e2510c-a429-11f1-b5ab-6ed8ca3651ef','441310bb-a429-11f1-b5ab-6ed8ca3651ef','GWCU051','Ão khoÃ¡c bomber lÃ³t lÃ´ng thÃªu logo ngá»±c GWCU051','ao-khoac-bomber-lot-long-theu-logo-nguc-5-gwcu051',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:19','2026-08-30 04:14:19'),('45f2dcfb-a429-11f1-b5ab-6ed8ca3651ef','441310bb-a429-11f1-b5ab-6ed8ca3651ef','GWCJ503','Ão khoÃ¡c khaki 2 lá»›p cháº§n bÃ´ng cá»• bomber GWCJ503','ao-khoac-khaki-2-lop-chan-bong-co-bomber-theu-logo-mat-sau-4-gwcj503',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:19','2026-08-30 04:14:19'),('46009d4c-a429-11f1-b5ab-6ed8ca3651ef','441310bb-a429-11f1-b5ab-6ed8ca3651ef','GWCL902','Ão khoÃ¡c da lá»™n basic cá»• báº» lÃ³t lÃ´ng GWCL902','ao-khoac-da-lon-basic-co-be-theu-logo-nguc-4-gwcl902',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:20','2026-08-30 04:14:20'),('4610fb49-a429-11f1-b5ab-6ed8ca3651ef','441310bb-a429-11f1-b5ab-6ed8ca3651ef','GWCF004','Ão khoÃ¡c phao 3 lá»›p lÃ³t bÃ´ng regularfit GWCF004','ao-khoac-phao-3-lop-lot-bong-co-cao-regularfit-tron-gwcf004',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:20','2026-08-30 04:14:20'),('462079e0-a429-11f1-b5ab-6ed8ca3651ef','4413120d-a429-11f1-b5ab-6ed8ca3651ef','GATB011','Ão sÆ¡ mi dÃ i tay trÆ¡n GATB011','so-mi-dai-tay-tron-1-gatb011',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:20','2026-08-30 04:14:20'),('462f71fc-a429-11f1-b5ab-6ed8ca3651ef','4413120d-a429-11f1-b5ab-6ed8ca3651ef','DATB920','Ão sÆ¡ mi dÃ i tay trÆ¡n Bamboo DATB920','ao-so-mi-dai-tay-tron-bamboo-datb920',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:20','2026-08-30 04:14:20'),('463be2df-a429-11f1-b5ab-6ed8ca3651ef','4413120d-a429-11f1-b5ab-6ed8ca3651ef','FATB001','SÆ¡ mi dÃ i tay trÆ¡n dá»‡t kim FATB001','so-mi-dai-tay-tron-det-kim-3-fatb001',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:20','2026-08-30 04:14:20'),('464ca3d5-a429-11f1-b5ab-6ed8ca3651ef','4413120d-a429-11f1-b5ab-6ed8ca3651ef','FATB002','SÆ¡ mi dÃ i tay trÆ¡n FATB002','so-mi-dai-tay-tron-5-fatb002',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:20','2026-08-30 04:14:20'),('465a34e0-a429-11f1-b5ab-6ed8ca3651ef','4413120d-a429-11f1-b5ab-6ed8ca3651ef','FSTP056','Ão Polo trÆ¡n bá» máº·t hiá»‡u á»©ng FSTP056','ao-polo-tron-be-mat-hieu-ung-3-fstp056',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:20','2026-08-30 04:14:20'),('466c3b3c-a429-11f1-b5ab-6ed8ca3651ef','4413120d-a429-11f1-b5ab-6ed8ca3651ef','FSTP046','Ão Polo trÆ¡n bo káº» FSTP046','ao-polo-tron-bo-ke-1-fstp046',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:20','2026-08-30 04:14:20'),('467b9211-a429-11f1-b5ab-6ed8ca3651ef','44131352-a429-11f1-b5ab-6ed8ca3651ef','GWTW823','Ão ná»‰ há»a tiáº¿t thÃªu logo ngá»±a GWTW823','ao-ni-hoa-tiet-theu-logo-ngua-2-gwtw823',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:20','2026-08-30 04:14:20'),('469040b1-a429-11f1-b5ab-6ed8ca3651ef','44131352-a429-11f1-b5ab-6ed8ca3651ef','GWTW824','Ão ná»‰ há»a tiáº¿t in trÃ n GWTW824','ao-ni-hoa-tiet-in-tran-3-gwtw824',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:20','2026-08-30 04:14:20'),('469cdedd-a429-11f1-b5ab-6ed8ca3651ef','44131352-a429-11f1-b5ab-6ed8ca3651ef','GWTW826','Ão ná»‰ há»a tiáº¿t thÃªu hÃ¬nh Unbridled ambition GWTW826','ao-ni-hoa-tiet-theu-hinh-unbridled-ambition-3-gwtw826',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:21','2026-08-30 04:14:21'),('46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','44131352-a429-11f1-b5ab-6ed8ca3651ef','GWTW901','Ão ná»‰ bá»™ can phá»‘i tay GWTW901','ao-ni-can-phoi-tay-ao-basic-slimfit-5-gwtw901',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:21','2026-08-30 04:14:21'),('46bed247-a429-11f1-b5ab-6ed8ca3651ef','44131352-a429-11f1-b5ab-6ed8ca3651ef','FWTW001','Ão ná»‰ bá»™ can phá»‘i tay FWTW001','ao-ni-bo-can-phoi-tay-6-fwtw001',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:21','2026-08-30 04:14:21'),('46ca86cf-a429-11f1-b5ab-6ed8ca3651ef','44131352-a429-11f1-b5ab-6ed8ca3651ef','FWTW002','Ão ná»‰ Hoodie in trÃ n há»a tiáº¿t TRN FWTW002','ao-hoodie-in-tran-hoa-tiet-trn-1-fwtw002',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,1,0,NULL,1,'2026-08-30 04:14:21','2026-08-30 04:14:21'),('46d87e87-a429-11f1-b5ab-6ed8ca3651ef','441313ec-a429-11f1-b5ab-6ed8ca3651ef','GAAL002','Tháº¯t lÆ°ng da Torano GAAL002','that-lung-da-torano-1-gaal002',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:21','2026-08-30 04:14:21'),('46de937c-a429-11f1-b5ab-6ed8ca3651ef','441313ec-a429-11f1-b5ab-6ed8ca3651ef','GAAL003','Tháº¯t lÆ°ng Ä‘áº§u xoay 2 mÃ u Torano GAAL003','that-lung-dau-xoay-2-mau-torano-1-gaal003',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:21','2026-08-30 04:14:21'),('46e49990-a429-11f1-b5ab-6ed8ca3651ef','441313ec-a429-11f1-b5ab-6ed8ca3651ef','GAAL007','Tháº¯t lÆ°ng Ä‘áº§u xoay 2 hiá»‡u á»©ng Torano GAAL007','that-lung-dau-xoay-2-hieu-ung-torano-1-gaal007',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:21','2026-08-30 04:14:21'),('46e7feab-a429-11f1-b5ab-6ed8ca3651ef','441313ec-a429-11f1-b5ab-6ed8ca3651ef','GAAL015','Tháº¯t lÆ°ng da Torano GAAL015','that-lung-da-torano-1-gaal015',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:21','2026-08-30 04:14:21'),('46ece6cc-a429-11f1-b5ab-6ed8ca3651ef','441313ec-a429-11f1-b5ab-6ed8ca3651ef','GAAL016','Tháº¯t lÆ°ng da Torano GAAL016','that-lung-da-torano-1-gaal016',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:21','2026-08-30 04:14:21'),('46f26246-a429-11f1-b5ab-6ed8ca3651ef','441313ec-a429-11f1-b5ab-6ed8ca3651ef','GAAL012','Tháº¯t lÆ°ng da Torano GAAL012','that-lung-da-torano-1-gaal012',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 04:14:21','2026-08-30 04:14:21'),('db031e46-a473-11f1-b5ab-6ed8ca3651ef','dafc5826-a473-11f1-b5ab-6ed8ca3651ef','GSTP068','Ão polo káº» bo tay GSTP068','ao-polo-ke-bo-tay-3-gstp068',NULL,NULL,NULL,NULL,'Torano',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,1,1,NULL,1,'2026-08-30 13:08:12','2026-08-30 13:08:12'),('p0000000-0000-0000-0000-000000000001','c0000000-0000-0000-0000-000000000001','AT-001','Ao Thun Polo Nam Co Ban','ao-thun-polo-nam-co-ban','<p>Ao thun polo nam chat lieu cotton 100%, thoang mat, co dan, phu hop mac hang ngay va di lam casual.</p>','Ao thun polo nam cotton co ban, nhieu mau',NULL,NULL,'FashionEcom',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,1,1,NULL,1,'2026-08-30 02:53:46','2026-08-30 02:53:46'),('p0000000-0000-0000-0000-000000000002','c0000000-0000-0000-0000-000000000001','AT-002','Ao Thun Oversize Unisex In Hinh','ao-thun-oversize-unisex-in-hinh','<p>Ao thun oversize form rong, unisex, chat lieu cotton pha spandex, in hinh trendy.</p>','Ao thun oversize unisex, in hinh doc dao',NULL,NULL,'FashionEcom',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,1,NULL,1,'2026-08-30 02:53:46','2026-08-30 02:53:46'),('p0000000-0000-0000-0000-000000000003','c0000000-0000-0000-0000-000000000002','SM-001','Ao So Mi Trang Cong So Nam','ao-so-mi-trang-cong-so-nam','<p>Ao so mi trang slim fit, vai khong nhan, phu hop cong so va su kien trang trong.</p>','Ao so mi trang slim fit nam, khong nhan',NULL,NULL,'FashionEcom',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,1,1,NULL,1,'2026-08-30 02:53:46','2026-08-30 02:53:46'),('p0000000-0000-0000-0000-000000000004','c0000000-0000-0000-0000-000000000002','SM-002','Ao So Mi Ca Ro Flannel','ao-so-mi-ca-ro-flannel','<p>Ao so mi flannel ca ro, chat lieu day dan, giu am tot, phong cach casual.</p>','So mi flannel ca ro, am ap mua dong',NULL,NULL,'FashionEcom',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,1,NULL,1,'2026-08-30 02:53:46','2026-08-30 02:53:46'),('p0000000-0000-0000-0000-000000000005','c0000000-0000-0000-0000-000000000003','QJ-001','Quan Jeans Slim Fit Nam Xanh Dam','quan-jeans-slim-fit-nam-xanh-dam','<p>Quan jeans nam slim fit, co gian nhe, mau xanh dam co dien, de phoi do.</p>','Jeans slim fit nam, xanh dam co dien',NULL,NULL,'FashionEcom',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,1,1,NULL,1,'2026-08-30 02:53:46','2026-08-30 02:53:46'),('p0000000-0000-0000-0000-000000000006','c0000000-0000-0000-0000-000000000003','QJ-002','Quan Jeans Skinny Nu Wash Nhe','quan-jeans-skinny-nu-wash-nhe','<p>Quan jeans nu skinny, wash nhe, co gian cao, ton dang, thoai mai van dong.</p>','Jeans skinny nu, wash nhe, co gian cao',NULL,NULL,'FashionEcom',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,1,NULL,1,'2026-08-30 02:53:46','2026-08-30 02:53:46'),('p0000000-0000-0000-0000-000000000007','c0000000-0000-0000-0000-000000000004','AK-001','Ao Khoac Bomber Nam Da PU','ao-khoac-bomber-nam-da-pu','<p>Ao khoac bomber chat lieu da PU cao cap, phong cach manh me, chong gio nhe.</p>','Bomber da PU nam, phong cach manh me',NULL,NULL,'FashionEcom',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,1,0,NULL,1,'2026-08-30 02:53:46','2026-08-30 02:53:46'),('p0000000-0000-0000-0000-000000000008','c0000000-0000-0000-0000-000000000004','AK-002','Ao Hoodie Unisex Noi Tay','ao-hoodie-unisex-noi-tay','<p>Ao hoodie unisex, noi cotton day, giu am tot, form rong thoai mai.</p>','Hoodie unisex noi cotton, giu am tot',NULL,NULL,'FashionEcom',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,1,NULL,1,'2026-08-30 02:53:46','2026-08-30 02:53:46'),('p0000000-0000-0000-0000-000000000009','c0000000-0000-0000-0000-000000000005','PK-001','That Lung Da Bo Nam Khoa Tu Dong','that-lung-da-bo-nam-khoa-tu-dong','<p>That lung da bo that, khoa tu dong cao cap, be rong 3.5cm, phu hop cong so.</p>','That lung da bo that, khoa tu dong',NULL,NULL,'FashionEcom',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,0,NULL,1,'2026-08-30 02:53:46','2026-08-30 02:53:46'),('p0000000-0000-0000-0000-000000000010','c0000000-0000-0000-0000-000000000005','PK-002','Vi Da Nam Card Holder Mini','vi-da-nam-card-holder-mini','<p>Vi da nam nho gon, card holder, nhieu ngan, chat lieu da PU chong tray.</p>','Vi da nam mini, nhieu ngan tien loi',NULL,NULL,'FashionEcom',NULL,NULL,NULL,'new',0.0000,0.0000,0.0000,0.0000,0,7,0,1,NULL,1,'2026-08-30 02:53:46','2026-08-30 02:53:46');
/*!40000 ALTER TABLE `cat_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_product_media`
--

DROP TABLE IF EXISTS `cat_product_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_product_media` (
  `cat_product_media_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toÃ n cá»¥c cá»§a Media sáº£n pháº©m',
  `cat_product_id` char(36) NOT NULL COMMENT 'KhÃ³a ngoáº¡i trá» tá»›i Sáº£n pháº©m',
  `cat_product_variant_id` char(36) DEFAULT NULL COMMENT 'KhÃ³a ngoáº¡i Biáº¿n thá»ƒ (NULL náº¿u lÃ  áº£nh chung cho cáº£ SP, cÃ³ giÃ¡ trá»‹ náº¿u lÃ  áº£nh riÃªng cá»§a tá»«ng mÃ u)',
  `cat_product_media_path` varchar(255) NOT NULL COMMENT 'ÄÆ°á»ng dáº«n thÆ° má»¥c váº­t lÃ½ (VD: /products/2024/05/abc.webp)',
  `cat_product_media_type` tinyint NOT NULL DEFAULT '1' COMMENT 'Loáº¡i file: 1: Image, 2: Video',
  `cat_product_media_sort` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Thá»© tá»± sáº¯p xáº¿p hiá»ƒn thá»‹ trÃªn Gallery',
  PRIMARY KEY (`cat_product_media_id`),
  KEY `ix_catproductmedia_catproductid` (`cat_product_id`),
  KEY `ix_catproductmedia_catproductvariantid` (`cat_product_variant_id`),
  CONSTRAINT `fk_catproductmedia_catproduct` FOREIGN KEY (`cat_product_id`) REFERENCES `cat_product` (`cat_product_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_catproductmedia_catproductvariant` FOREIGN KEY (`cat_product_variant_id`) REFERENCES `cat_product_variant` (`cat_product_variant_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='LÆ°u trá»¯ Ä‘Æ°á»ng dáº«n HÃ¬nh áº£nh, Video cá»§a Sáº£n pháº©m (Local Storage)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_product_media`
--

LOCK TABLES `cat_product_media` WRITE;
/*!40000 ALTER TABLE `cat_product_media` DISABLE KEYS */;
INSERT INTO `cat_product_media` VALUES ('4417cad0-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/_o_web_75638124a9704332bada4b2aa10c379b_master.png',1,1.0000),('4419ccdf-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54629081966_cbaaad4789_k_1ef0ed7dd60e4779afcb8259929ec3b1_master.jpg',1,2.0000),('442a17a0-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/_o_web_b3095315fbad44439231d69b28c8e420_master.png',1,1.0000),('442ac808-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54629287024_aa453ac2be_k_8bbc8777a0cc43d088864b6588a3cd3f_master.jpg',1,2.0000),('443e8d5a-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/_o_web_b2d41e8adb7e4050a404a3ad11696770_master.png',1,1.0000),('443f3b1e-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54629391780_548de97568_k_e76a147413104a67ab054854afcf4ae1_master.jpg',1,2.0000),('444c6fc0-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/1_42b0199a7ff846fb8d066deb10672a81_master.png',1,1.0000),('444d2bce-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/5_3246ef0319354cdebefa12c46b16df67_master.png',1,2.0000),('4460be78-a429-11f1-b5ab-6ed8ca3651ef','445f2d99-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/1_257a3776f6a54b32a5d2612e41582b64_master.png',1,1.0000),('44615d9b-a429-11f1-b5ab-6ed8ca3651ef','445f2d99-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/8_3849787218384057ba447b05790935ce_master.png',1,2.0000),('446bccf9-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/_o_web__2__85e02af752c1443aa16633aa1ac4076b_master.png',1,1.0000),('446c8760-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/_o_web__1__0e9104c64a924e19a8f88bb29b3b5b51_master.png',1,2.0000),('447ee18d-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/2_c84d08a4d3984392b5b7be8a45e3e16e_master.png',1,1.0000),('44805334-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54850534122_abd94e6bc4_k_0366700a90854459af974377e28d3a30_master.jpg',1,2.0000),('449211d1-a429-11f1-b5ab-6ed8ca3651ef','449161c8-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/1_457e8f91dae54ba6a9ed2ad64be7ad47_master.png',1,1.0000),('4492cb4e-a429-11f1-b5ab-6ed8ca3651ef','449161c8-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54930091512_12e28ca3bc_c_5c170ac00dee4db195185811ca48e016_master.jpg',1,2.0000),('44a0d6d2-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/_o_web_afc4f5e440bf4e9988e93da9d021a203_master.png',1,1.0000),('44a1f90d-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54947149811_02e5e698a8_k_e943f1095ba846f0b97468759adf3318_master.jpg',1,2.0000),('44b255fe-a429-11f1-b5ab-6ed8ca3651ef','44b19bd4-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/tp038-1_f8e3fadea4364cbda92fa58a7b38aac7_master.png',1,1.0000),('44b3650a-a429-11f1-b5ab-6ed8ca3651ef','44b19bd4-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/576869033_1252460493594196_3116353017788408982_n_356619ed176d4bdc8b7284fdcc8c782b_master.jpg',1,2.0000),('44c129cc-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/thiet_ke_chua_co_ten__5__ed54b4168e6f4f3f92e24f6ebd4961f7_master.png',1,1.0000),('44c1cbcd-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/577038858_1255218279985084_5252201006724013030_n_a50bbe37fade4c44ae5774983b5dd3fe_master.jpg',1,2.0000),('44d4dc20-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/tp038-1_12784231360b4e619e47e59ee28981c6_master.png',1,1.0000),('44d582b5-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/590729306_1268920281948217_8370921118819506715_n_07f456a575194ceca632fcdc9f6fcc47_master.jpg',1,2.0000),('44e88e28-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/fsbi001-9_53586798344_o_d2e78b3de56d4b098fe40d3310c7f996_master.jpg',1,1.0000),('44e94080-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/595913189_1278756820964563_6438612972851276560_n_c14be49bb87e437f951df031135d2c60_master.jpg',1,2.0000),('44faa0ac-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/fsbk012-2_53626901061_o_60d9ea3be5a44c31ac15ba401a919896_master.jpg',1,1.0000),('44fb4f35-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/600532210_1285691930271052_7217001211690083350_n_4f122840c25e45779b311cf4929e9544_master.jpg',1,2.0000),('450e7eb2-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/bw600_82451b6d03bc40ada574ce3f8401df2f_master.jpg',1,1.0000),('450f3537-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/497728757_1107401171433463_2464759818378874823_n_e1e65cfc022749f7afe99b9960de023c_master.jpg',1,2.0000),('452a0d27-a429-11f1-b5ab-6ed8ca3651ef','45292f7e-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/avt_web_1150_x_1475_px__3592e7567bb24ab4bf2f4e467b2e48d3_master.png',1,1.0000),('452b084a-a429-11f1-b5ab-6ed8ca3651ef','45292f7e-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/514694025_1144505567723023_2229080463376009636_n_2fc8f4d493e544a78e71b085a26bfbdb_master.jpg',1,2.0000),('45380534-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/tp038-1_2e954120db914978b420e969f044a0cd_master.png',1,1.0000),('45389f3b-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/517136676_1147676020739311_4226858427086245361_n_0ebde8dbb9e64dc5959b35bbdd2a394c_master.jpg',1,2.0000),('4549f805-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/53569696867_539e007d35_b_f6c9571bb6684f7cbcc39a3f20adc933_master.jpg',1,1.0000),('454aa3a8-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/img_0232_54976947321_o_c42f07dcd0bc43fd84a484ee8cf1abcf_master.jpg',1,2.0000),('455bf4e9-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/t892_eb23ce8e51714572b03a1fbe52f91dfe_master.png',1,1.0000),('455cea72-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54629081966_cbaaad4789_k_1ef0ed7dd60e4779afcb8259929ec3b1_master.jpg',1,2.0000),('45721c9c-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/t891_3eead5a7f97e4c649b40221367f517f5_master.png',1,1.0000),('45734e3e-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54629287024_aa453ac2be_k_8bbc8777a0cc43d088864b6588a3cd3f_master.jpg',1,2.0000),('458197c5-a429-11f1-b5ab-6ed8ca3651ef','4580ed89-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/bt900_afe890ccab214119b1fcb9b0340878f9_master.jpg',1,1.0000),('45826eed-a429-11f1-b5ab-6ed8ca3651ef','4580ed89-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54629391780_548de97568_k_e76a147413104a67ab054854afcf4ae1_master.jpg',1,2.0000),('458e2c71-a429-11f1-b5ab-6ed8ca3651ef','458d7ca5-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/bj012_972f5893a3c14a8f8d4c71e8a453f23e_master.jpg',1,1.0000),('458eed9b-a429-11f1-b5ab-6ed8ca3651ef','458d7ca5-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/5_3246ef0319354cdebefa12c46b16df67_master.png',1,2.0000),('459bba3d-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/qu_n_web_c166306cb69142db901aceaf3883c1c9_master.png',1,1.0000),('459c4eeb-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/8_3849787218384057ba447b05790935ce_master.png',1,2.0000),('45b16a10-a429-11f1-b5ab-6ed8ca3651ef','45af322a-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/qu_n_web_fc8dbced49084e6e986c7b2134fd9de9_master.png',1,1.0000),('45b21243-a429-11f1-b5ab-6ed8ca3651ef','45af322a-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/_o_web__1__0e9104c64a924e19a8f88bb29b3b5b51_master.png',1,2.0000),('45bfe6ef-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/_o_web_3b2942fceadc46408ee21184550cccd8_master.png',1,1.0000),('45c10f6e-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54850534122_abd94e6bc4_k_0366700a90854459af974377e28d3a30_master.jpg',1,2.0000),('45d43bd6-a429-11f1-b5ab-6ed8ca3651ef','45d315eb-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/5_3246ef0319354cdebefa12c46b16df67_master.png',1,1.0000),('45d4fdb9-a429-11f1-b5ab-6ed8ca3651ef','45d315eb-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54930091512_12e28ca3bc_c_5c170ac00dee4db195185811ca48e016_master.jpg',1,2.0000),('45e33a75-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/8_3849787218384057ba447b05790935ce_master.png',1,1.0000),('45e4020c-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54947149811_02e5e698a8_k_e943f1095ba846f0b97468759adf3318_master.jpg',1,2.0000),('45f4416a-a429-11f1-b5ab-6ed8ca3651ef','45f2dcfb-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/_o_web_fd9680326d1d47e5b772a6defbd19237_master.png',1,1.0000),('45f52a07-a429-11f1-b5ab-6ed8ca3651ef','45f2dcfb-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/576869033_1252460493594196_3116353017788408982_n_356619ed176d4bdc8b7284fdcc8c782b_master.jpg',1,2.0000),('46014b9c-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/_o_web_6885a311ce9940899082e6aaac6555e9_master.png',1,1.0000),('4601f948-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/577038858_1255218279985084_5252201006724013030_n_a50bbe37fade4c44ae5774983b5dd3fe_master.jpg',1,2.0000),('46128177-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/_o_web_f03fa12180374293b18c50f93c3dd3fd_master.png',1,1.0000),('46132103-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/590729306_1268920281948217_8370921118819506715_n_07f456a575194ceca632fcdc9f6fcc47_master.jpg',1,2.0000),('462143f3-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/thiet_ke_chua_co_ten__5__c43044e163cf44329b0c081ddaff1e5c_master.png',1,1.0000),('46222d58-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/595913189_1278756820964563_6438612972851276560_n_c14be49bb87e437f951df031135d2c60_master.jpg',1,2.0000),('46301fac-a429-11f1-b5ab-6ed8ca3651ef','462f71fc-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/tb920_a04cd3c42ae9458e9207fdccaf7bed48_master.png',1,1.0000),('4630af4d-a429-11f1-b5ab-6ed8ca3651ef','462f71fc-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/600532210_1285691930271052_7217001211690083350_n_4f122840c25e45779b311cf4929e9544_master.jpg',1,2.0000),('463cbdc1-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/tb001_c0675ef2b3a7434696f12bd8905d98e4_master.png',1,1.0000),('463d66e3-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/497728757_1107401171433463_2464759818378874823_n_e1e65cfc022749f7afe99b9960de023c_master.jpg',1,2.0000),('464d5525-a429-11f1-b5ab-6ed8ca3651ef','464ca3d5-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/tb002_de80d5dec15646a49b16d689b0873ac1_master.png',1,1.0000),('464e6395-a429-11f1-b5ab-6ed8ca3651ef','464ca3d5-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/514694025_1144505567723023_2229080463376009636_n_2fc8f4d493e544a78e71b085a26bfbdb_master.jpg',1,2.0000),('465b0dc5-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/thiet_ke_chua_co_ten__4__e085a9db930d492a9783a68d45d4d534_master.png',1,1.0000),('465ce3f5-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/517136676_1147676020739311_4226858427086245361_n_0ebde8dbb9e64dc5959b35bbdd2a394c_master.jpg',1,2.0000),('466d45d9-a429-11f1-b5ab-6ed8ca3651ef','466c3b3c-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/thiet_ke_chua_co_ten__4__2efaf64af4c942c4a3711b6f14fe808a_master.png',1,1.0000),('466df39d-a429-11f1-b5ab-6ed8ca3651ef','466c3b3c-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/img_0232_54976947321_o_c42f07dcd0bc43fd84a484ee8cf1abcf_master.jpg',1,2.0000),('467c2ff6-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/25_585e2dd08dfc4392b986ec1b3d115d74_master.png',1,1.0000),('467cd037-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54629081966_cbaaad4789_k_1ef0ed7dd60e4779afcb8259929ec3b1_master.jpg',1,2.0000),('4691200e-a429-11f1-b5ab-6ed8ca3651ef','469040b1-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/26_48c6beb5acd546ae860c015fe19dc154_master.png',1,1.0000),('4691bbaa-a429-11f1-b5ab-6ed8ca3651ef','469040b1-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54629287024_aa453ac2be_k_8bbc8777a0cc43d088864b6588a3cd3f_master.jpg',1,2.0000),('469df460-a429-11f1-b5ab-6ed8ca3651ef','469cdedd-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/27_3aa82df04f8b4f8788b4488d4c08f881_master.png',1,1.0000),('469f4e0a-a429-11f1-b5ab-6ed8ca3651ef','469cdedd-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54629391780_548de97568_k_e76a147413104a67ab054854afcf4ae1_master.jpg',1,2.0000),('46ad79d6-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/_o_web_500d269f1d9d4aafb2dbf9db640f63bd_master.png',1,1.0000),('46ae25d7-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/5_3246ef0319354cdebefa12c46b16df67_master.png',1,2.0000),('46bf6ecb-a429-11f1-b5ab-6ed8ca3651ef','46bed247-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/19334a78-6cbb-4bbb-abeb-31088b5578ff_ea4d8d95d7fe424297ad95179a26f18b_master.jpg',1,1.0000),('46c02505-a429-11f1-b5ab-6ed8ca3651ef','46bed247-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/8_3849787218384057ba447b05790935ce_master.png',1,2.0000),('46cb5754-a429-11f1-b5ab-6ed8ca3651ef','46ca86cf-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/thiet_ke_chua_co_ten__4__5f0ad70259c1470fbd5e51709ae99bd5_master.png',1,1.0000),('46cc95f6-a429-11f1-b5ab-6ed8ca3651ef','46ca86cf-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/_o_web__1__0e9104c64a924e19a8f88bb29b3b5b51_master.png',1,2.0000),('46da950f-a429-11f1-b5ab-6ed8ca3651ef','46d87e87-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/al002_4e1ff963227346adafb51ca0e87efe27_master.png',1,1.0000),('46db556d-a429-11f1-b5ab-6ed8ca3651ef','46d87e87-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54850534122_abd94e6bc4_k_0366700a90854459af974377e28d3a30_master.jpg',1,2.0000),('46df71a1-a429-11f1-b5ab-6ed8ca3651ef','46de937c-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/al003_6bbbf5c157ab4eefae2ddae428b4f01c_master.png',1,1.0000),('46e0122f-a429-11f1-b5ab-6ed8ca3651ef','46de937c-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54930091512_12e28ca3bc_c_5c170ac00dee4db195185811ca48e016_master.jpg',1,2.0000),('46e54c1c-a429-11f1-b5ab-6ed8ca3651ef','46e49990-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/al007_378e77d4f8244c68897fc748d4665b3a_master.png',1,1.0000),('46e5fac1-a429-11f1-b5ab-6ed8ca3651ef','46e49990-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54947149811_02e5e698a8_k_e943f1095ba846f0b97468759adf3318_master.jpg',1,2.0000),('46e8bf12-a429-11f1-b5ab-6ed8ca3651ef','46e7feab-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/al010_aa92a95073b0446e86a1d050436111d2_master.png',1,1.0000),('46e9724d-a429-11f1-b5ab-6ed8ca3651ef','46e7feab-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/576869033_1252460493594196_3116353017788408982_n_356619ed176d4bdc8b7284fdcc8c782b_master.jpg',1,2.0000),('46edc6d6-a429-11f1-b5ab-6ed8ca3651ef','46ece6cc-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/al011_63e4d647752348dfb69f2538e4e13982_master.png',1,1.0000),('46ee7bdb-a429-11f1-b5ab-6ed8ca3651ef','46ece6cc-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/577038858_1255218279985084_5252201006724013030_n_a50bbe37fade4c44ae5774983b5dd3fe_master.jpg',1,2.0000),('46f30e4a-a429-11f1-b5ab-6ed8ca3651ef','46f26246-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/al014_a9aad068cdb34d94b21abbbf81c6bbff_master.png',1,1.0000),('46f3bc87-a429-11f1-b5ab-6ed8ca3651ef','46f26246-a429-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/590729306_1268920281948217_8370921118819506715_n_07f456a575194ceca632fcdc9f6fcc47_master.jpg',1,2.0000),('db043007-a473-11f1-b5ab-6ed8ca3651ef','db031e46-a473-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/_o_web_75638124a9704332bada4b2aa10c379b_master.png',1,1.0000),('db058eb9-a473-11f1-b5ab-6ed8ca3651ef','db031e46-a473-11f1-b5ab-6ed8ca3651ef',NULL,'/images/products/54629081966_cbaaad4789_k_1ef0ed7dd60e4779afcb8259929ec3b1_master.jpg',1,2.0000);
/*!40000 ALTER TABLE `cat_product_media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_product_variant`
--

DROP TABLE IF EXISTS `cat_product_variant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_product_variant` (
  `cat_product_variant_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toÃ n cá»¥c cá»§a Biáº¿n thá»ƒ (SKU)',
  `cat_product_id` char(36) NOT NULL COMMENT 'KhÃ³a ngoáº¡i trá» tá»›i Sáº£n pháº©m gá»‘c',
  `cat_product_variant_sku` varchar(20) NOT NULL COMMENT 'MÃ£ SKU thá»±c táº¿ cá»§a biáº¿n thá»ƒ (VÃ­ dá»¥: POLO-BLACK-XL)',
  `cat_product_variant_color` varchar(50) DEFAULT NULL COMMENT 'TÃªn mÃ u sáº¯c (VÃ­ dá»¥: Äen, Tráº¯ng)',
  `cat_product_variant_size` varchar(50) DEFAULT NULL COMMENT 'KÃ­ch cá»¡ (VÃ­ dá»¥: S, M, L, XL, 39, 40)',
  `cat_product_variant_price` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'GiÃ¡ bÃ¡n láº» hiá»‡n táº¡i',
  `cat_product_variant_compare_price` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Gia goc (gia gach)',
  `cat_product_variant_cost` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'GiÃ¡ vá»‘n (TÃ­nh toÃ¡n P&L)',
  `cat_product_variant_weight` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Trá»ng lÆ°á»£ng (Grams) dÃ¹ng tÃ­nh phÃ­ váº­n chuyá»ƒn',
  `cat_product_variant_barcode` varchar(50) DEFAULT NULL COMMENT 'Barcode EAN/UPC',
  `cat_product_variant_status` tinyint NOT NULL DEFAULT '1' COMMENT '0: An, 1: Hien',
  `cat_color_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'FK mau sac',
  `cat_size_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'FK kich thuoc',
  PRIMARY KEY (`cat_product_variant_id`),
  UNIQUE KEY `uix_catproductvariant_catproductvariantsku` (`cat_product_variant_sku`),
  UNIQUE KEY `uix_catproductvariant_product_color_size` (`cat_product_id`,`cat_color_id`,`cat_size_id`),
  KEY `ix_catproductvariant_catproductid` (`cat_product_id`),
  KEY `ix_catproductvariant_catcolorid` (`cat_color_id`),
  KEY `ix_catproductvariant_catsizeid` (`cat_size_id`),
  CONSTRAINT `fk_catproductvariant_catcolor` FOREIGN KEY (`cat_color_id`) REFERENCES `cat_color` (`cat_color_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_catproductvariant_catproduct` FOREIGN KEY (`cat_product_id`) REFERENCES `cat_product` (`cat_product_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_catproductvariant_catsize` FOREIGN KEY (`cat_size_id`) REFERENCES `cat_size` (`cat_size_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Danh sÃ¡ch Biáº¿n thá»ƒ sáº£n pháº©m (SKU) thá»±c táº¿ giao dá»‹ch';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_product_variant`
--

LOCK TABLES `cat_product_variant` WRITE;
/*!40000 ALTER TABLE `cat_product_variant` DISABLE KEYS */;
INSERT INTO `cat_product_variant` VALUES ('441aa968-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef','GSTP068-Xan-S','Xanh Navy','S',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('441b4a48-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef','GSTP068-Xan-M','Xanh Navy','M',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('441bf6eb-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef','GSTP068-Xan-L','Xanh Navy','L',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('441e2d0f-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef','GSTP068-Xan-XL','Xanh Navy','XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('441f3047-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef','GSTP068-Xan-2XL','Xanh Navy','2XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4421305e-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef','GSTP068-Äe-S','Äen','S',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('442203af-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef','GSTP068-Äe-M','Äen','M',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4422c386-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef','GSTP068-Äe-L','Äen','L',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44236ce7-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef','GSTP068-Äe-XL','Äen','XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4424098c-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef','GSTP068-Äe-2XL','Äen','2XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4424b51f-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef','GSTP068-XÃ¡-S','XÃ¡m','S',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44254622-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef','GSTP068-XÃ¡-M','XÃ¡m','M',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4425e046-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef','GSTP068-XÃ¡-L','XÃ¡m','L',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('442693a4-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef','GSTP068-XÃ¡-XL','XÃ¡m','XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44274c37-a429-11f1-b5ab-6ed8ca3651ef','4416f41e-a429-11f1-b5ab-6ed8ca3651ef','GSTP068-XÃ¡-2XL','XÃ¡m','2XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('442b90d3-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef','GSTP643-Xan-S','Xanh Navy','S',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('442c2a98-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef','GSTP643-Xan-M','Xanh Navy','M',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('442db3b2-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef','GSTP643-Xan-L','Xanh Navy','L',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('442ea598-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef','GSTP643-Xan-XL','Xanh Navy','XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('442f833f-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef','GSTP643-Xan-2XL','Xanh Navy','2XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4430769f-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef','GSTP643-Trá-S','Tráº¯ng','S',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4431fde6-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef','GSTP643-Trá-M','Tráº¯ng','M',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4432b877-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef','GSTP643-Trá-L','Tráº¯ng','L',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('443387a9-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef','GSTP643-Trá-XL','Tráº¯ng','XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('443442e3-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef','GSTP643-Trá-2XL','Tráº¯ng','2XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44362f40-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef','GSTP643-Äe-S','Äen','S',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('443703a9-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef','GSTP643-Äe-M','Äen','M',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44382420-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef','GSTP643-Äe-L','Äen','L',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4438d44a-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef','GSTP643-Äe-XL','Äen','XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44397676-a429-11f1-b5ab-6ed8ca3651ef','442959ab-a429-11f1-b5ab-6ed8ca3651ef','GSTP643-Äe-2XL','Äen','2XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44402396-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef','GSTP042-Äe-S','Äen','S',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4440cd63-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef','GSTP042-Äe-M','Äen','M',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4441740a-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef','GSTP042-Äe-L','Äen','L',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44420dd2-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef','GSTP042-Äe-XL','Äen','XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4442aa8e-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef','GSTP042-Äe-2XL','Äen','2XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4443544c-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef','GSTP042-Be-S','Be','S',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4443f4d0-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef','GSTP042-Be-M','Be','M',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4444f30c-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef','GSTP042-Be-L','Be','L',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4445938a-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef','GSTP042-Be-XL','Be','XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44462bf5-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef','GSTP042-Be-2XL','Be','2XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4446e1b2-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef','GSTP042-Xan-S','Xanh Navy','S',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4447fd9d-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef','GSTP042-Xan-M','Xanh Navy','M',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4448b4fe-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef','GSTP042-Xan-L','Xanh Navy','L',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('444952c3-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef','GSTP042-Xan-XL','Xanh Navy','XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4449e8d2-a429-11f1-b5ab-6ed8ca3651ef','443add33-a429-11f1-b5ab-6ed8ca3651ef','GSTP042-Xan-2XL','Xanh Navy','2XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('444ddf58-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-Äe-S','Äen','S',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('444e712b-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-Äe-M','Äen','M',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44508d8a-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-Äe-L','Äen','L',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44513b67-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-Äe-XL','Äen','XL',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4451d109-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-Äe-2XL','Äen','2XL',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44527951-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-NÃ¢-S','NÃ¢u','S',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('445314d2-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-NÃ¢-M','NÃ¢u','M',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4453aff1-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-NÃ¢-L','NÃ¢u','L',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4454dd2b-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-NÃ¢-XL','NÃ¢u','XL',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('445574c0-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-NÃ¢-2XL','NÃ¢u','2XL',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4456366d-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-Trá-S','Tráº¯ng','S',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4456ce40-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-Trá-M','Tráº¯ng','M',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4457674f-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-Trá-L','Tráº¯ng','L',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44581533-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-Trá-XL','Tráº¯ng','XL',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4458bcff-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-Trá-2XL','Tráº¯ng','2XL',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('445963e9-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-XÃ¡-S','XÃ¡m','S',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4459f44f-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-XÃ¡-M','XÃ¡m','M',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('445a8740-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-XÃ¡-L','XÃ¡m','L',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('445b84ca-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-XÃ¡-XL','XÃ¡m','XL',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('445c1ef9-a429-11f1-b5ab-6ed8ca3651ef','444b4854-a429-11f1-b5ab-6ed8ca3651ef','ESTP038-XÃ¡-2XL','XÃ¡m','2XL',249000.0000,400000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('446203f4-a429-11f1-b5ab-6ed8ca3651ef','445f2d99-a429-11f1-b5ab-6ed8ca3651ef','GSTP047-Xan-S','Xanh Navy','S',299000.0000,480000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4463c29f-a429-11f1-b5ab-6ed8ca3651ef','445f2d99-a429-11f1-b5ab-6ed8ca3651ef','GSTP047-Xan-M','Xanh Navy','M',299000.0000,480000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4464671e-a429-11f1-b5ab-6ed8ca3651ef','445f2d99-a429-11f1-b5ab-6ed8ca3651ef','GSTP047-Xan-L','Xanh Navy','L',299000.0000,480000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44651058-a429-11f1-b5ab-6ed8ca3651ef','445f2d99-a429-11f1-b5ab-6ed8ca3651ef','GSTP047-Xan-XL','Xanh Navy','XL',299000.0000,480000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4465a21b-a429-11f1-b5ab-6ed8ca3651ef','445f2d99-a429-11f1-b5ab-6ed8ca3651ef','GSTP047-Xan-2XL','Xanh Navy','2XL',299000.0000,480000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4466c2e4-a429-11f1-b5ab-6ed8ca3651ef','445f2d99-a429-11f1-b5ab-6ed8ca3651ef','GSTP047-Äe-S','Äen','S',299000.0000,480000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44675ce8-a429-11f1-b5ab-6ed8ca3651ef','445f2d99-a429-11f1-b5ab-6ed8ca3651ef','GSTP047-Äe-M','Äen','M',299000.0000,480000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('446806c6-a429-11f1-b5ab-6ed8ca3651ef','445f2d99-a429-11f1-b5ab-6ed8ca3651ef','GSTP047-Äe-L','Äen','L',299000.0000,480000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4468b4d9-a429-11f1-b5ab-6ed8ca3651ef','445f2d99-a429-11f1-b5ab-6ed8ca3651ef','GSTP047-Äe-XL','Äen','XL',299000.0000,480000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4469bc62-a429-11f1-b5ab-6ed8ca3651ef','445f2d99-a429-11f1-b5ab-6ed8ca3651ef','GSTP047-Äe-2XL','Äen','2XL',299000.0000,480000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('446d6b92-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef','GWTP502-Äe-S','Äen','S',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('446e0819-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef','GWTP502-Äe-M','Äen','M',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('446f3406-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef','GWTP502-Äe-L','Äen','L',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4470423c-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef','GWTP502-Äe-XL','Äen','XL',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4470e80e-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef','GWTP502-Äe-2XL','Äen','2XL',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44719707-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef','GWTP502-Xan-S','Xanh Navy','S',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('447259c9-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef','GWTP502-Xan-M','Xanh Navy','M',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4472f0d9-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef','GWTP502-Xan-L','Xanh Navy','L',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44739f32-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef','GWTP502-Xan-XL','Xanh Navy','XL',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44745a4a-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef','GWTP502-Xan-2XL','Xanh Navy','2XL',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44750e2b-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef','GWTP502-XÃ¡-S','XÃ¡m','S',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4475c329-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef','GWTP502-XÃ¡-M','XÃ¡m','M',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4476c70c-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef','GWTP502-XÃ¡-L','XÃ¡m','L',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('447aeac6-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef','GWTP502-XÃ¡-XL','XÃ¡m','XL',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('447cacb0-a429-11f1-b5ab-6ed8ca3651ef','446b28ca-a429-11f1-b5ab-6ed8ca3651ef','GWTP502-XÃ¡-2XL','XÃ¡m','2XL',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('448161e5-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef','GSTS018-Äe-S','Äen','S',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('448209fa-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef','GSTS018-Äe-M','Äen','M',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4482b4f8-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef','GSTS018-Äe-L','Äen','L',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('448381cc-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef','GSTS018-Äe-XL','Äen','XL',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('448421f8-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef','GSTS018-Äe-2XL','Äen','2XL',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44852d06-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef','GSTS018-Trá-S','Tráº¯ng','S',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44860bdf-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef','GSTS018-Trá-M','Tráº¯ng','M',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4486ca07-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef','GSTS018-Trá-L','Tráº¯ng','L',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('448760e9-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef','GSTS018-Trá-XL','Tráº¯ng','XL',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('448881c0-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef','GSTS018-Trá-2XL','Tráº¯ng','2XL',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4489286f-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef','GSTS018-Xan-S','Xanh Navy','S',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('448c2bdf-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef','GSTS018-Xan-M','Xanh Navy','M',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('448df8a5-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef','GSTS018-Xan-L','Xanh Navy','L',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('448eddfc-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef','GSTS018-Xan-XL','Xanh Navy','XL',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('448f8b6f-a429-11f1-b5ab-6ed8ca3651ef','447e2728-a429-11f1-b5ab-6ed8ca3651ef','GSTS018-Xan-2XL','Xanh Navy','2XL',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44938f03-a429-11f1-b5ab-6ed8ca3651ef','449161c8-a429-11f1-b5ab-6ed8ca3651ef','GSTS017-Äe-S','Äen','S',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44945866-a429-11f1-b5ab-6ed8ca3651ef','449161c8-a429-11f1-b5ab-6ed8ca3651ef','GSTS017-Äe-M','Äen','M',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4494f8d7-a429-11f1-b5ab-6ed8ca3651ef','449161c8-a429-11f1-b5ab-6ed8ca3651ef','GSTS017-Äe-L','Äen','L',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4495d04a-a429-11f1-b5ab-6ed8ca3651ef','449161c8-a429-11f1-b5ab-6ed8ca3651ef','GSTS017-Äe-XL','Äen','XL',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4497c8f8-a429-11f1-b5ab-6ed8ca3651ef','449161c8-a429-11f1-b5ab-6ed8ca3651ef','GSTS017-Äe-2XL','Äen','2XL',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44989dc7-a429-11f1-b5ab-6ed8ca3651ef','449161c8-a429-11f1-b5ab-6ed8ca3651ef','GSTS017-XÃ¡-S','XÃ¡m','S',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('449940c1-a429-11f1-b5ab-6ed8ca3651ef','449161c8-a429-11f1-b5ab-6ed8ca3651ef','GSTS017-XÃ¡-M','XÃ¡m','M',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('449a00b8-a429-11f1-b5ab-6ed8ca3651ef','449161c8-a429-11f1-b5ab-6ed8ca3651ef','GSTS017-XÃ¡-L','XÃ¡m','L',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('449aa440-a429-11f1-b5ab-6ed8ca3651ef','449161c8-a429-11f1-b5ab-6ed8ca3651ef','GSTS017-XÃ¡-XL','XÃ¡m','XL',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('449ba2fd-a429-11f1-b5ab-6ed8ca3651ef','449161c8-a429-11f1-b5ab-6ed8ca3651ef','GSTS017-XÃ¡-2XL','XÃ¡m','2XL',249000.0000,349000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44a2a699-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef','GSTS006-Äe-S','Äen','S',279000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44a34542-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef','GSTS006-Äe-M','Äen','M',279000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44a3eeff-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef','GSTS006-Äe-L','Äen','L',279000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44a4df3a-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef','GSTS006-Äe-XL','Äen','XL',279000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44a7dc84-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef','GSTS006-Äe-2XL','Äen','2XL',279000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44a883a9-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef','GSTS006-Trá-S','Tráº¯ng','S',279000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44a93b7e-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef','GSTS006-Trá-M','Tráº¯ng','M',279000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44a9d148-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef','GSTS006-Trá-L','Tráº¯ng','L',279000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44aa641c-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef','GSTS006-Trá-XL','Tráº¯ng','XL',279000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44ab15fe-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef','GSTS006-Trá-2XL','Tráº¯ng','2XL',279000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44abccc9-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef','GSTS006-XÃ¡-S','XÃ¡m','S',279000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44ac684f-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef','GSTS006-XÃ¡-M','XÃ¡m','M',279000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44ad11cb-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef','GSTS006-XÃ¡-L','XÃ¡m','L',279000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44af1490-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef','GSTS006-XÃ¡-XL','XÃ¡m','XL',279000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44b03a1b-a429-11f1-b5ab-6ed8ca3651ef','449f622a-a429-11f1-b5ab-6ed8ca3651ef','GSTS006-XÃ¡-2XL','XÃ¡m','2XL',279000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44b431c4-a429-11f1-b5ab-6ed8ca3651ef','44b19bd4-a429-11f1-b5ab-6ed8ca3651ef','FSTS002-Äe-S','Äen','S',149000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44b57413-a429-11f1-b5ab-6ed8ca3651ef','44b19bd4-a429-11f1-b5ab-6ed8ca3651ef','FSTS002-Äe-M','Äen','M',149000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44b6de6d-a429-11f1-b5ab-6ed8ca3651ef','44b19bd4-a429-11f1-b5ab-6ed8ca3651ef','FSTS002-Äe-L','Äen','L',149000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44b7be92-a429-11f1-b5ab-6ed8ca3651ef','44b19bd4-a429-11f1-b5ab-6ed8ca3651ef','FSTS002-Äe-XL','Äen','XL',149000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44b876be-a429-11f1-b5ab-6ed8ca3651ef','44b19bd4-a429-11f1-b5ab-6ed8ca3651ef','FSTS002-Äe-2XL','Äen','2XL',149000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44b94fb9-a429-11f1-b5ab-6ed8ca3651ef','44b19bd4-a429-11f1-b5ab-6ed8ca3651ef','FSTS002-Trá-S','Tráº¯ng','S',149000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44ba2026-a429-11f1-b5ab-6ed8ca3651ef','44b19bd4-a429-11f1-b5ab-6ed8ca3651ef','FSTS002-Trá-M','Tráº¯ng','M',149000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44bc2252-a429-11f1-b5ab-6ed8ca3651ef','44b19bd4-a429-11f1-b5ab-6ed8ca3651ef','FSTS002-Trá-L','Tráº¯ng','L',149000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44bcc0f3-a429-11f1-b5ab-6ed8ca3651ef','44b19bd4-a429-11f1-b5ab-6ed8ca3651ef','FSTS002-Trá-XL','Tráº¯ng','XL',149000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44bd5c17-a429-11f1-b5ab-6ed8ca3651ef','44b19bd4-a429-11f1-b5ab-6ed8ca3651ef','FSTS002-Trá-2XL','Tráº¯ng','2XL',149000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44c2f144-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','FSTS001-Äe-S','Äen','S',169000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44c3cc68-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','FSTS001-Äe-M','Äen','M',169000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44c49bff-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','FSTS001-Äe-L','Äen','L',169000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44c55f50-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','FSTS001-Äe-XL','Äen','XL',169000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44c6c529-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','FSTS001-Äe-2XL','Äen','2XL',169000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44c7ffda-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','FSTS001-Xan-S','Xanh Navy','S',169000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44c8e048-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','FSTS001-Xan-M','Xanh Navy','M',169000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44ca0346-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','FSTS001-Xan-L','Xanh Navy','L',169000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44cad141-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','FSTS001-Xan-XL','Xanh Navy','XL',169000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44cc2d5c-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','FSTS001-Xan-2XL','Xanh Navy','2XL',169000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44cd57df-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','FSTS001-Trá-S','Tráº¯ng','S',169000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44ce12dd-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','FSTS001-Trá-M','Tráº¯ng','M',169000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44cefaa0-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','FSTS001-Trá-L','Tráº¯ng','L',169000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44d0f99a-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','FSTS001-Trá-XL','Tráº¯ng','XL',169000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44d1c1dd-a429-11f1-b5ab-6ed8ca3651ef','44c05ce4-a429-11f1-b5ab-6ed8ca3651ef','FSTS001-Trá-2XL','Tráº¯ng','2XL',169000.0000,250000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44d62aa8-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef','FSTS026-Äe-S','Äen','S',300000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44d75f1c-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef','FSTS026-Äe-M','Äen','M',300000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44d8ae34-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef','FSTS026-Äe-L','Äen','L',300000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44d95a4f-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef','FSTS026-Äe-XL','Äen','XL',300000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44da8e92-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef','FSTS026-Äe-2XL','Äen','2XL',300000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44db645c-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef','FSTS026-Trá-S','Tráº¯ng','S',300000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44dc2079-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef','FSTS026-Trá-M','Tráº¯ng','M',300000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44dcb3bf-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef','FSTS026-Trá-L','Tráº¯ng','L',300000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44df7227-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef','FSTS026-Trá-XL','Tráº¯ng','XL',300000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44e02d54-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef','FSTS026-Trá-2XL','Tráº¯ng','2XL',300000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44e0e6cd-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef','FSTS026-Be-S','Be','S',300000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44e183f7-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef','FSTS026-Be-M','Be','M',300000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44e26861-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef','FSTS026-Be-L','Be','L',300000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44e3a549-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef','FSTS026-Be-XL','Be','XL',300000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44e5b724-a429-11f1-b5ab-6ed8ca3651ef','44d43b41-a429-11f1-b5ab-6ed8ca3651ef','FSTS026-Be-2XL','Be','2XL',300000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44e9f32a-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef','FSBI001-Äe-29','Äen','29',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44eaacd0-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef','FSBI001-Äe-30','Äen','30',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44eb525d-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef','FSBI001-Äe-31','Äen','31',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44ec22ab-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef','FSBI001-Äe-32','Äen','32',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44ed2dbc-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef','FSBI001-Äe-33','Äen','33',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44edec33-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef','FSBI001-Be-29','Be','29',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44ee8ec3-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef','FSBI001-Be-30','Be','30',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44ef2fcb-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef','FSBI001-Be-31','Be','31',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44efcd6c-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef','FSBI001-Be-32','Be','32',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44f07753-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef','FSBI001-Be-33','Be','33',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44f1e2d2-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef','FSBI001-XÃ¡-29','XÃ¡m','29',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44f28c52-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef','FSBI001-XÃ¡-30','XÃ¡m','30',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44f35266-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef','FSBI001-XÃ¡-31','XÃ¡m','31',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44f3f8c4-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef','FSBI001-XÃ¡-32','XÃ¡m','32',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44f79836-a429-11f1-b5ab-6ed8ca3651ef','44e7e709-a429-11f1-b5ab-6ed8ca3651ef','FSBI001-XÃ¡-33','XÃ¡m','33',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44fc34ba-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','FSBK012-Be-29','Be','29',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44fce262-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','FSBK012-Be-30','Be','30',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('44ff9c91-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','FSBK012-Be-31','Be','31',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('450092a5-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','FSBK012-Be-32','Be','32',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45015722-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','FSBK012-Be-33','Be','33',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45020d90-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','FSBK012-Äe-29','Äen','29',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4502afa9-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','FSBK012-Äe-30','Äen','30',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4503ea87-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','FSBK012-Äe-31','Äen','31',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45053b02-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','FSBK012-Äe-32','Äen','32',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45060bc8-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','FSBK012-Äe-33','Äen','33',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4506f061-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','FSBK012-Xan-29','Xanh Navy','29',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4507d60d-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','FSBK012-Xan-30','Xanh Navy','30',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45091a78-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','FSBK012-Xan-31','Xanh Navy','31',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4509ca6b-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','FSBK012-Xan-32','Xanh Navy','32',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('450a749f-a429-11f1-b5ab-6ed8ca3651ef','44f9ee84-a429-11f1-b5ab-6ed8ca3651ef','FSBK012-Xan-33','Xanh Navy','33',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('450ff687-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef','BW600-Äe-29','Äen','29',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4510a503-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef','BW600-Äe-30','Äen','30',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45117b1c-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef','BW600-Äe-31','Äen','31',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('451264e8-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef','BW600-Äe-32','Äen','32',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4515622b-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef','BW600-Äe-33','Äen','33',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('451613ec-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef','BW600-Xan-29','Xanh Navy','29',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4516b2f0-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef','BW600-Xan-30','Xanh Navy','30',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45174f79-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef','BW600-Xan-31','Xanh Navy','31',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4517f3ea-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef','BW600-Xan-32','Xanh Navy','32',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4518c0a3-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef','BW600-Xan-33','Xanh Navy','33',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4519e45b-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef','BW600-XÃ¡-29','XÃ¡m','29',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('451b2019-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef','BW600-XÃ¡-30','XÃ¡m','30',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('451d8f8c-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef','BW600-XÃ¡-31','XÃ¡m','31',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('451e5ed9-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef','BW600-XÃ¡-32','XÃ¡m','32',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('452194cc-a429-11f1-b5ab-6ed8ca3651ef','450dcece-a429-11f1-b5ab-6ed8ca3651ef','BW600-XÃ¡-33','XÃ¡m','33',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('452c49c0-a429-11f1-b5ab-6ed8ca3651ef','45292f7e-a429-11f1-b5ab-6ed8ca3651ef','FSBW001-Äe-29','Äen','29',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('452d042f-a429-11f1-b5ab-6ed8ca3651ef','45292f7e-a429-11f1-b5ab-6ed8ca3651ef','FSBW001-Äe-30','Äen','30',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('452dbf31-a429-11f1-b5ab-6ed8ca3651ef','45292f7e-a429-11f1-b5ab-6ed8ca3651ef','FSBW001-Äe-31','Äen','31',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('452ee6c1-a429-11f1-b5ab-6ed8ca3651ef','45292f7e-a429-11f1-b5ab-6ed8ca3651ef','FSBW001-Äe-32','Äen','32',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('452fa232-a429-11f1-b5ab-6ed8ca3651ef','45292f7e-a429-11f1-b5ab-6ed8ca3651ef','FSBW001-Äe-33','Äen','33',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45305195-a429-11f1-b5ab-6ed8ca3651ef','45292f7e-a429-11f1-b5ab-6ed8ca3651ef','FSBW001-Xan-29','Xanh Navy','29',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45324131-a429-11f1-b5ab-6ed8ca3651ef','45292f7e-a429-11f1-b5ab-6ed8ca3651ef','FSBW001-Xan-30','Xanh Navy','30',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45330873-a429-11f1-b5ab-6ed8ca3651ef','45292f7e-a429-11f1-b5ab-6ed8ca3651ef','FSBW001-Xan-31','Xanh Navy','31',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4533edc7-a429-11f1-b5ab-6ed8ca3651ef','45292f7e-a429-11f1-b5ab-6ed8ca3651ef','FSBW001-Xan-32','Xanh Navy','32',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4534ae12-a429-11f1-b5ab-6ed8ca3651ef','45292f7e-a429-11f1-b5ab-6ed8ca3651ef','FSBW001-Xan-33','Xanh Navy','33',169000.0000,249000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45394b80-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef','FSBK015-Be-29','Be','29',350000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4539ef0e-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef','FSBK015-Be-30','Be','30',350000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('453ab6fe-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef','FSBK015-Be-31','Be','31',350000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('453c037f-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef','FSBK015-Be-32','Be','32',350000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('453cd78a-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef','FSBK015-Be-33','Be','33',350000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('453da7ea-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef','FSBK015-Äe-29','Äen','29',350000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45418735-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef','FSBK015-Äe-30','Äen','30',350000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45425605-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef','FSBK015-Äe-31','Äen','31',350000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4543017d-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef','FSBK015-Äe-32','Äen','32',350000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4543ab99-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef','FSBK015-Äe-33','Äen','33',350000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45445fc7-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef','FSBK015-XÃ¡-29','XÃ¡m','29',350000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45450d58-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef','FSBK015-XÃ¡-30','XÃ¡m','30',350000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4545a872-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef','FSBK015-XÃ¡-31','XÃ¡m','31',350000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45466648-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef','FSBK015-XÃ¡-32','XÃ¡m','32',350000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45471fa2-a429-11f1-b5ab-6ed8ca3651ef','45373472-a429-11f1-b5ab-6ed8ca3651ef','FSBK015-XÃ¡-33','XÃ¡m','33',350000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('454b601a-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef','FSBK010-Be-29','Be','29',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('454c0aa5-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef','FSBK010-Be-30','Be','30',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('454cad6b-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef','FSBK010-Be-31','Be','31',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('454de18a-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef','FSBK010-Be-32','Be','32',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('454e8d5c-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef','FSBK010-Be-33','Be','33',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('454f5651-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef','FSBK010-Äe-29','Äen','29',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('454ff350-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef','FSBK010-Äe-30','Äen','30',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45514ff6-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef','FSBK010-Äe-31','Äen','31',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4552843b-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef','FSBK010-Äe-32','Äen','32',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45533c9a-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef','FSBK010-Äe-33','Äen','33',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4553e786-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef','FSBK010-Xan-29','Xanh Navy','29',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45549dba-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef','FSBK010-Xan-30','Xanh Navy','30',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45555361-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef','FSBK010-Xan-31','Xanh Navy','31',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4556df8d-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef','FSBK010-Xan-32','Xanh Navy','32',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('455892ac-a429-11f1-b5ab-6ed8ca3651ef','4549436c-a429-11f1-b5ab-6ed8ca3651ef','FSBK010-Xan-33','Xanh Navy','33',299000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('455d937c-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef','GABT892-Äe-29','Äen','29',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('455e4ea7-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef','GABT892-Äe-30','Äen','30',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('455ef8cb-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef','GABT892-Äe-31','Äen','31',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45600a9c-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef','GABT892-Äe-32','Äen','32',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4560cf1f-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef','GABT892-Äe-33','Äen','33',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45641890-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef','GABT892-XÃ¡-29','XÃ¡m','29',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4564bdc7-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef','GABT892-XÃ¡-30','XÃ¡m','30',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45659232-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef','GABT892-XÃ¡-31','XÃ¡m','31',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4566730f-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef','GABT892-XÃ¡-32','XÃ¡m','32',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('456794fc-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef','GABT892-XÃ¡-33','XÃ¡m','33',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45690160-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef','GABT892-Xan-29','Xanh Navy','29',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('456b0d0e-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef','GABT892-Xan-30','Xanh Navy','30',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('456bef2e-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef','GABT892-Xan-31','Xanh Navy','31',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('456d1687-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef','GABT892-Xan-32','Xanh Navy','32',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('456e9d11-a429-11f1-b5ab-6ed8ca3651ef','455b462f-a429-11f1-b5ab-6ed8ca3651ef','GABT892-Xan-33','Xanh Navy','33',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45740573-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','GABT891-Äe-29','Äen','29',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4574e233-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','GABT891-Äe-30','Äen','30',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45758a54-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','GABT891-Äe-31','Äen','31',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45762d36-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','GABT891-Äe-32','Äen','32',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45770f42-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','GABT891-Äe-33','Äen','33',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4577b86c-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','GABT891-XÃ¡-29','XÃ¡m','29',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('457852aa-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','GABT891-XÃ¡-30','XÃ¡m','30',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4578f0fb-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','GABT891-XÃ¡-31','XÃ¡m','31',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('457a264e-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','GABT891-XÃ¡-32','XÃ¡m','32',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('457b22c5-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','GABT891-XÃ¡-33','XÃ¡m','33',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('457c2630-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','GABT891-Be-29','Be','29',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('457cb991-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','GABT891-Be-30','Be','30',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('457d7865-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','GABT891-Be-31','Be','31',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('457e1fbe-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','GABT891-Be-32','Be','32',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('457ec6ba-a429-11f1-b5ab-6ed8ca3651ef','4570a4f3-a429-11f1-b5ab-6ed8ca3651ef','GABT891-Be-33','Be','33',649000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45835176-a429-11f1-b5ab-6ed8ca3651ef','4580ed89-a429-11f1-b5ab-6ed8ca3651ef','DABT900-Äe-29','Äen','29',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4584b8a6-a429-11f1-b5ab-6ed8ca3651ef','4580ed89-a429-11f1-b5ab-6ed8ca3651ef','DABT900-Äe-30','Äen','30',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45856a16-a429-11f1-b5ab-6ed8ca3651ef','4580ed89-a429-11f1-b5ab-6ed8ca3651ef','DABT900-Äe-31','Äen','31',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4586087e-a429-11f1-b5ab-6ed8ca3651ef','4580ed89-a429-11f1-b5ab-6ed8ca3651ef','DABT900-Äe-32','Äen','32',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45873b5c-a429-11f1-b5ab-6ed8ca3651ef','4580ed89-a429-11f1-b5ab-6ed8ca3651ef','DABT900-Äe-33','Äen','33',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4587ec3c-a429-11f1-b5ab-6ed8ca3651ef','4580ed89-a429-11f1-b5ab-6ed8ca3651ef','DABT900-XÃ¡-29','XÃ¡m','29',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45893fd0-a429-11f1-b5ab-6ed8ca3651ef','4580ed89-a429-11f1-b5ab-6ed8ca3651ef','DABT900-XÃ¡-30','XÃ¡m','30',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('458a07c7-a429-11f1-b5ab-6ed8ca3651ef','4580ed89-a429-11f1-b5ab-6ed8ca3651ef','DABT900-XÃ¡-31','XÃ¡m','31',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('458acab5-a429-11f1-b5ab-6ed8ca3651ef','4580ed89-a429-11f1-b5ab-6ed8ca3651ef','DABT900-XÃ¡-32','XÃ¡m','32',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('458b871d-a429-11f1-b5ab-6ed8ca3651ef','4580ed89-a429-11f1-b5ab-6ed8ca3651ef','DABT900-XÃ¡-33','XÃ¡m','33',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('458fc5cd-a429-11f1-b5ab-6ed8ca3651ef','458d7ca5-a429-11f1-b5ab-6ed8ca3651ef','EABJ012-Äe-29','Äen','29',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('459088e1-a429-11f1-b5ab-6ed8ca3651ef','458d7ca5-a429-11f1-b5ab-6ed8ca3651ef','EABJ012-Äe-30','Äen','30',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45912b22-a429-11f1-b5ab-6ed8ca3651ef','458d7ca5-a429-11f1-b5ab-6ed8ca3651ef','EABJ012-Äe-31','Äen','31',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4591e370-a429-11f1-b5ab-6ed8ca3651ef','458d7ca5-a429-11f1-b5ab-6ed8ca3651ef','EABJ012-Äe-32','Äen','32',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4592b9d5-a429-11f1-b5ab-6ed8ca3651ef','458d7ca5-a429-11f1-b5ab-6ed8ca3651ef','EABJ012-Äe-33','Äen','33',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('459423f1-a429-11f1-b5ab-6ed8ca3651ef','458d7ca5-a429-11f1-b5ab-6ed8ca3651ef','EABJ012-Xan-29','Xanh Navy','29',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4594eb0f-a429-11f1-b5ab-6ed8ca3651ef','458d7ca5-a429-11f1-b5ab-6ed8ca3651ef','EABJ012-Xan-30','Xanh Navy','30',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45966ce3-a429-11f1-b5ab-6ed8ca3651ef','458d7ca5-a429-11f1-b5ab-6ed8ca3651ef','EABJ012-Xan-31','Xanh Navy','31',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('459755b5-a429-11f1-b5ab-6ed8ca3651ef','458d7ca5-a429-11f1-b5ab-6ed8ca3651ef','EABJ012-Xan-32','Xanh Navy','32',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('459813e3-a429-11f1-b5ab-6ed8ca3651ef','458d7ca5-a429-11f1-b5ab-6ed8ca3651ef','EABJ012-Xan-33','Xanh Navy','33',449000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('459f4fd1-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef','FABK001-Be-29','Be','29',399000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45a05c21-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef','FABK001-Be-30','Be','30',399000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45a0f4d4-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef','FABK001-Be-31','Be','31',399000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45a1c8c0-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef','FABK001-Be-32','Be','32',399000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45a2b1b9-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef','FABK001-Be-33','Be','33',399000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45a370a5-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef','FABK001-Äe-29','Äen','29',399000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45a42dc3-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef','FABK001-Äe-30','Äen','30',399000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45a4cf61-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef','FABK001-Äe-31','Äen','31',399000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45a58c20-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef','FABK001-Äe-32','Äen','32',399000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45a63089-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef','FABK001-Äe-33','Äen','33',399000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45a6f89f-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef','FABK001-XÃ¡-29','XÃ¡m','29',399000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45a818a0-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef','FABK001-XÃ¡-30','XÃ¡m','30',399000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45a8c476-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef','FABK001-XÃ¡-31','XÃ¡m','31',399000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45a983ba-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef','FABK001-XÃ¡-32','XÃ¡m','32',399000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45aa4ca9-a429-11f1-b5ab-6ed8ca3651ef','459abd94-a429-11f1-b5ab-6ed8ca3651ef','FABK001-XÃ¡-33','XÃ¡m','33',399000.0000,650000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45b30385-a429-11f1-b5ab-6ed8ca3651ef','45af322a-a429-11f1-b5ab-6ed8ca3651ef','GABJ302-Äe-29','Äen','29',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45b3ad3e-a429-11f1-b5ab-6ed8ca3651ef','45af322a-a429-11f1-b5ab-6ed8ca3651ef','GABJ302-Äe-30','Äen','30',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45b443fc-a429-11f1-b5ab-6ed8ca3651ef','45af322a-a429-11f1-b5ab-6ed8ca3651ef','GABJ302-Äe-31','Äen','31',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45b4ed2b-a429-11f1-b5ab-6ed8ca3651ef','45af322a-a429-11f1-b5ab-6ed8ca3651ef','GABJ302-Äe-32','Äen','32',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45b5e3a4-a429-11f1-b5ab-6ed8ca3651ef','45af322a-a429-11f1-b5ab-6ed8ca3651ef','GABJ302-Äe-33','Äen','33',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45b7c62b-a429-11f1-b5ab-6ed8ca3651ef','45af322a-a429-11f1-b5ab-6ed8ca3651ef','GABJ302-Xan-29','Xanh Navy','29',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45b8baff-a429-11f1-b5ab-6ed8ca3651ef','45af322a-a429-11f1-b5ab-6ed8ca3651ef','GABJ302-Xan-30','Xanh Navy','30',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45b96282-a429-11f1-b5ab-6ed8ca3651ef','45af322a-a429-11f1-b5ab-6ed8ca3651ef','GABJ302-Xan-31','Xanh Navy','31',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45ba1ef6-a429-11f1-b5ab-6ed8ca3651ef','45af322a-a429-11f1-b5ab-6ed8ca3651ef','GABJ302-Xan-32','Xanh Navy','32',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45bab8f0-a429-11f1-b5ab-6ed8ca3651ef','45af322a-a429-11f1-b5ab-6ed8ca3651ef','GABJ302-Xan-33','Xanh Navy','33',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45c28e3f-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef','GWCW505-Äe-S','Äen','S',899000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45c39c24-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef','GWCW505-Äe-M','Äen','M',899000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45c44d68-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef','GWCW505-Äe-L','Äen','L',899000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45c516e9-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef','GWCW505-Äe-XL','Äen','XL',899000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45c5cec3-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef','GWCW505-Äe-2XL','Äen','2XL',899000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45c8a003-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef','GWCW505-Xan-S','Xanh Navy','S',899000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45c93e7c-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef','GWCW505-Xan-M','Xanh Navy','M',899000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45cc10a0-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef','GWCW505-Xan-L','Xanh Navy','L',899000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45ccce11-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef','GWCW505-Xan-XL','Xanh Navy','XL',899000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45cd673b-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef','GWCW505-Xan-2XL','Xanh Navy','2XL',899000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45ce08c7-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef','GWCW505-XÃ¡-S','XÃ¡m','S',899000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45cf5fd3-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef','GWCW505-XÃ¡-M','XÃ¡m','M',899000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45d013ae-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef','GWCW505-XÃ¡-L','XÃ¡m','L',899000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45d0ff40-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef','GWCW505-XÃ¡-XL','XÃ¡m','XL',899000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45d19ee7-a429-11f1-b5ab-6ed8ca3651ef','45be08bd-a429-11f1-b5ab-6ed8ca3651ef','GWCW505-XÃ¡-2XL','XÃ¡m','2XL',899000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45d6408b-a429-11f1-b5ab-6ed8ca3651ef','45d315eb-a429-11f1-b5ab-6ed8ca3651ef','GWCW051-Äe-S','Äen','S',399000.0000,699000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45d72b63-a429-11f1-b5ab-6ed8ca3651ef','45d315eb-a429-11f1-b5ab-6ed8ca3651ef','GWCW051-Äe-M','Äen','M',399000.0000,699000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45d8334d-a429-11f1-b5ab-6ed8ca3651ef','45d315eb-a429-11f1-b5ab-6ed8ca3651ef','GWCW051-Äe-L','Äen','L',399000.0000,699000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45d9776a-a429-11f1-b5ab-6ed8ca3651ef','45d315eb-a429-11f1-b5ab-6ed8ca3651ef','GWCW051-Äe-XL','Äen','XL',399000.0000,699000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45da1543-a429-11f1-b5ab-6ed8ca3651ef','45d315eb-a429-11f1-b5ab-6ed8ca3651ef','GWCW051-Äe-2XL','Äen','2XL',399000.0000,699000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45db61b5-a429-11f1-b5ab-6ed8ca3651ef','45d315eb-a429-11f1-b5ab-6ed8ca3651ef','GWCW051-Xan-S','Xanh Navy','S',399000.0000,699000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45dc2e7f-a429-11f1-b5ab-6ed8ca3651ef','45d315eb-a429-11f1-b5ab-6ed8ca3651ef','GWCW051-Xan-M','Xanh Navy','M',399000.0000,699000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45dcede8-a429-11f1-b5ab-6ed8ca3651ef','45d315eb-a429-11f1-b5ab-6ed8ca3651ef','GWCW051-Xan-L','Xanh Navy','L',399000.0000,699000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45df019d-a429-11f1-b5ab-6ed8ca3651ef','45d315eb-a429-11f1-b5ab-6ed8ca3651ef','GWCW051-Xan-XL','Xanh Navy','XL',399000.0000,699000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45dfb425-a429-11f1-b5ab-6ed8ca3651ef','45d315eb-a429-11f1-b5ab-6ed8ca3651ef','GWCW051-Xan-2XL','Xanh Navy','2XL',399000.0000,699000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45e4be13-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef','GWCU051-Äe-S','Äen','S',599000.0000,899000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45e5c461-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef','GWCU051-Äe-M','Äen','M',599000.0000,899000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45e66217-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef','GWCU051-Äe-L','Äen','L',599000.0000,899000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45e711fa-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef','GWCU051-Äe-XL','Äen','XL',599000.0000,899000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45e7b506-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef','GWCU051-Äe-2XL','Äen','2XL',599000.0000,899000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45e8571d-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef','GWCU051-NÃ¢-S','NÃ¢u','S',599000.0000,899000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45e8efd1-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef','GWCU051-NÃ¢-M','NÃ¢u','M',599000.0000,899000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45e99cb0-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef','GWCU051-NÃ¢-L','NÃ¢u','L',599000.0000,899000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45eab50a-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef','GWCU051-NÃ¢-XL','NÃ¢u','XL',599000.0000,899000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45ec4ea5-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef','GWCU051-NÃ¢-2XL','NÃ¢u','2XL',599000.0000,899000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45edabaf-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef','GWCU051-Xan-S','Xanh rÃªu','S',599000.0000,899000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45eebd2f-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef','GWCU051-Xan-M','Xanh rÃªu','M',599000.0000,899000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45ef5eb3-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef','GWCU051-Xan-L','Xanh rÃªu','L',599000.0000,899000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45f04a0a-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef','GWCU051-Xan-XL','Xanh rÃªu','XL',599000.0000,899000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45f10c6e-a429-11f1-b5ab-6ed8ca3651ef','45e2510c-a429-11f1-b5ab-6ed8ca3651ef','GWCU051-Xan-2XL','Xanh rÃªu','2XL',599000.0000,899000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45f6537e-a429-11f1-b5ab-6ed8ca3651ef','45f2dcfb-a429-11f1-b5ab-6ed8ca3651ef','GWCJ503-Äe-S','Äen','S',999000.0000,1299000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45f762d4-a429-11f1-b5ab-6ed8ca3651ef','45f2dcfb-a429-11f1-b5ab-6ed8ca3651ef','GWCJ503-Äe-M','Äen','M',999000.0000,1299000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45f886da-a429-11f1-b5ab-6ed8ca3651ef','45f2dcfb-a429-11f1-b5ab-6ed8ca3651ef','GWCJ503-Äe-L','Äen','L',999000.0000,1299000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45f9a7a5-a429-11f1-b5ab-6ed8ca3651ef','45f2dcfb-a429-11f1-b5ab-6ed8ca3651ef','GWCJ503-Äe-XL','Äen','XL',999000.0000,1299000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45fa4c49-a429-11f1-b5ab-6ed8ca3651ef','45f2dcfb-a429-11f1-b5ab-6ed8ca3651ef','GWCJ503-Äe-2XL','Äen','2XL',999000.0000,1299000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45fb18ac-a429-11f1-b5ab-6ed8ca3651ef','45f2dcfb-a429-11f1-b5ab-6ed8ca3651ef','GWCJ503-Be-S','Be','S',999000.0000,1299000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45fbc2a5-a429-11f1-b5ab-6ed8ca3651ef','45f2dcfb-a429-11f1-b5ab-6ed8ca3651ef','GWCJ503-Be-M','Be','M',999000.0000,1299000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45fc7af2-a429-11f1-b5ab-6ed8ca3651ef','45f2dcfb-a429-11f1-b5ab-6ed8ca3651ef','GWCJ503-Be-L','Be','L',999000.0000,1299000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45fd9997-a429-11f1-b5ab-6ed8ca3651ef','45f2dcfb-a429-11f1-b5ab-6ed8ca3651ef','GWCJ503-Be-XL','Be','XL',999000.0000,1299000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('45ff2fa5-a429-11f1-b5ab-6ed8ca3651ef','45f2dcfb-a429-11f1-b5ab-6ed8ca3651ef','GWCJ503-Be-2XL','Be','2XL',999000.0000,1299000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4604b946-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef','GWCL902-Äe-S','Äen','S',799000.0000,1099000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46060204-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef','GWCL902-Äe-M','Äen','M',799000.0000,1099000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4606990f-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef','GWCL902-Äe-L','Äen','L',799000.0000,1099000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46077611-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef','GWCL902-Äe-XL','Äen','XL',799000.0000,1099000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46081f4e-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef','GWCL902-Äe-2XL','Äen','2XL',799000.0000,1099000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46091b2a-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef','GWCL902-NÃ¢-S','NÃ¢u','S',799000.0000,1099000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4609b7b6-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef','GWCL902-NÃ¢-M','NÃ¢u','M',799000.0000,1099000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('460a7b24-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef','GWCL902-NÃ¢-L','NÃ¢u','L',799000.0000,1099000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('460b2fff-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef','GWCL902-NÃ¢-XL','NÃ¢u','XL',799000.0000,1099000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('460bcbe7-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef','GWCL902-NÃ¢-2XL','NÃ¢u','2XL',799000.0000,1099000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('460c7d63-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef','GWCL902-Be-S','Be','S',799000.0000,1099000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('460dc325-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef','GWCL902-Be-M','Be','M',799000.0000,1099000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('460e5d25-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef','GWCL902-Be-L','Be','L',799000.0000,1099000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('460ef4e6-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef','GWCL902-Be-XL','Be','XL',799000.0000,1099000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('460f960c-a429-11f1-b5ab-6ed8ca3651ef','46009d4c-a429-11f1-b5ab-6ed8ca3651ef','GWCL902-Be-2XL','Be','2XL',799000.0000,1099000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4613f7bd-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef','GWCF004-Äe-S','Äen','S',699000.0000,1199000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46158df3-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef','GWCF004-Äe-M','Äen','M',699000.0000,1199000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46163340-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef','GWCF004-Äe-L','Äen','L',699000.0000,1199000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4616d314-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef','GWCF004-Äe-XL','Äen','XL',699000.0000,1199000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('461768a2-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef','GWCF004-Äe-2XL','Äen','2XL',699000.0000,1199000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('461818a2-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef','GWCF004-Xan-S','Xanh Navy','S',699000.0000,1199000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4618ac13-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef','GWCF004-Xan-M','Xanh Navy','M',699000.0000,1199000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46195452-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef','GWCF004-Xan-L','Xanh Navy','L',699000.0000,1199000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('461a866d-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef','GWCF004-Xan-XL','Xanh Navy','XL',699000.0000,1199000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('461b1ed0-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef','GWCF004-Xan-2XL','Xanh Navy','2XL',699000.0000,1199000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('461bfeb4-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef','GWCF004-XÃ¡-S','XÃ¡m','S',699000.0000,1199000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('461ce135-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef','GWCF004-XÃ¡-M','XÃ¡m','M',699000.0000,1199000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('461d7645-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef','GWCF004-XÃ¡-L','XÃ¡m','L',699000.0000,1199000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('461e123f-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef','GWCF004-XÃ¡-XL','XÃ¡m','XL',699000.0000,1199000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('461eac3e-a429-11f1-b5ab-6ed8ca3651ef','4610fb49-a429-11f1-b5ab-6ed8ca3651ef','GWCF004-XÃ¡-2XL','XÃ¡m','2XL',699000.0000,1199000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4622e079-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef','GATB011-Trá-S','Tráº¯ng','S',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('462372f0-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef','GATB011-Trá-M','Tráº¯ng','M',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('462415a5-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef','GATB011-Trá-L','Tráº¯ng','L',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4624afc4-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef','GATB011-Trá-XL','Tráº¯ng','XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46254047-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef','GATB011-Trá-2XL','Tráº¯ng','2XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46266e80-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef','GATB011-Äe-S','Äen','S',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('462746ed-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef','GATB011-Äe-M','Äen','M',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4627e376-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef','GATB011-Äe-L','Äen','L',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('462871e4-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef','GATB011-Äe-XL','Äen','XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4629ae2d-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef','GATB011-Äe-2XL','Äen','2XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('462a62c5-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef','GATB011-Xan-S','Xanh Navy','S',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('462af71d-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef','GATB011-Xan-M','Xanh Navy','M',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('462ba79d-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef','GATB011-Xan-L','Xanh Navy','L',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('462c3e04-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef','GATB011-Xan-XL','Xanh Navy','XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('462db402-a429-11f1-b5ab-6ed8ca3651ef','462079e0-a429-11f1-b5ab-6ed8ca3651ef','GATB011-Xan-2XL','Xanh Navy','2XL',550000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46315bd1-a429-11f1-b5ab-6ed8ca3651ef','462f71fc-a429-11f1-b5ab-6ed8ca3651ef','DATB920-Trá-S','Tráº¯ng','S',210000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46326b83-a429-11f1-b5ab-6ed8ca3651ef','462f71fc-a429-11f1-b5ab-6ed8ca3651ef','DATB920-Trá-M','Tráº¯ng','M',210000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('463305ce-a429-11f1-b5ab-6ed8ca3651ef','462f71fc-a429-11f1-b5ab-6ed8ca3651ef','DATB920-Trá-L','Tráº¯ng','L',210000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46339c85-a429-11f1-b5ab-6ed8ca3651ef','462f71fc-a429-11f1-b5ab-6ed8ca3651ef','DATB920-Trá-XL','Tráº¯ng','XL',210000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('463430e8-a429-11f1-b5ab-6ed8ca3651ef','462f71fc-a429-11f1-b5ab-6ed8ca3651ef','DATB920-Trá-2XL','Tráº¯ng','2XL',210000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4634d1a0-a429-11f1-b5ab-6ed8ca3651ef','462f71fc-a429-11f1-b5ab-6ed8ca3651ef','DATB920-XÃ¡-S','XÃ¡m','S',210000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('463592d6-a429-11f1-b5ab-6ed8ca3651ef','462f71fc-a429-11f1-b5ab-6ed8ca3651ef','DATB920-XÃ¡-M','XÃ¡m','M',210000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('463650a1-a429-11f1-b5ab-6ed8ca3651ef','462f71fc-a429-11f1-b5ab-6ed8ca3651ef','DATB920-XÃ¡-L','XÃ¡m','L',210000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('463718d1-a429-11f1-b5ab-6ed8ca3651ef','462f71fc-a429-11f1-b5ab-6ed8ca3651ef','DATB920-XÃ¡-XL','XÃ¡m','XL',210000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46393bec-a429-11f1-b5ab-6ed8ca3651ef','462f71fc-a429-11f1-b5ab-6ed8ca3651ef','DATB920-XÃ¡-2XL','XÃ¡m','2XL',210000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('463e4d5c-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef','FATB001-Trá-S','Tráº¯ng','S',329000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('463f0f14-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef','FATB001-Trá-M','Tráº¯ng','M',329000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('463fcafb-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef','FATB001-Trá-L','Tráº¯ng','L',329000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('464086cb-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef','FATB001-Trá-XL','Tráº¯ng','XL',329000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46420fdb-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef','FATB001-Trá-2XL','Tráº¯ng','2XL',329000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4642bf67-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef','FATB001-Äe-S','Äen','S',329000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('464397f5-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef','FATB001-Äe-M','Äen','M',329000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46448250-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef','FATB001-Äe-L','Äen','L',329000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46451fc4-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef','FATB001-Äe-XL','Äen','XL',329000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4645d873-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef','FATB001-Äe-2XL','Äen','2XL',329000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46468e26-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef','FATB001-Be-S','Be','S',329000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46472dd4-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef','FATB001-Be-M','Be','M',329000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4647fd9c-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef','FATB001-Be-L','Be','L',329000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46495fbe-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef','FATB001-Be-XL','Be','XL',329000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('464ab9c6-a429-11f1-b5ab-6ed8ca3651ef','463be2df-a429-11f1-b5ab-6ed8ca3651ef','FATB001-Be-2XL','Be','2XL',329000.0000,450000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('464f60cb-a429-11f1-b5ab-6ed8ca3651ef','464ca3d5-a429-11f1-b5ab-6ed8ca3651ef','FATB002-Trá-S','Tráº¯ng','S',349000.0000,500000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('465093a3-a429-11f1-b5ab-6ed8ca3651ef','464ca3d5-a429-11f1-b5ab-6ed8ca3651ef','FATB002-Trá-M','Tráº¯ng','M',349000.0000,500000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('465135a9-a429-11f1-b5ab-6ed8ca3651ef','464ca3d5-a429-11f1-b5ab-6ed8ca3651ef','FATB002-Trá-L','Tráº¯ng','L',349000.0000,500000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4651e147-a429-11f1-b5ab-6ed8ca3651ef','464ca3d5-a429-11f1-b5ab-6ed8ca3651ef','FATB002-Trá-XL','Tráº¯ng','XL',349000.0000,500000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4652afbf-a429-11f1-b5ab-6ed8ca3651ef','464ca3d5-a429-11f1-b5ab-6ed8ca3651ef','FATB002-Trá-2XL','Tráº¯ng','2XL',349000.0000,500000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46536b35-a429-11f1-b5ab-6ed8ca3651ef','464ca3d5-a429-11f1-b5ab-6ed8ca3651ef','FATB002-Xan-S','Xanh Navy','S',349000.0000,500000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46540ae0-a429-11f1-b5ab-6ed8ca3651ef','464ca3d5-a429-11f1-b5ab-6ed8ca3651ef','FATB002-Xan-M','Xanh Navy','M',349000.0000,500000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4656f6d2-a429-11f1-b5ab-6ed8ca3651ef','464ca3d5-a429-11f1-b5ab-6ed8ca3651ef','FATB002-Xan-L','Xanh Navy','L',349000.0000,500000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4657a335-a429-11f1-b5ab-6ed8ca3651ef','464ca3d5-a429-11f1-b5ab-6ed8ca3651ef','FATB002-Xan-XL','Xanh Navy','XL',349000.0000,500000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4658443f-a429-11f1-b5ab-6ed8ca3651ef','464ca3d5-a429-11f1-b5ab-6ed8ca3651ef','FATB002-Xan-2XL','Xanh Navy','2XL',349000.0000,500000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('465d887e-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef','FSTP056-Äe-S','Äen','S',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('465e538e-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef','FSTP056-Äe-M','Äen','M',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('465f29b9-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef','FSTP056-Äe-L','Äen','L',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46605c36-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef','FSTP056-Äe-XL','Äen','XL',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46619f0a-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef','FSTP056-Äe-2XL','Äen','2XL',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4662d97a-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef','FSTP056-XÃ¡-S','XÃ¡m','S',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4663958a-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef','FSTP056-XÃ¡-M','XÃ¡m','M',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('466454bf-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef','FSTP056-XÃ¡-L','XÃ¡m','L',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46655816-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef','FSTP056-XÃ¡-XL','XÃ¡m','XL',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4665fed6-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef','FSTP056-XÃ¡-2XL','XÃ¡m','2XL',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4666ab70-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef','FSTP056-Xan-S','Xanh Navy','S',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46674773-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef','FSTP056-Xan-M','Xanh Navy','M',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4667de7f-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef','FSTP056-Xan-L','Xanh Navy','L',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4668936d-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef','FSTP056-Xan-XL','Xanh Navy','XL',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('466a8320-a429-11f1-b5ab-6ed8ca3651ef','465a34e0-a429-11f1-b5ab-6ed8ca3651ef','FSTP056-Xan-2XL','Xanh Navy','2XL',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('466f2232-a429-11f1-b5ab-6ed8ca3651ef','466c3b3c-a429-11f1-b5ab-6ed8ca3651ef','FSTP046-Äe-S','Äen','S',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46719e2e-a429-11f1-b5ab-6ed8ca3651ef','466c3b3c-a429-11f1-b5ab-6ed8ca3651ef','FSTP046-Äe-M','Äen','M',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46725951-a429-11f1-b5ab-6ed8ca3651ef','466c3b3c-a429-11f1-b5ab-6ed8ca3651ef','FSTP046-Äe-L','Äen','L',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46730a53-a429-11f1-b5ab-6ed8ca3651ef','466c3b3c-a429-11f1-b5ab-6ed8ca3651ef','FSTP046-Äe-XL','Äen','XL',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46742a49-a429-11f1-b5ab-6ed8ca3651ef','466c3b3c-a429-11f1-b5ab-6ed8ca3651ef','FSTP046-Äe-2XL','Äen','2XL',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46752684-a429-11f1-b5ab-6ed8ca3651ef','466c3b3c-a429-11f1-b5ab-6ed8ca3651ef','FSTP046-Xan-S','Xanh Navy','S',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4675e084-a429-11f1-b5ab-6ed8ca3651ef','466c3b3c-a429-11f1-b5ab-6ed8ca3651ef','FSTP046-Xan-M','Xanh Navy','M',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4676f2de-a429-11f1-b5ab-6ed8ca3651ef','466c3b3c-a429-11f1-b5ab-6ed8ca3651ef','FSTP046-Xan-L','Xanh Navy','L',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4677b61a-a429-11f1-b5ab-6ed8ca3651ef','466c3b3c-a429-11f1-b5ab-6ed8ca3651ef','FSTP046-Xan-XL','Xanh Navy','XL',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46788f50-a429-11f1-b5ab-6ed8ca3651ef','466c3b3c-a429-11f1-b5ab-6ed8ca3651ef','FSTP046-Xan-2XL','Xanh Navy','2XL',380000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('467d81f1-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef','GWTW823-Äe-S','Äen','S',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('467eabb1-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef','GWTW823-Äe-M','Äen','M',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('467f89c5-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef','GWTW823-Äe-L','Äen','L',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46804119-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef','GWTW823-Äe-XL','Äen','XL',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46817375-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef','GWTW823-Äe-2XL','Äen','2XL',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4682fb27-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef','GWTW823-XÃ¡-S','XÃ¡m','S',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4683c935-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef','GWTW823-XÃ¡-M','XÃ¡m','M',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46847264-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef','GWTW823-XÃ¡-L','XÃ¡m','L',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46850b03-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef','GWTW823-XÃ¡-XL','XÃ¡m','XL',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46872cfd-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef','GWTW823-XÃ¡-2XL','XÃ¡m','2XL',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4688eaa2-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef','GWTW823-Xan-S','Xanh Navy','S',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46899a9e-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef','GWTW823-Xan-M','Xanh Navy','M',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('468ab600-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef','GWTW823-Xan-L','Xanh Navy','L',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('468b7c6d-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef','GWTW823-Xan-XL','Xanh Navy','XL',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('468dc9c5-a429-11f1-b5ab-6ed8ca3651ef','467b9211-a429-11f1-b5ab-6ed8ca3651ef','GWTW823-Xan-2XL','Xanh Navy','2XL',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46928730-a429-11f1-b5ab-6ed8ca3651ef','469040b1-a429-11f1-b5ab-6ed8ca3651ef','GWTW824-Äe-S','Äen','S',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46939263-a429-11f1-b5ab-6ed8ca3651ef','469040b1-a429-11f1-b5ab-6ed8ca3651ef','GWTW824-Äe-M','Äen','M',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46943a07-a429-11f1-b5ab-6ed8ca3651ef','469040b1-a429-11f1-b5ab-6ed8ca3651ef','GWTW824-Äe-L','Äen','L',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('469603f0-a429-11f1-b5ab-6ed8ca3651ef','469040b1-a429-11f1-b5ab-6ed8ca3651ef','GWTW824-Äe-XL','Äen','XL',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4696c2f5-a429-11f1-b5ab-6ed8ca3651ef','469040b1-a429-11f1-b5ab-6ed8ca3651ef','GWTW824-Äe-2XL','Äen','2XL',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4697c3c7-a429-11f1-b5ab-6ed8ca3651ef','469040b1-a429-11f1-b5ab-6ed8ca3651ef','GWTW824-Xan-S','Xanh Navy','S',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46985cc7-a429-11f1-b5ab-6ed8ca3651ef','469040b1-a429-11f1-b5ab-6ed8ca3651ef','GWTW824-Xan-M','Xanh Navy','M',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4698f93d-a429-11f1-b5ab-6ed8ca3651ef','469040b1-a429-11f1-b5ab-6ed8ca3651ef','GWTW824-Xan-L','Xanh Navy','L',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('4699c9ed-a429-11f1-b5ab-6ed8ca3651ef','469040b1-a429-11f1-b5ab-6ed8ca3651ef','GWTW824-Xan-XL','Xanh Navy','XL',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('469a9633-a429-11f1-b5ab-6ed8ca3651ef','469040b1-a429-11f1-b5ab-6ed8ca3651ef','GWTW824-Xan-2XL','Xanh Navy','2XL',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('469ffeb5-a429-11f1-b5ab-6ed8ca3651ef','469cdedd-a429-11f1-b5ab-6ed8ca3651ef','GWTW826-Äe-S','Äen','S',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46a0fedb-a429-11f1-b5ab-6ed8ca3651ef','469cdedd-a429-11f1-b5ab-6ed8ca3651ef','GWTW826-Äe-M','Äen','M',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46a43afc-a429-11f1-b5ab-6ed8ca3651ef','469cdedd-a429-11f1-b5ab-6ed8ca3651ef','GWTW826-Äe-L','Äen','L',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46a4ddf2-a429-11f1-b5ab-6ed8ca3651ef','469cdedd-a429-11f1-b5ab-6ed8ca3651ef','GWTW826-Äe-XL','Äen','XL',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46a576be-a429-11f1-b5ab-6ed8ca3651ef','469cdedd-a429-11f1-b5ab-6ed8ca3651ef','GWTW826-Äe-2XL','Äen','2XL',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46a71ec9-a429-11f1-b5ab-6ed8ca3651ef','469cdedd-a429-11f1-b5ab-6ed8ca3651ef','GWTW826-XÃ¡-S','XÃ¡m','S',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46a7c47d-a429-11f1-b5ab-6ed8ca3651ef','469cdedd-a429-11f1-b5ab-6ed8ca3651ef','GWTW826-XÃ¡-M','XÃ¡m','M',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46a89eca-a429-11f1-b5ab-6ed8ca3651ef','469cdedd-a429-11f1-b5ab-6ed8ca3651ef','GWTW826-XÃ¡-L','XÃ¡m','L',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46a939ea-a429-11f1-b5ab-6ed8ca3651ef','469cdedd-a429-11f1-b5ab-6ed8ca3651ef','GWTW826-XÃ¡-XL','XÃ¡m','XL',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46a9d1a2-a429-11f1-b5ab-6ed8ca3651ef','469cdedd-a429-11f1-b5ab-6ed8ca3651ef','GWTW826-XÃ¡-2XL','XÃ¡m','2XL',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46aee405-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','GWTW901-Äe-S','Äen','S',399000.0000,599000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46afa309-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','GWTW901-Äe-M','Äen','M',399000.0000,599000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46b071f1-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','GWTW901-Äe-L','Äen','L',399000.0000,599000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46b12000-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','GWTW901-Äe-XL','Äen','XL',399000.0000,599000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46b22c57-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','GWTW901-Äe-2XL','Äen','2XL',399000.0000,599000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46b35989-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','GWTW901-XÃ¡-S','XÃ¡m','S',399000.0000,599000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46b450e6-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','GWTW901-XÃ¡-M','XÃ¡m','M',399000.0000,599000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46b54eea-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','GWTW901-XÃ¡-L','XÃ¡m','L',399000.0000,599000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46b64603-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','GWTW901-XÃ¡-XL','XÃ¡m','XL',399000.0000,599000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46b70d08-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','GWTW901-XÃ¡-2XL','XÃ¡m','2XL',399000.0000,599000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46b87341-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','GWTW901-Xan-S','Xanh Navy','S',399000.0000,599000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46b95b6a-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','GWTW901-Xan-M','Xanh Navy','M',399000.0000,599000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46b9faff-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','GWTW901-Xan-L','Xanh Navy','L',399000.0000,599000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46bb569a-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','GWTW901-Xan-XL','Xanh Navy','XL',399000.0000,599000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46bd2a5c-a429-11f1-b5ab-6ed8ca3651ef','46ac47c4-a429-11f1-b5ab-6ed8ca3651ef','GWTW901-Xan-2XL','Xanh Navy','2XL',399000.0000,599000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46c0d6bd-a429-11f1-b5ab-6ed8ca3651ef','46bed247-a429-11f1-b5ab-6ed8ca3651ef','FWTW001-Äe-S','Äen','S',319000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46c1d52a-a429-11f1-b5ab-6ed8ca3651ef','46bed247-a429-11f1-b5ab-6ed8ca3651ef','FWTW001-Äe-M','Äen','M',319000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46c26f3c-a429-11f1-b5ab-6ed8ca3651ef','46bed247-a429-11f1-b5ab-6ed8ca3651ef','FWTW001-Äe-L','Äen','L',319000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46c376a4-a429-11f1-b5ab-6ed8ca3651ef','46bed247-a429-11f1-b5ab-6ed8ca3651ef','FWTW001-Äe-XL','Äen','XL',319000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46c434ef-a429-11f1-b5ab-6ed8ca3651ef','46bed247-a429-11f1-b5ab-6ed8ca3651ef','FWTW001-Äe-2XL','Äen','2XL',319000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46c4f346-a429-11f1-b5ab-6ed8ca3651ef','46bed247-a429-11f1-b5ab-6ed8ca3651ef','FWTW001-XÃ¡-S','XÃ¡m','S',319000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46c5cd9a-a429-11f1-b5ab-6ed8ca3651ef','46bed247-a429-11f1-b5ab-6ed8ca3651ef','FWTW001-XÃ¡-M','XÃ¡m','M',319000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46c6c2c0-a429-11f1-b5ab-6ed8ca3651ef','46bed247-a429-11f1-b5ab-6ed8ca3651ef','FWTW001-XÃ¡-L','XÃ¡m','L',319000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46c807e7-a429-11f1-b5ab-6ed8ca3651ef','46bed247-a429-11f1-b5ab-6ed8ca3651ef','FWTW001-XÃ¡-XL','XÃ¡m','XL',319000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46c8b926-a429-11f1-b5ab-6ed8ca3651ef','46bed247-a429-11f1-b5ab-6ed8ca3651ef','FWTW001-XÃ¡-2XL','XÃ¡m','2XL',319000.0000,420000.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46cd4cd6-a429-11f1-b5ab-6ed8ca3651ef','46ca86cf-a429-11f1-b5ab-6ed8ca3651ef','FWTW002-Äe-S','Äen','S',650000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46cdea76-a429-11f1-b5ab-6ed8ca3651ef','46ca86cf-a429-11f1-b5ab-6ed8ca3651ef','FWTW002-Äe-M','Äen','M',650000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46ce875c-a429-11f1-b5ab-6ed8ca3651ef','46ca86cf-a429-11f1-b5ab-6ed8ca3651ef','FWTW002-Äe-L','Äen','L',650000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46cf3984-a429-11f1-b5ab-6ed8ca3651ef','46ca86cf-a429-11f1-b5ab-6ed8ca3651ef','FWTW002-Äe-XL','Äen','XL',650000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46d0abf1-a429-11f1-b5ab-6ed8ca3651ef','46ca86cf-a429-11f1-b5ab-6ed8ca3651ef','FWTW002-Äe-2XL','Äen','2XL',650000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46d17cc8-a429-11f1-b5ab-6ed8ca3651ef','46ca86cf-a429-11f1-b5ab-6ed8ca3651ef','FWTW002-Xan-S','Xanh Navy','S',650000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46d411dc-a429-11f1-b5ab-6ed8ca3651ef','46ca86cf-a429-11f1-b5ab-6ed8ca3651ef','FWTW002-Xan-M','Xanh Navy','M',650000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46d4cd7f-a429-11f1-b5ab-6ed8ca3651ef','46ca86cf-a429-11f1-b5ab-6ed8ca3651ef','FWTW002-Xan-L','Xanh Navy','L',650000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46d5be24-a429-11f1-b5ab-6ed8ca3651ef','46ca86cf-a429-11f1-b5ab-6ed8ca3651ef','FWTW002-Xan-XL','Xanh Navy','XL',650000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46d66f67-a429-11f1-b5ab-6ed8ca3651ef','46ca86cf-a429-11f1-b5ab-6ed8ca3651ef','FWTW002-Xan-2XL','Xanh Navy','2XL',650000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46dc1749-a429-11f1-b5ab-6ed8ca3651ef','46d87e87-a429-11f1-b5ab-6ed8ca3651ef','GAAL002-Äe-Freesize','Äen','Freesize',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46dcd904-a429-11f1-b5ab-6ed8ca3651ef','46d87e87-a429-11f1-b5ab-6ed8ca3651ef','GAAL002-NÃ¢-Freesize','NÃ¢u','Freesize',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46e0d865-a429-11f1-b5ab-6ed8ca3651ef','46de937c-a429-11f1-b5ab-6ed8ca3651ef','GAAL003-Äe-Freesize','Äen','Freesize',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46e1f105-a429-11f1-b5ab-6ed8ca3651ef','46de937c-a429-11f1-b5ab-6ed8ca3651ef','GAAL003-NÃ¢-Freesize','NÃ¢u','Freesize',599000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46e6a68d-a429-11f1-b5ab-6ed8ca3651ef','46e49990-a429-11f1-b5ab-6ed8ca3651ef','GAAL007-Äe-Freesize','Äen','Freesize',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46ea26dd-a429-11f1-b5ab-6ed8ca3651ef','46e7feab-a429-11f1-b5ab-6ed8ca3651ef','GAAL015-Äe-Freesize','Äen','Freesize',799000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46eb6422-a429-11f1-b5ab-6ed8ca3651ef','46e7feab-a429-11f1-b5ab-6ed8ca3651ef','GAAL015-NÃ¢-Freesize','NÃ¢u','Freesize',799000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46f0f703-a429-11f1-b5ab-6ed8ca3651ef','46ece6cc-a429-11f1-b5ab-6ed8ca3651ef','GAAL016-Äe-Freesize','Äen','Freesize',799000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46f46c30-a429-11f1-b5ab-6ed8ca3651ef','46f26246-a429-11f1-b5ab-6ed8ca3651ef','GAAL012-Äe-Freesize','Äen','Freesize',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('46f5d2bb-a429-11f1-b5ab-6ed8ca3651ef','46f26246-a429-11f1-b5ab-6ed8ca3651ef','GAAL012-NÃ¢-Freesize','NÃ¢u','Freesize',699000.0000,0.0000,0.0000,0.0000,NULL,1,NULL,NULL),('v0000000-0000-0000-0000-000000000001','p0000000-0000-0000-0000-000000000001','AT001-DEN-M','Den','M',299000.0000,0.0000,120000.0000,250.0000,NULL,1,'ff4e0701-a41d-11f1-b0a9-762043079894','ff4fceef-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000002','p0000000-0000-0000-0000-000000000001','AT001-DEN-L','Den','L',299000.0000,0.0000,120000.0000,260.0000,NULL,1,'ff4e0701-a41d-11f1-b0a9-762043079894','ff4fcf33-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000003','p0000000-0000-0000-0000-000000000001','AT001-TRANG-M','Trang','M',299000.0000,0.0000,120000.0000,250.0000,NULL,1,'ff4e0bae-a41d-11f1-b0a9-762043079894','ff4fceef-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000004','p0000000-0000-0000-0000-000000000002','AT002-DEN-XL','Den','XL',250000.0000,0.0000,100000.0000,280.0000,NULL,1,'ff4e0701-a41d-11f1-b0a9-762043079894','ff4fcf40-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000005','p0000000-0000-0000-0000-000000000002','AT002-KEM-XL','Kem','XL',250000.0000,0.0000,100000.0000,280.0000,NULL,1,'ff4e0cdb-a41d-11f1-b0a9-762043079894','ff4fcf40-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000006','p0000000-0000-0000-0000-000000000003','SM001-TRANG-M','Trang','M',450000.0000,0.0000,180000.0000,200.0000,NULL,1,'ff4e0bae-a41d-11f1-b0a9-762043079894','ff4fceef-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000007','p0000000-0000-0000-0000-000000000003','SM001-TRANG-L','Trang','L',450000.0000,0.0000,180000.0000,210.0000,NULL,1,'ff4e0bae-a41d-11f1-b0a9-762043079894','ff4fcf33-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000008','p0000000-0000-0000-0000-000000000004','SM002-DO-M','Do Ca Ro','M',380000.0000,0.0000,150000.0000,300.0000,NULL,1,'ff4e0d4d-a41d-11f1-b0a9-762043079894','ff4fceef-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000009','p0000000-0000-0000-0000-000000000004','SM002-XANH-L','Xanh Ca Ro','L',380000.0000,0.0000,150000.0000,310.0000,NULL,1,'ff4e0daa-a41d-11f1-b0a9-762043079894','ff4fcf33-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000010','p0000000-0000-0000-0000-000000000005','QJ001-XDAM-30','Xanh Dam','30',550000.0000,0.0000,220000.0000,500.0000,NULL,1,'ff4e0e08-a41d-11f1-b0a9-762043079894','ff50e49c-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000011','p0000000-0000-0000-0000-000000000005','QJ001-XDAM-32','Xanh Dam','32',550000.0000,0.0000,220000.0000,520.0000,NULL,1,'ff4e0e08-a41d-11f1-b0a9-762043079894','ff50e4a6-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000012','p0000000-0000-0000-0000-000000000006','QJ002-XNHE-26','Xanh Nhe','26',490000.0000,0.0000,200000.0000,460.0000,NULL,1,'ff4e0e54-a41d-11f1-b0a9-762043079894','ff50e449-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000013','p0000000-0000-0000-0000-000000000006','QJ002-XNHE-28','Xanh Nhe','28',490000.0000,0.0000,200000.0000,470.0000,NULL,1,'ff4e0e54-a41d-11f1-b0a9-762043079894','ff50e48e-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000014','p0000000-0000-0000-0000-000000000007','AK001-DEN-L','Den','L',890000.0000,0.0000,350000.0000,650.0000,NULL,1,'ff4e0701-a41d-11f1-b0a9-762043079894','ff4fcf33-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000015','p0000000-0000-0000-0000-000000000007','AK001-NAU-L','Nau','L',890000.0000,0.0000,350000.0000,650.0000,NULL,1,'ff4e0ea0-a41d-11f1-b0a9-762043079894','ff4fcf33-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000016','p0000000-0000-0000-0000-000000000008','AK002-XAM-M','Xam','M',350000.0000,0.0000,140000.0000,400.0000,NULL,1,'ff4e0efb-a41d-11f1-b0a9-762043079894','ff4fceef-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000017','p0000000-0000-0000-0000-000000000008','AK002-DEN-L','Den','L',350000.0000,0.0000,140000.0000,420.0000,NULL,1,'ff4e0701-a41d-11f1-b0a9-762043079894','ff4fcf33-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000018','p0000000-0000-0000-0000-000000000009','PK001-DEN-110','Den','110cm',320000.0000,0.0000,130000.0000,200.0000,NULL,1,'ff4e0701-a41d-11f1-b0a9-762043079894','ff51b8cc-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000019','p0000000-0000-0000-0000-000000000009','PK001-NAU-110','Nau','110cm',320000.0000,0.0000,130000.0000,200.0000,NULL,1,'ff4e0ea0-a41d-11f1-b0a9-762043079894','ff51b8cc-a41d-11f1-b0a9-762043079894'),('v0000000-0000-0000-0000-000000000020','p0000000-0000-0000-0000-000000000010','PK002-DEN','Den',NULL,200000.0000,0.0000,80000.0000,100.0000,NULL,1,'ff4e0701-a41d-11f1-b0a9-762043079894',NULL),('v0000000-0000-0000-0000-000000000021','p0000000-0000-0000-0000-000000000010','PK002-NAU','Nau',NULL,200000.0000,0.0000,80000.0000,100.0000,NULL,1,'ff4e0ea0-a41d-11f1-b0a9-762043079894',NULL);
/*!40000 ALTER TABLE `cat_product_variant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_size`
--

DROP TABLE IF EXISTS `cat_size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_size` (
  `cat_size_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID gia tri size',
  `cat_size_group_id` char(36) NOT NULL COMMENT 'FK nhom size',
  `cat_size_value` varchar(50) NOT NULL COMMENT 'Gia tri size (S, M, L, XL, 39, 40...)',
  `cat_size_sort` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Thu tu sap xep trong nhom',
  `cat_size_status` tinyint NOT NULL DEFAULT '1' COMMENT '0: An, 1: Active',
  PRIMARY KEY (`cat_size_id`),
  UNIQUE KEY `uix_catsize_group_value` (`cat_size_group_id`,`cat_size_value`),
  KEY `ix_catsize_catsizegroupid` (`cat_size_group_id`),
  CONSTRAINT `fk_catsize_catsizegroup` FOREIGN KEY (`cat_size_group_id`) REFERENCES `cat_size_group` (`cat_size_group_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Gia tri kich thuoc cu the (normalize tu cat_size_group JSON)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_size`
--

LOCK TABLES `cat_size` WRITE;
/*!40000 ALTER TABLE `cat_size` DISABLE KEYS */;
INSERT INTO `cat_size` VALUES ('440cc5e3-a429-11f1-b5ab-6ed8ca3651ef','440ab7d4-a429-11f1-b5ab-6ed8ca3651ef','S',1.0000,1),('440cc61f-a429-11f1-b5ab-6ed8ca3651ef','440ab7d4-a429-11f1-b5ab-6ed8ca3651ef','M',2.0000,1),('440cc639-a429-11f1-b5ab-6ed8ca3651ef','440ab7d4-a429-11f1-b5ab-6ed8ca3651ef','L',3.0000,1),('440cc657-a429-11f1-b5ab-6ed8ca3651ef','440ab7d4-a429-11f1-b5ab-6ed8ca3651ef','XL',4.0000,1),('440cc670-a429-11f1-b5ab-6ed8ca3651ef','440ab7d4-a429-11f1-b5ab-6ed8ca3651ef','2XL',5.0000,1),('440de4f2-a429-11f1-b5ab-6ed8ca3651ef','440b615d-a429-11f1-b5ab-6ed8ca3651ef','29',1.0000,1),('440de51b-a429-11f1-b5ab-6ed8ca3651ef','440b615d-a429-11f1-b5ab-6ed8ca3651ef','30',2.0000,1),('440de531-a429-11f1-b5ab-6ed8ca3651ef','440b615d-a429-11f1-b5ab-6ed8ca3651ef','31',3.0000,1),('440de546-a429-11f1-b5ab-6ed8ca3651ef','440b615d-a429-11f1-b5ab-6ed8ca3651ef','32',4.0000,1),('440de559-a429-11f1-b5ab-6ed8ca3651ef','440b615d-a429-11f1-b5ab-6ed8ca3651ef','33',5.0000,1),('44104362-a429-11f1-b5ab-6ed8ca3651ef','440c0867-a429-11f1-b5ab-6ed8ca3651ef','Freesize',1.0000,1),('ff4fceef-a41d-11f1-b0a9-762043079894','ff4f0cf8-a41d-11f1-b0a9-762043079894','M',1.0000,1),('ff4fcf33-a41d-11f1-b0a9-762043079894','ff4f0cf8-a41d-11f1-b0a9-762043079894','L',2.0000,1),('ff4fcf40-a41d-11f1-b0a9-762043079894','ff4f0cf8-a41d-11f1-b0a9-762043079894','XL',3.0000,1),('ff50e449-a41d-11f1-b0a9-762043079894','ff4f1056-a41d-11f1-b0a9-762043079894','26',1.0000,1),('ff50e48e-a41d-11f1-b0a9-762043079894','ff4f1056-a41d-11f1-b0a9-762043079894','28',2.0000,1),('ff50e49c-a41d-11f1-b0a9-762043079894','ff4f1056-a41d-11f1-b0a9-762043079894','30',3.0000,1),('ff50e4a6-a41d-11f1-b0a9-762043079894','ff4f1056-a41d-11f1-b0a9-762043079894','32',4.0000,1),('ff51b8cc-a41d-11f1-b0a9-762043079894','ff4f114f-a41d-11f1-b0a9-762043079894','110cm',1.0000,1);
/*!40000 ALTER TABLE `cat_size` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_size_group`
--

DROP TABLE IF EXISTS `cat_size_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cat_size_group` (
  `cat_size_group_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID nhom size',
  `cat_size_group_name` varchar(100) NOT NULL COMMENT 'Ten nhom (Ao, Quan, Giay)',
  `cat_size_group_values` text NOT NULL COMMENT 'JSON array cac gia tri size ["S","M","L","XL"]',
  `cat_size_group_guide` text COMMENT 'Huong dan chon size (HTML)',
  `cat_size_group_sort` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Thu tu',
  PRIMARY KEY (`cat_size_group_id`),
  UNIQUE KEY `uix_catsizegroup_catsizegroupname` (`cat_size_group_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Nhom kich thuoc san pham';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_size_group`
--

LOCK TABLES `cat_size_group` WRITE;
/*!40000 ALTER TABLE `cat_size_group` DISABLE KEYS */;
INSERT INTO `cat_size_group` VALUES ('440ab7d4-a429-11f1-b5ab-6ed8ca3651ef','Ão Nam','[\"S\",\"M\",\"L\",\"XL\",\"2XL\"]',NULL,1.0000),('440b615d-a429-11f1-b5ab-6ed8ca3651ef','Quáº§n Nam','[\"29\",\"30\",\"31\",\"32\",\"33\"]',NULL,2.0000),('440c0867-a429-11f1-b5ab-6ed8ca3651ef','Freesize','[\"Freesize\"]',NULL,3.0000),('ff4f0cf8-a41d-11f1-b0a9-762043079894','Quan Ao','[\"M\",\"L\",\"XL\"]',NULL,1.0000),('ff4f1056-a41d-11f1-b0a9-762043079894','Quan So','[\"26\",\"28\",\"30\",\"32\"]',NULL,2.0000),('ff4f114f-a41d-11f1-b0a9-762043079894','Ao Dai','[\"110cm\"]',NULL,3.0000);
/*!40000 ALTER TABLE `cat_size_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_banner`
--

DROP TABLE IF EXISTS `cms_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cms_banner` (
  `cms_banner_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toan cuc cua Banner',
  `cms_banner_title` varchar(255) NOT NULL COMMENT 'Ten banner noi bo',
  `cms_banner_image_desktop` varchar(255) NOT NULL COMMENT 'Duong dan anh desktop (1440x600)',
  `cms_banner_image_mobile` varchar(255) NOT NULL COMMENT 'Duong dan anh mobile (768x500)',
  `cms_banner_alt` varchar(255) DEFAULT NULL COMMENT 'Alt text SEO',
  `cms_banner_link` varchar(255) DEFAULT NULL COMMENT 'URL redirect khi click',
  `cms_banner_cta_text` varchar(100) DEFAULT NULL COMMENT 'Text nut CTA',
  `cms_banner_sort` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Thu tu hien thi',
  `cms_banner_start_date` datetime DEFAULT NULL COMMENT 'Ngay bat dau hien thi',
  `cms_banner_end_date` datetime DEFAULT NULL COMMENT 'Ngay ket thuc hien thi (NULL = vinh vien)',
  `cms_banner_status` tinyint NOT NULL DEFAULT '1' COMMENT 'Trang thai: 0: An, 1: Hien thi, 2: Scheduled',
  `cms_banner_ab_variant` char(1) DEFAULT NULL COMMENT 'Phien ban A/B test: NULL / A / B',
  `cms_banner_ab_group_id` char(36) DEFAULT NULL COMMENT 'Group ID chung cho 2 banner A/B',
  `cms_banner_click_count` int NOT NULL DEFAULT '0' COMMENT 'So luot click',
  `cms_banner_view_count` int NOT NULL DEFAULT '0' COMMENT 'So luot impression',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay tao',
  PRIMARY KEY (`cms_banner_id`),
  KEY `ix_cmsbanner_status` (`cms_banner_status`),
  KEY `ix_cmsbanner_abgroupid` (`cms_banner_ab_group_id`),
  KEY `ix_cmsbanner_sort` (`cms_banner_sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Quan ly Banner quang cao tren Storefront';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_banner`
--

LOCK TABLES `cms_banner` WRITE;
/*!40000 ALTER TABLE `cms_banner` DISABLE KEYS */;
INSERT INTO `cms_banner` VALUES ('46f72f6c-a429-11f1-b5ab-6ed8ca3651ef','Back In Form','/images/theme/slide_1_img.jpg','/images/theme/slide_1_mb.jpg','Back In Form','/san-pham','KHÃM PHÃ NGAY',1.0000,NULL,NULL,1,NULL,NULL,0,0,'2026-08-30 04:14:21'),('46f77974-a429-11f1-b5ab-6ed8ca3651ef','Embrace Holiday','/images/theme/slide_2_img.jpg','/images/theme/slide_2_mb.jpg','FW Collection 2026','/danh-muc/ao-khoac','XEM BST',2.0000,NULL,NULL,1,NULL,NULL,0,0,'2026-08-30 04:14:21'),('46f77cc6-a429-11f1-b5ab-6ed8ca3651ef','Sale LÃªn Äáº¿n 50%','/images/theme/slide_3_img.jpg','/images/theme/slide_3_mb.jpg','Sale 50%','/danh-muc/ao-polo','MUA NGAY',3.0000,NULL,NULL,1,NULL,NULL,0,0,'2026-08-30 04:14:21'),('46f77dc9-a429-11f1-b5ab-6ed8ca3651ef','Lookbook For Men','/images/theme/slide_4_img.jpg','/images/theme/slide_4_mb.jpg','Lookbook For Men','/san-pham','KHÃM PHÃ',4.0000,NULL,NULL,1,NULL,NULL,0,0,'2026-08-30 04:14:21'),('bn-0000-0000-0000-000000000001','BST Xuan He 2026','/images/banner/banner-1-desktop.jpg','/images/banner/banner-1-mobile.jpg','Bo suu tap xuan he 2026','/danh-muc/ao-thun','Kham pha ngay',1.0000,NULL,NULL,1,NULL,NULL,0,0,'2026-08-30 02:53:31'),('bn-0000-0000-0000-000000000002','Flash Sale Cuoi Tuan','/images/banner/banner-2-desktop.jpg','/images/banner/banner-2-mobile.jpg','Flash sale cuoi tuan giam den 50%','/san-pham?sale=1','Mua ngay',2.0000,NULL,NULL,1,NULL,NULL,0,0,'2026-08-30 02:53:31'),('bn-0000-0000-0000-000000000003','Ao Khoac Mua Dong','/images/banner/banner-3-desktop.jpg','/images/banner/banner-3-mobile.jpg','Ao khoac mua dong giam 40%','/danh-muc/ao-khoac','Xem bo suu tap',3.0000,NULL,NULL,1,NULL,NULL,0,0,'2026-08-30 02:53:31');
/*!40000 ALTER TABLE `cms_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_email_template`
--

DROP TABLE IF EXISTS `cms_email_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cms_email_template` (
  `cms_email_template_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toan cuc cua Email Template',
  `cms_email_template_key` varchar(50) NOT NULL COMMENT 'Key: order_confirmation, welcome, password_reset, ...',
  `cms_email_template_subject` varchar(255) NOT NULL COMMENT 'Subject line email',
  `cms_email_template_body` text NOT NULL COMMENT 'Noi dung HTML body (co the chua {{variables}})',
  `cms_email_template_variables` json DEFAULT NULL COMMENT 'Metadata cac variables kha dung: [{key, label, sample}]',
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Lan cap nhat cuoi',
  PRIMARY KEY (`cms_email_template_id`),
  UNIQUE KEY `uix_cmsemailtemplate_key` (`cms_email_template_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Mau email tu dong gui theo su kien he thong';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_email_template`
--

LOCK TABLES `cms_email_template` WRITE;
/*!40000 ALTER TABLE `cms_email_template` DISABLE KEYS */;
INSERT INTO `cms_email_template` VALUES ('fbf31f98-a41d-11f1-b0a9-762043079894','welcome','Chao mung ban den voi FashionEcom!','<h2>Xin chao {{customer_name}},</h2><p>Cam on ban da dang ky tai khoan tai FashionEcom.</p>','[{\"key\": \"customer_name\", \"label\": \"Ten khach hang\", \"sample\": \"Nguyen Van A\"}]','2026-08-30 02:53:31'),('fbf32534-a41d-11f1-b0a9-762043079894','order_confirmation','Xac nhan don hang #{{order_code}}','<h2>Don hang cua ban da duoc tiep nhan</h2><p>Ma don: <strong>{{order_code}}</strong></p><p>Tong tien: {{order_total}}</p>','[{\"key\": \"order_code\", \"label\": \"Ma don hang\", \"sample\": \"ORD-001\"}, {\"key\": \"order_total\", \"label\": \"Tong tien\", \"sample\": \"500,000Ä‘\"}]','2026-08-30 02:53:31'),('fbf3278b-a41d-11f1-b0a9-762043079894','order_shipped','Don hang #{{order_code}} dang duoc giao','<h2>Don hang cua ban da duoc gui di</h2><p>Ma van don: <strong>{{tracking_code}}</strong></p>','[{\"key\": \"order_code\", \"label\": \"Ma don hang\", \"sample\": \"ORD-001\"}, {\"key\": \"tracking_code\", \"label\": \"Ma van don\", \"sample\": \"GHN123456\"}]','2026-08-30 02:53:31'),('fbf3288d-a41d-11f1-b0a9-762043079894','order_delivered','Don hang #{{order_code}} da giao thanh cong','<h2>Don hang cua ban da giao thanh cong!</h2><p>Hay danh gia san pham de nhan diem thuong.</p>','[{\"key\": \"order_code\", \"label\": \"Ma don hang\", \"sample\": \"ORD-001\"}]','2026-08-30 02:53:31'),('fbf32968-a41d-11f1-b0a9-762043079894','password_reset','Dat lai mat khau FashionEcom','<h2>Dat lai mat khau</h2><p>Click vao link ben duoi de dat lai mat khau:</p><p><a href=\"{{reset_link}}\">Dat lai mat khau</a></p>','[{\"key\": \"reset_link\", \"label\": \"Link dat lai\", \"sample\": \"https://fashionecom.vn/reset?token=xxx\"}]','2026-08-30 02:53:31'),('fbf32a47-a41d-11f1-b0a9-762043079894','order_cancelled','Don hang #{{order_code}} da bi huy','<h2>Don hang cua ban da bi huy</h2><p>Ly do: {{cancel_reason}}</p>','[{\"key\": \"order_code\", \"label\": \"Ma don hang\", \"sample\": \"ORD-001\"}, {\"key\": \"cancel_reason\", \"label\": \"Ly do huy\", \"sample\": \"Khach yeu cau huy\"}]','2026-08-30 02:53:31'),('fbf32b50-a41d-11f1-b0a9-762043079894','flash_sale_notify','Flash Sale bat dau!','<h2>{{sale_title}}</h2><p>Giam den {{max_discount}}% â€” chi tu {{start_time}} den {{end_time}}!</p>','[{\"key\": \"sale_title\", \"label\": \"Ten flash sale\", \"sample\": \"Flash Sale Thu 6\"}, {\"key\": \"max_discount\", \"label\": \"% giam toi da\", \"sample\": \"50\"}, {\"key\": \"start_time\", \"label\": \"Gio bat dau\", \"sample\": \"12:00\"}, {\"key\": \"end_time\", \"label\": \"Gio ket thuc\", \"sample\": \"14:00\"}]','2026-08-30 02:53:31'),('fbf32c6d-a41d-11f1-b0a9-762043079894','discount_code','Ma giam gia danh rieng cho ban!','<h2>Ban nhan duoc ma giam gia!</h2><p>Ma: <strong>{{discount_code}}</strong></p><p>Giam {{discount_value}} â€” het han {{expiry_date}}</p>','[{\"key\": \"discount_code\", \"label\": \"Ma giam gia\", \"sample\": \"SALE50\"}, {\"key\": \"discount_value\", \"label\": \"Gia tri giam\", \"sample\": \"50%\"}, {\"key\": \"expiry_date\", \"label\": \"Ngay het han\", \"sample\": \"30/04/2026\"}]','2026-08-30 02:53:31');
/*!40000 ALTER TABLE `cms_email_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_layout_section`
--

DROP TABLE IF EXISTS `cms_layout_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cms_layout_section` (
  `cms_layout_section_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toan cuc cua Section trong Layout',
  `cms_layout_section_page` varchar(50) NOT NULL DEFAULT 'homepage' COMMENT 'Trang ap dung: homepage, landing_xxx',
  `cms_layout_section_type` varchar(50) NOT NULL COMMENT 'Loai section: hero_slider, announcement_bar, category_grid, ...',
  `cms_layout_section_config` json NOT NULL COMMENT 'Config JSON theo schema cua tung section type',
  `cms_layout_section_sort` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Thu tu hien thi tren trang',
  `cms_layout_section_visible` tinyint NOT NULL DEFAULT '1' COMMENT 'An/hien section: 0: An, 1: Hien',
  `cms_layout_section_version` varchar(20) NOT NULL DEFAULT 'draft' COMMENT 'Version: draft, published, scheduled',
  `cms_layout_section_publish_at` datetime DEFAULT NULL COMMENT 'Thoi diem hen publish (khi version=scheduled)',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay tao section',
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Ngay cap nhat cuoi',
  PRIMARY KEY (`cms_layout_section_id`),
  KEY `ix_cmslayoutsection_page_version` (`cms_layout_section_page`,`cms_layout_section_version`),
  KEY `ix_cmslayoutsection_sort` (`cms_layout_section_sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Cac section cau thanh trang Homepage (Layout Builder)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_layout_section`
--

LOCK TABLES `cms_layout_section` WRITE;
/*!40000 ALTER TABLE `cms_layout_section` DISABLE KEYS */;
INSERT INTO `cms_layout_section` VALUES ('ls-draft-0000-0000-0000-000000000001','homepage','announcement_bar','{\"bg_color\": \"#1a1a1a\", \"messages\": [{\"link\": \"/san-pham\", \"text\": \"FREESHIP don tu 500K â€” Ap dung toan quoc\"}, {\"link\": \"/san-pham\", \"text\": \"Giam 10% cho don hang dau tien â€” Ma: WELCOME10\"}, {\"link\": \"\", \"text\": \"Doi tra mien phi trong 30 ngay\"}], \"text_color\": \"#FFFFFF\", \"auto_scroll\": true, \"dismissible\": true, \"scroll_speed\": 3000}',1.0000,1,'draft',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31'),('ls-draft-0000-0000-0000-000000000002','homepage','hero_slider','{\"slides\": [{\"title\": \"Bo Suu Tap Xuan He 2026\", \"cta_link\": \"/danh-muc/ao-thun\", \"cta_text\": \"Kham pha ngay\", \"subtitle\": \"Phong cach toi gian â€” Chat lieu cao cap\", \"text_color\": \"#FFFFFF\", \"image_mobile\": \"/images/hero/slide-1-mobile.jpg\", \"image_desktop\": \"/images/hero/slide-1-desktop.jpg\", \"text_position\": \"center\"}, {\"title\": \"Smart Casual\", \"cta_link\": \"/danh-muc/ao-so-mi\", \"cta_text\": \"Mua so mi\", \"subtitle\": \"Tu tin moi ngay voi phong cach lich lam\", \"text_color\": \"#FFFFFF\", \"image_mobile\": \"/images/hero/slide-2-mobile.jpg\", \"image_desktop\": \"/images/hero/slide-2-desktop.jpg\", \"text_position\": \"left\"}, {\"title\": \"Jeans â€” Muon kieu phoi do\", \"cta_link\": \"/danh-muc/quan-jeans\", \"cta_text\": \"Chon quan jeans\", \"subtitle\": \"Slim fit, Skinny, Straight â€” Du phong cach\", \"text_color\": \"#FFFFFF\", \"image_mobile\": \"/images/hero/slide-3-mobile.jpg\", \"image_desktop\": \"/images/hero/slide-3-desktop.jpg\", \"text_position\": \"right\"}], \"autoplay\": true, \"show_dots\": true, \"show_arrows\": true, \"display_mode\": \"fullwidth\", \"height_mobile\": 300, \"overlay_color\": \"#000000\", \"autoplay_speed\": 5000, \"height_desktop\": 500, \"overlay_opacity\": 30}',2.0000,1,'draft',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31'),('ls-draft-0000-0000-0000-000000000003','homepage','trust_bar','{\"items\": [{\"icon\": \"Truck\", \"title\": \"Freeship\", \"subtitle\": \"Don tu 500K\"}, {\"icon\": \"ShieldCheck\", \"title\": \"Chinh hang 100%\", \"subtitle\": \"Dam bao chat luong\"}, {\"icon\": \"RefreshCw\", \"title\": \"Doi tra 30 ngay\", \"subtitle\": \"Mien phi doi tra\"}, {\"icon\": \"Headphones\", \"title\": \"Ho tro 24/7\", \"subtitle\": \"0901 234 567\"}], \"bg_color\": \"#F9FAFB\", \"icon_color\": \"#333333\", \"text_color\": \"#333333\", \"show_border\": false, \"display_mode\": \"row\", \"show_icon_bg\": true}',3.0000,1,'draft',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31'),('ls-draft-0000-0000-0000-000000000004','homepage','category_grid','{\"title\": \"Danh muc noi bat\", \"card_style\": \"overlay\", \"categories\": [{\"id\": \"c0000000-0000-0000-0000-000000000001\", \"link\": \"/danh-muc/ao-thun\", \"name\": \"Ao Thun\", \"image\": \"/images/category/ao-thun.jpg\"}, {\"id\": \"c0000000-0000-0000-0000-000000000002\", \"link\": \"/danh-muc/ao-so-mi\", \"name\": \"Ao So Mi\", \"image\": \"/images/category/ao-so-mi.jpg\"}, {\"id\": \"c0000000-0000-0000-0000-000000000003\", \"link\": \"/danh-muc/quan-jeans\", \"name\": \"Quan Jeans\", \"image\": \"/images/category/quan-jeans.jpg\"}, {\"id\": \"c0000000-0000-0000-0000-000000000004\", \"link\": \"/danh-muc/ao-khoac\", \"name\": \"Ao Khoac\", \"image\": \"/images/category/ao-khoac.jpg\"}, {\"id\": \"c0000000-0000-0000-0000-000000000005\", \"link\": \"/danh-muc/phu-kien\", \"name\": \"Phu Kien\", \"image\": \"/images/category/phu-kien.jpg\"}], \"item_count\": 5, \"show_arrow\": true, \"show_count\": true, \"show_image\": true, \"display_mode\": \"grid\", \"columns_mobile\": 2, \"columns_desktop\": 5}',4.0000,1,'draft',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31'),('ls-draft-0000-0000-0000-000000000005','homepage','featured_products_tab','{\"tabs\": [{\"label\": \"Hang moi ve\", \"source_type\": \"collection\", \"source_value\": \"new_arrivals\"}, {\"label\": \"Ban chay nhat\", \"source_type\": \"collection\", \"source_value\": \"best_sellers\"}, {\"label\": \"Khuyen mai\", \"source_type\": \"collection\", \"source_value\": \"on_sale\"}], \"cta_text\": \"XEM TAT CA SAN PHAM\", \"show_cta\": true, \"tab_style\": \"underline\", \"columns_mobile\": 2, \"columns_desktop\": 5, \"products_per_tab\": 10}',5.0000,1,'draft',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31'),('ls-draft-0000-0000-0000-000000000006','homepage','product_carousel','{\"title\": \"San pham noi bat\", \"autoplay\": false, \"cta_link\": \"/san-pham?featured=1\", \"cta_text\": \"XEM TAT CA\", \"show_cta\": true, \"show_badge\": true, \"show_price\": true, \"category_id\": null, \"show_rating\": true, \"source_type\": \"collection\", \"display_mode\": \"carousel\", \"max_products\": 12, \"source_value\": \"featured\", \"show_quick_add\": true, \"columns_desktop\": 5}',6.0000,1,'draft',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31'),('ls-draft-0000-0000-0000-000000000007','homepage','banner_columns','{\"gap\": 12, \"columns\": [{\"link\": \"/danh-muc/ao-khoac\", \"image\": \"/images/banner/banner-col-1.jpg\", \"title\": \"Ao Khoac Mua Dong\", \"subtitle\": \"Giam den 40%\"}, {\"link\": \"/danh-muc/phu-kien\", \"image\": \"/images/banner/banner-col-2.jpg\", \"title\": \"Phu Kien Thoi Trang\", \"subtitle\": \"Tu 200K\"}], \"rounded\": true, \"aspect_ratio\": \"4:3\", \"display_mode\": \"equal\", \"show_text_overlay\": true}',7.0000,1,'draft',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31'),('ls-draft-0000-0000-0000-000000000008','homepage','newsletter','{\"title\": \"Dang ky nhan tin khuyen mai\", \"bg_color\": \"#1a1a1a\", \"subtitle\": \"Nhan ngay ma giam 10% cho don hang dau tien\", \"btn_color\": \"#D0021B\", \"text_color\": \"#FFFFFF\", \"button_text\": \"Dang ky\", \"input_style\": \"rounded\", \"placeholder\": \"Nhap email cua ban\", \"display_mode\": \"full\"}',8.0000,1,'draft',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31'),('ls-publ--0000-0000-0000-000000000001','homepage','announcement_bar','{\"bg_color\": \"#1a1a1a\", \"messages\": [{\"link\": \"/san-pham\", \"text\": \"FREESHIP don tu 500K â€” Ap dung toan quoc\"}, {\"link\": \"/san-pham\", \"text\": \"Giam 10% cho don hang dau tien â€” Ma: WELCOME10\"}, {\"link\": \"\", \"text\": \"Doi tra mien phi trong 30 ngay\"}], \"text_color\": \"#FFFFFF\", \"auto_scroll\": true, \"dismissible\": true, \"scroll_speed\": 3000}',1.0000,1,'published',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31'),('ls-publ--0000-0000-0000-000000000002','homepage','hero_slider','{\"slides\": [{\"title\": \"Bo Suu Tap Xuan He 2026\", \"cta_link\": \"/danh-muc/ao-thun\", \"cta_text\": \"Kham pha ngay\", \"subtitle\": \"Phong cach toi gian â€” Chat lieu cao cap\", \"text_color\": \"#FFFFFF\", \"image_mobile\": \"/images/hero/slide-1-mobile.jpg\", \"image_desktop\": \"/images/hero/slide-1-desktop.jpg\", \"text_position\": \"center\"}, {\"title\": \"Smart Casual\", \"cta_link\": \"/danh-muc/ao-so-mi\", \"cta_text\": \"Mua so mi\", \"subtitle\": \"Tu tin moi ngay voi phong cach lich lam\", \"text_color\": \"#FFFFFF\", \"image_mobile\": \"/images/hero/slide-2-mobile.jpg\", \"image_desktop\": \"/images/hero/slide-2-desktop.jpg\", \"text_position\": \"left\"}, {\"title\": \"Jeans â€” Muon kieu phoi do\", \"cta_link\": \"/danh-muc/quan-jeans\", \"cta_text\": \"Chon quan jeans\", \"subtitle\": \"Slim fit, Skinny, Straight â€” Du phong cach\", \"text_color\": \"#FFFFFF\", \"image_mobile\": \"/images/hero/slide-3-mobile.jpg\", \"image_desktop\": \"/images/hero/slide-3-desktop.jpg\", \"text_position\": \"right\"}], \"autoplay\": true, \"show_dots\": true, \"show_arrows\": true, \"display_mode\": \"fullwidth\", \"height_mobile\": 300, \"overlay_color\": \"#000000\", \"autoplay_speed\": 5000, \"height_desktop\": 500, \"overlay_opacity\": 30}',2.0000,1,'published',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31'),('ls-publ--0000-0000-0000-000000000003','homepage','trust_bar','{\"items\": [{\"icon\": \"Truck\", \"title\": \"Freeship\", \"subtitle\": \"Don tu 500K\"}, {\"icon\": \"ShieldCheck\", \"title\": \"Chinh hang 100%\", \"subtitle\": \"Dam bao chat luong\"}, {\"icon\": \"RefreshCw\", \"title\": \"Doi tra 30 ngay\", \"subtitle\": \"Mien phi doi tra\"}, {\"icon\": \"Headphones\", \"title\": \"Ho tro 24/7\", \"subtitle\": \"0901 234 567\"}], \"bg_color\": \"#F9FAFB\", \"icon_color\": \"#333333\", \"text_color\": \"#333333\", \"show_border\": false, \"display_mode\": \"row\", \"show_icon_bg\": true}',3.0000,1,'published',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31'),('ls-publ--0000-0000-0000-000000000004','homepage','category_grid','{\"title\": \"Danh muc noi bat\", \"card_style\": \"overlay\", \"categories\": [{\"id\": \"c0000000-0000-0000-0000-000000000001\", \"link\": \"/danh-muc/ao-thun\", \"name\": \"Ao Thun\", \"image\": \"/images/category/ao-thun.jpg\"}, {\"id\": \"c0000000-0000-0000-0000-000000000002\", \"link\": \"/danh-muc/ao-so-mi\", \"name\": \"Ao So Mi\", \"image\": \"/images/category/ao-so-mi.jpg\"}, {\"id\": \"c0000000-0000-0000-0000-000000000003\", \"link\": \"/danh-muc/quan-jeans\", \"name\": \"Quan Jeans\", \"image\": \"/images/category/quan-jeans.jpg\"}, {\"id\": \"c0000000-0000-0000-0000-000000000004\", \"link\": \"/danh-muc/ao-khoac\", \"name\": \"Ao Khoac\", \"image\": \"/images/category/ao-khoac.jpg\"}, {\"id\": \"c0000000-0000-0000-0000-000000000005\", \"link\": \"/danh-muc/phu-kien\", \"name\": \"Phu Kien\", \"image\": \"/images/category/phu-kien.jpg\"}], \"item_count\": 5, \"show_arrow\": true, \"show_count\": true, \"show_image\": true, \"display_mode\": \"grid\", \"columns_mobile\": 2, \"columns_desktop\": 5}',4.0000,1,'published',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31'),('ls-publ--0000-0000-0000-000000000005','homepage','featured_products_tab','{\"tabs\": [{\"label\": \"Hang moi ve\", \"source_type\": \"collection\", \"source_value\": \"new_arrivals\"}, {\"label\": \"Ban chay nhat\", \"source_type\": \"collection\", \"source_value\": \"best_sellers\"}, {\"label\": \"Khuyen mai\", \"source_type\": \"collection\", \"source_value\": \"on_sale\"}], \"cta_text\": \"XEM TAT CA SAN PHAM\", \"show_cta\": true, \"tab_style\": \"underline\", \"columns_mobile\": 2, \"columns_desktop\": 5, \"products_per_tab\": 10}',5.0000,1,'published',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31'),('ls-publ--0000-0000-0000-000000000006','homepage','product_carousel','{\"title\": \"San pham noi bat\", \"autoplay\": false, \"cta_link\": \"/san-pham?featured=1\", \"cta_text\": \"XEM TAT CA\", \"show_cta\": true, \"show_badge\": true, \"show_price\": true, \"category_id\": null, \"show_rating\": true, \"source_type\": \"collection\", \"display_mode\": \"carousel\", \"max_products\": 12, \"source_value\": \"featured\", \"show_quick_add\": true, \"columns_desktop\": 5}',6.0000,1,'published',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31'),('ls-publ--0000-0000-0000-000000000007','homepage','banner_columns','{\"gap\": 12, \"columns\": [{\"link\": \"/danh-muc/ao-khoac\", \"image\": \"/images/banner/banner-col-1.jpg\", \"title\": \"Ao Khoac Mua Dong\", \"subtitle\": \"Giam den 40%\"}, {\"link\": \"/danh-muc/phu-kien\", \"image\": \"/images/banner/banner-col-2.jpg\", \"title\": \"Phu Kien Thoi Trang\", \"subtitle\": \"Tu 200K\"}], \"rounded\": true, \"aspect_ratio\": \"4:3\", \"display_mode\": \"equal\", \"show_text_overlay\": true}',7.0000,1,'published',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31'),('ls-publ--0000-0000-0000-000000000008','homepage','newsletter','{\"title\": \"Dang ky nhan tin khuyen mai\", \"bg_color\": \"#1a1a1a\", \"subtitle\": \"Nhan ngay ma giam 10% cho don hang dau tien\", \"btn_color\": \"#D0021B\", \"text_color\": \"#FFFFFF\", \"button_text\": \"Dang ky\", \"input_style\": \"rounded\", \"placeholder\": \"Nhap email cua ban\", \"display_mode\": \"full\"}',8.0000,1,'published',NULL,'2026-08-30 02:53:31','2026-08-30 02:53:31');
/*!40000 ALTER TABLE `cms_layout_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_menu`
--

DROP TABLE IF EXISTS `cms_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cms_menu` (
  `cms_menu_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toan cuc cua Menu',
  `cms_menu_type` varchar(20) NOT NULL COMMENT 'Loai menu: header, footer, mobile',
  `cms_menu_name` varchar(100) NOT NULL COMMENT 'Ten menu',
  `cms_menu_status` tinyint NOT NULL DEFAULT '1' COMMENT 'Trang thai: 0: An, 1: Active',
  PRIMARY KEY (`cms_menu_id`),
  UNIQUE KEY `uix_cmsmenu_type` (`cms_menu_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Danh sach Menu chinh (header, footer, mobile)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_menu`
--

LOCK TABLES `cms_menu` WRITE;
/*!40000 ALTER TABLE `cms_menu` DISABLE KEYS */;
INSERT INTO `cms_menu` VALUES ('fc3f2bfd-a41d-11f1-b0a9-762043079894','header','Menu Header',1),('fc3f3005-a41d-11f1-b0a9-762043079894','footer','Menu Footer',1),('fc3f322d-a41d-11f1-b0a9-762043079894','mobile','Menu Mobile',1);
/*!40000 ALTER TABLE `cms_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_menu_item`
--

DROP TABLE IF EXISTS `cms_menu_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cms_menu_item` (
  `cms_menu_item_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toan cuc cua Menu Item',
  `cms_menu_id` char(36) NOT NULL COMMENT 'FK tro toi Menu',
  `cms_menu_item_parent_id` char(36) DEFAULT NULL COMMENT 'FK tro toi parent item (NULL = cap 1)',
  `cms_menu_item_label` varchar(100) NOT NULL COMMENT 'Text hien thi cua menu item',
  `cms_menu_item_type` varchar(20) NOT NULL DEFAULT 'url' COMMENT 'Loai item: category, page, url, custom',
  `cms_menu_item_value` varchar(255) NOT NULL COMMENT 'Gia tri: category_id / page_slug / URL / path',
  `cms_menu_item_icon` varchar(50) DEFAULT NULL COMMENT 'Lucide icon name (optional)',
  `cms_menu_item_badge` varchar(20) DEFAULT NULL COMMENT 'Badge text: Moi, Sale (optional)',
  `cms_menu_item_open_new_tab` tinyint NOT NULL DEFAULT '0' COMMENT 'Mo trong tab moi: 0: Khong, 1: Co',
  `cms_menu_item_mobile_visible` tinyint NOT NULL DEFAULT '1' COMMENT 'Hien thi tren mobile: 0: An, 1: Hien',
  `cms_menu_item_sort` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Thu tu sap xep trong cung cap',
  PRIMARY KEY (`cms_menu_item_id`),
  KEY `ix_cmsmenuitem_cmsmenuid` (`cms_menu_id`),
  KEY `ix_cmsmenuitem_parentid` (`cms_menu_item_parent_id`),
  KEY `ix_cmsmenuitem_sort` (`cms_menu_item_sort`),
  CONSTRAINT `fk_cmsmenuitem_cmsmenu` FOREIGN KEY (`cms_menu_id`) REFERENCES `cms_menu` (`cms_menu_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cmsmenuitem_parent` FOREIGN KEY (`cms_menu_item_parent_id`) REFERENCES `cms_menu_item` (`cms_menu_item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Cac item trong Menu (ho tro 2 cap cho header)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_menu_item`
--

LOCK TABLES `cms_menu_item` WRITE;
/*!40000 ALTER TABLE `cms_menu_item` DISABLE KEYS */;
INSERT INTO `cms_menu_item` VALUES ('mi-ftr-0000-0000-0000-000000000001','fc3f3005-a41d-11f1-b0a9-762043079894',NULL,'Ho tro khach hang','custom','#',NULL,NULL,0,1,1.0000),('mi-ftr-0000-0000-0000-000000000002','fc3f3005-a41d-11f1-b0a9-762043079894','mi-ftr-0000-0000-0000-000000000001','Huong dan mua hang','page','/huong-dan-mua-hang',NULL,NULL,0,1,1.0000),('mi-ftr-0000-0000-0000-000000000003','fc3f3005-a41d-11f1-b0a9-762043079894','mi-ftr-0000-0000-0000-000000000001','Phuong thuc thanh toan','page','/phuong-thuc-thanh-toan',NULL,NULL,0,1,2.0000),('mi-ftr-0000-0000-0000-000000000004','fc3f3005-a41d-11f1-b0a9-762043079894','mi-ftr-0000-0000-0000-000000000001','Van chuyen & Giao hang','page','/van-chuyen',NULL,NULL,0,1,3.0000),('mi-ftr-0000-0000-0000-000000000005','fc3f3005-a41d-11f1-b0a9-762043079894',NULL,'Chinh sach','custom','#',NULL,NULL,0,1,2.0000),('mi-ftr-0000-0000-0000-000000000006','fc3f3005-a41d-11f1-b0a9-762043079894','mi-ftr-0000-0000-0000-000000000005','Chinh sach doi tra','page','/chinh-sach-doi-tra',NULL,NULL,0,1,1.0000),('mi-ftr-0000-0000-0000-000000000007','fc3f3005-a41d-11f1-b0a9-762043079894','mi-ftr-0000-0000-0000-000000000005','Chinh sach bao mat','page','/chinh-sach-bao-mat',NULL,NULL,0,1,2.0000),('mi-ftr-0000-0000-0000-000000000008','fc3f3005-a41d-11f1-b0a9-762043079894','mi-ftr-0000-0000-0000-000000000005','Dieu khoan su dung','page','/dieu-khoan-su-dung',NULL,NULL,0,1,3.0000),('mi-hdr-0000-0000-0000-000000000001','fc3f2bfd-a41d-11f1-b0a9-762043079894',NULL,'Trang chu','url','/',NULL,NULL,0,1,1.0000),('mi-hdr-0000-0000-0000-000000000002','fc3f2bfd-a41d-11f1-b0a9-762043079894',NULL,'Ao Thun','category','ao-thun',NULL,'New',0,1,2.0000),('mi-hdr-0000-0000-0000-000000000003','fc3f2bfd-a41d-11f1-b0a9-762043079894',NULL,'Ao So Mi','category','ao-so-mi',NULL,NULL,0,1,3.0000),('mi-hdr-0000-0000-0000-000000000004','fc3f2bfd-a41d-11f1-b0a9-762043079894',NULL,'Quan Jeans','category','quan-jeans',NULL,NULL,0,1,4.0000),('mi-hdr-0000-0000-0000-000000000005','fc3f2bfd-a41d-11f1-b0a9-762043079894',NULL,'Ao Khoac','category','ao-khoac',NULL,'Sale',0,1,5.0000),('mi-hdr-0000-0000-0000-000000000006','fc3f2bfd-a41d-11f1-b0a9-762043079894',NULL,'Phu Kien','category','phu-kien',NULL,NULL,0,1,6.0000),('mi-mob-0000-0000-0000-000000000001','fc3f322d-a41d-11f1-b0a9-762043079894',NULL,'Trang chu','url','/','Home',NULL,0,1,1.0000),('mi-mob-0000-0000-0000-000000000002','fc3f322d-a41d-11f1-b0a9-762043079894',NULL,'Ao Thun','category','ao-thun','Shirt','New',0,1,2.0000),('mi-mob-0000-0000-0000-000000000003','fc3f322d-a41d-11f1-b0a9-762043079894',NULL,'Ao So Mi','category','ao-so-mi','Shirt',NULL,0,1,3.0000),('mi-mob-0000-0000-0000-000000000004','fc3f322d-a41d-11f1-b0a9-762043079894',NULL,'Quan Jeans','category','quan-jeans','Shirt',NULL,0,1,4.0000),('mi-mob-0000-0000-0000-000000000005','fc3f322d-a41d-11f1-b0a9-762043079894',NULL,'Ao Khoac','category','ao-khoac','Shirt','Sale',0,1,5.0000),('mi-mob-0000-0000-0000-000000000006','fc3f322d-a41d-11f1-b0a9-762043079894',NULL,'Phu Kien','category','phu-kien','Package',NULL,0,1,6.0000);
/*!40000 ALTER TABLE `cms_menu_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_theme_config`
--

DROP TABLE IF EXISTS `cms_theme_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cms_theme_config` (
  `cms_theme_config_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toan cuc cua Theme Config entry',
  `cms_theme_config_key` varchar(50) NOT NULL COMMENT 'Key cau hinh: primary_color, font_heading, logo_url, ...',
  `cms_theme_config_value` text NOT NULL COMMENT 'Gia tri cau hinh',
  `cms_theme_config_type` varchar(20) NOT NULL DEFAULT 'text' COMMENT 'Kieu du lieu: color, font, text, number, boolean, json, image',
  `cms_theme_config_group` varchar(30) NOT NULL COMMENT 'Nhom: colors, fonts, branding, footer, announcement, cookie',
  `cms_theme_config_label` varchar(100) NOT NULL COMMENT 'Nhan hien thi cho admin',
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Lan cap nhat cuoi',
  PRIMARY KEY (`cms_theme_config_id`),
  UNIQUE KEY `uix_cmsthemeconfig_key` (`cms_theme_config_key`),
  KEY `ix_cmsthemeconfig_group` (`cms_theme_config_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Cau hinh giao dien toan cuc (colors, fonts, logo, ...)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_theme_config`
--

LOCK TABLES `cms_theme_config` WRITE;
/*!40000 ALTER TABLE `cms_theme_config` DISABLE KEYS */;
INSERT INTO `cms_theme_config` VALUES ('fbe43621-a41d-11f1-b0a9-762043079894','primary_color','#1a1a1a','color','colors','Mau chinh','2026-08-30 02:53:31'),('fbe43b2e-a41d-11f1-b0a9-762043079894','accent_color','#D0021B','color','colors','Mau nhan (CTA, Sale)','2026-08-30 02:53:31'),('fbe43cb9-a41d-11f1-b0a9-762043079894','bg_color','#FFFFFF','color','colors','Mau nen','2026-08-30 02:53:31'),('fbe43d7e-a41d-11f1-b0a9-762043079894','text_color','#333333','color','colors','Mau chu','2026-08-30 02:53:31'),('fbe43e24-a41d-11f1-b0a9-762043079894','muted_color','#6B7280','color','colors','Mau chu phu','2026-08-30 02:53:31'),('fbe43ee1-a41d-11f1-b0a9-762043079894','font_heading','Inter','font','fonts','Font tieu de','2026-08-30 02:53:31'),('fbe44072-a41d-11f1-b0a9-762043079894','font_body','Inter','font','fonts','Font noi dung','2026-08-30 02:53:31'),('fbe44172-a41d-11f1-b0a9-762043079894','logo_url','','image','branding','Logo','2026-08-30 02:53:31'),('fbe44231-a41d-11f1-b0a9-762043079894','favicon_url','','image','branding','Favicon','2026-08-30 02:53:31'),('fbe442dc-a41d-11f1-b0a9-762043079894','footer_copyright','Â© 2026 FashionEcom. All rights reserved.','text','footer','Copyright footer','2026-08-30 02:53:31'),('fbe44387-a41d-11f1-b0a9-762043079894','footer_description','Thoi trang nam nu chinh hang','text','footer','Mo ta footer','2026-08-30 02:53:31'),('fbe4443c-a41d-11f1-b0a9-762043079894','announcement_text','','text','announcement','Text thong bao header','2026-08-30 02:53:31'),('fbe444d3-a41d-11f1-b0a9-762043079894','announcement_bg_color','#D0021B','color','announcement','Mau nen thong bao','2026-08-30 02:53:31'),('fbe4456f-a41d-11f1-b0a9-762043079894','announcement_visible','0','boolean','announcement','Hien thi thong bao','2026-08-30 02:53:31'),('tc-0000-0000-0000-000000000002','secondary_color','#D0021B','color','colors','Mau phu (accent)','2026-08-30 02:53:31'),('tc-0000-0000-0000-000000000003','background_color','#FFFFFF','color','colors','Mau nen','2026-08-30 02:53:31'),('tc-0000-0000-0000-000000000005','border_color','#E5E7EB','color','colors','Mau vien','2026-08-30 02:53:31'),('tc-0000-0000-0000-000000000006','heading_font','Montserrat','font','fonts','Font tieu de','2026-08-30 02:53:31'),('tc-0000-0000-0000-000000000007','body_font','Inter','font','fonts','Font noi dung','2026-08-30 02:53:31'),('tc-0000-0000-0000-000000000010','site_name','Fashion Ecom','text','branding','Ten website','2026-08-30 02:53:31'),('tc-0000-0000-0000-000000000011','footer_text','Â© 2026 Fashion Ecom. All rights reserved.','text','footer','Text footer','2026-08-30 02:53:31'),('tc-0000-0000-0000-000000000012','footer_bg_color','#1a1a1a','color','footer','Mau nen footer','2026-08-30 02:53:31'),('tc-0000-0000-0000-000000000013','footer_text_color','#FFFFFF','color','footer','Mau chu footer','2026-08-30 02:53:31'),('tc-0000-0000-0000-000000000014','show_social_icons','1','boolean','footer','Hien icon MXH','2026-08-30 02:53:31'),('tc-0000-0000-0000-000000000015','show_announcement','1','boolean','announcement','Hien thanh thong bao','2026-08-30 02:53:31'),('tc-0000-0000-0000-000000000016','announcement_bg','#1a1a1a','color','announcement','Mau nen thong bao','2026-08-30 02:53:31');
/*!40000 ALTER TABLE `cms_theme_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_goods_receipt`
--

DROP TABLE IF EXISTS `inv_goods_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_goods_receipt` (
  `inv_goods_receipt_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID phieu nhap kho',
  `inv_purchase_order_id` char(36) NOT NULL COMMENT 'Khoa ngoai PO',
  `inv_warehouse_id` char(36) NOT NULL COMMENT 'Kho nhan hang',
  `inv_goods_receipt_code` varchar(20) NOT NULL COMMENT 'Ma phieu nhap (VD: GRN-20260410-001)',
  `inv_goods_receipt_notes` text COMMENT 'Ghi chu',
  `sys_user_id` char(36) DEFAULT NULL COMMENT 'Nguoi nhap kho',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay nhap',
  PRIMARY KEY (`inv_goods_receipt_id`),
  UNIQUE KEY `uix_invgoodsreceipt_code` (`inv_goods_receipt_code`),
  KEY `ix_invgoodsreceipt_poid` (`inv_purchase_order_id`),
  CONSTRAINT `fk_invgoodsreceipt_po` FOREIGN KEY (`inv_purchase_order_id`) REFERENCES `inv_purchase_order` (`inv_purchase_order_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Phieu nhap kho tu PO';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_goods_receipt`
--

LOCK TABLES `inv_goods_receipt` WRITE;
/*!40000 ALTER TABLE `inv_goods_receipt` DISABLE KEYS */;
/*!40000 ALTER TABLE `inv_goods_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_goods_receipt_item`
--

DROP TABLE IF EXISTS `inv_goods_receipt_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_goods_receipt_item` (
  `inv_goods_receipt_item_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID dong phieu nhap',
  `inv_goods_receipt_id` char(36) NOT NULL COMMENT 'Khoa ngoai phieu nhap',
  `cat_product_variant_id` char(36) NOT NULL COMMENT 'Khoa ngoai Variant',
  `inv_goods_receipt_item_qty` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'So luong thuc nhan',
  `inv_goods_receipt_item_unit_cost` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Don gia thuc te',
  `inv_goods_receipt_item_notes` varchar(255) DEFAULT NULL COMMENT 'Ghi chu dong (VD: 5 cai loi)',
  PRIMARY KEY (`inv_goods_receipt_item_id`),
  KEY `ix_invgoodsreceiptitem_receiptid` (`inv_goods_receipt_id`),
  CONSTRAINT `fk_invgoodsreceiptitem_receipt` FOREIGN KEY (`inv_goods_receipt_id`) REFERENCES `inv_goods_receipt` (`inv_goods_receipt_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Chi tiet dong phieu nhap kho';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_goods_receipt_item`
--

LOCK TABLES `inv_goods_receipt_item` WRITE;
/*!40000 ALTER TABLE `inv_goods_receipt_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `inv_goods_receipt_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_inventory`
--

DROP TABLE IF EXISTS `inv_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_inventory` (
  `inv_inventory_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'PK â€” UUID',
  `cat_product_variant_id` char(36) NOT NULL COMMENT 'FK bien the san pham',
  `inv_inventory_qty` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'So luong ton kho',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay tao',
  PRIMARY KEY (`inv_inventory_id`),
  KEY `ix_invinventory_variant` (`cat_product_variant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Ton kho theo bien the san pham';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_inventory`
--

LOCK TABLES `inv_inventory` WRITE;
/*!40000 ALTER TABLE `inv_inventory` DISABLE KEYS */;
INSERT INTO `inv_inventory` VALUES ('442869d6-a429-11f1-b5ab-6ed8ca3651ef','441aa968-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:16'),('44286a30-a429-11f1-b5ab-6ed8ca3651ef','441b4a48-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:16'),('44286a48-a429-11f1-b5ab-6ed8ca3651ef','441bf6eb-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:16'),('44286a61-a429-11f1-b5ab-6ed8ca3651ef','441e2d0f-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:16'),('44286a75-a429-11f1-b5ab-6ed8ca3651ef','441f3047-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:16'),('44286a89-a429-11f1-b5ab-6ed8ca3651ef','4421305e-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:16'),('44286a9c-a429-11f1-b5ab-6ed8ca3651ef','442203af-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:16'),('44286ab0-a429-11f1-b5ab-6ed8ca3651ef','4422c386-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:16'),('44286ac6-a429-11f1-b5ab-6ed8ca3651ef','44236ce7-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:16'),('44286ad9-a429-11f1-b5ab-6ed8ca3651ef','4424098c-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:16'),('44286aec-a429-11f1-b5ab-6ed8ca3651ef','4424b51f-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:16'),('44286afd-a429-11f1-b5ab-6ed8ca3651ef','44254622-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:16'),('44286b0f-a429-11f1-b5ab-6ed8ca3651ef','4425e046-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:16'),('44286b21-a429-11f1-b5ab-6ed8ca3651ef','442693a4-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:16'),('44286b33-a429-11f1-b5ab-6ed8ca3651ef','44274c37-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:16'),('443a26b1-a429-11f1-b5ab-6ed8ca3651ef','442b90d3-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:17'),('443a2718-a429-11f1-b5ab-6ed8ca3651ef','442c2a98-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:17'),('443a2741-a429-11f1-b5ab-6ed8ca3651ef','442db3b2-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:17'),('443a2765-a429-11f1-b5ab-6ed8ca3651ef','442ea598-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:17'),('443a278a-a429-11f1-b5ab-6ed8ca3651ef','442f833f-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:17'),('443a27a9-a429-11f1-b5ab-6ed8ca3651ef','4430769f-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:17'),('443a27cd-a429-11f1-b5ab-6ed8ca3651ef','4431fde6-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:17'),('443a27ef-a429-11f1-b5ab-6ed8ca3651ef','4432b877-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:17'),('443a2812-a429-11f1-b5ab-6ed8ca3651ef','443387a9-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:17'),('443a2832-a429-11f1-b5ab-6ed8ca3651ef','443442e3-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:17'),('443a296a-a429-11f1-b5ab-6ed8ca3651ef','44362f40-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:17'),('443a299e-a429-11f1-b5ab-6ed8ca3651ef','443703a9-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:17'),('443a29c0-a429-11f1-b5ab-6ed8ca3651ef','44382420-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:17'),('443a29e1-a429-11f1-b5ab-6ed8ca3651ef','4438d44a-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:17'),('443a2a01-a429-11f1-b5ab-6ed8ca3651ef','44397676-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:17'),('444a874c-a429-11f1-b5ab-6ed8ca3651ef','44402396-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:17'),('444a87a3-a429-11f1-b5ab-6ed8ca3651ef','4440cd63-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:17'),('444a87cc-a429-11f1-b5ab-6ed8ca3651ef','4441740a-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:17'),('444a87f1-a429-11f1-b5ab-6ed8ca3651ef','44420dd2-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:17'),('444a8828-a429-11f1-b5ab-6ed8ca3651ef','4442aa8e-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:17'),('444a8864-a429-11f1-b5ab-6ed8ca3651ef','4443544c-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:17'),('444a88a4-a429-11f1-b5ab-6ed8ca3651ef','4443f4d0-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:17'),('444a88da-a429-11f1-b5ab-6ed8ca3651ef','4444f30c-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:17'),('444a8917-a429-11f1-b5ab-6ed8ca3651ef','4445938a-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:17'),('444a894a-a429-11f1-b5ab-6ed8ca3651ef','44462bf5-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:17'),('444a897e-a429-11f1-b5ab-6ed8ca3651ef','4446e1b2-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:17'),('444a89a5-a429-11f1-b5ab-6ed8ca3651ef','4447fd9d-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:17'),('444a89c9-a429-11f1-b5ab-6ed8ca3651ef','4448b4fe-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:17'),('444a89e9-a429-11f1-b5ab-6ed8ca3651ef','444952c3-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:17'),('444a8a0a-a429-11f1-b5ab-6ed8ca3651ef','4449e8d2-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:17'),('445cd0fd-a429-11f1-b5ab-6ed8ca3651ef','444ddf58-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:17'),('445cd14c-a429-11f1-b5ab-6ed8ca3651ef','444e712b-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:17'),('445cd173-a429-11f1-b5ab-6ed8ca3651ef','44508d8a-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:17'),('445cd196-a429-11f1-b5ab-6ed8ca3651ef','44513b67-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:17'),('445cd1b7-a429-11f1-b5ab-6ed8ca3651ef','4451d109-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:17'),('445cd1d8-a429-11f1-b5ab-6ed8ca3651ef','44527951-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:17'),('445cd1f9-a429-11f1-b5ab-6ed8ca3651ef','445314d2-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:17'),('445cd21c-a429-11f1-b5ab-6ed8ca3651ef','4453aff1-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:17'),('445cd244-a429-11f1-b5ab-6ed8ca3651ef','4454dd2b-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:17'),('445cd265-a429-11f1-b5ab-6ed8ca3651ef','445574c0-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:17'),('445cd285-a429-11f1-b5ab-6ed8ca3651ef','4456366d-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:17'),('445cd2a5-a429-11f1-b5ab-6ed8ca3651ef','4456ce40-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:17'),('445cd2c7-a429-11f1-b5ab-6ed8ca3651ef','4457674f-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:17'),('445cd2e8-a429-11f1-b5ab-6ed8ca3651ef','44581533-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:17'),('445cd309-a429-11f1-b5ab-6ed8ca3651ef','4458bcff-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:17'),('445cd328-a429-11f1-b5ab-6ed8ca3651ef','445963e9-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:17'),('445cd347-a429-11f1-b5ab-6ed8ca3651ef','4459f44f-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:17'),('445cd366-a429-11f1-b5ab-6ed8ca3651ef','445a8740-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:17'),('445cd389-a429-11f1-b5ab-6ed8ca3651ef','445b84ca-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:17'),('445cd3aa-a429-11f1-b5ab-6ed8ca3651ef','445c1ef9-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:17'),('446a6c9a-a429-11f1-b5ab-6ed8ca3651ef','446203f4-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:17'),('446a6d03-a429-11f1-b5ab-6ed8ca3651ef','4463c29f-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:17'),('446a6d2d-a429-11f1-b5ab-6ed8ca3651ef','4464671e-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:17'),('446a6d56-a429-11f1-b5ab-6ed8ca3651ef','44651058-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:17'),('446a6d79-a429-11f1-b5ab-6ed8ca3651ef','4465a21b-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:17'),('446a6d9b-a429-11f1-b5ab-6ed8ca3651ef','4466c2e4-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:17'),('446a6dc1-a429-11f1-b5ab-6ed8ca3651ef','44675ce8-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:17'),('446a6de4-a429-11f1-b5ab-6ed8ca3651ef','446806c6-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:17'),('446a6e08-a429-11f1-b5ab-6ed8ca3651ef','4468b4d9-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:17'),('446a6e28-a429-11f1-b5ab-6ed8ca3651ef','4469bc62-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:17'),('447d6026-a429-11f1-b5ab-6ed8ca3651ef','446d6b92-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:17'),('447d60ce-a429-11f1-b5ab-6ed8ca3651ef','446e0819-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:17'),('447d60fe-a429-11f1-b5ab-6ed8ca3651ef','446f3406-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:17'),('447d6126-a429-11f1-b5ab-6ed8ca3651ef','4470423c-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:17'),('447d6149-a429-11f1-b5ab-6ed8ca3651ef','4470e80e-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:17'),('447d6170-a429-11f1-b5ab-6ed8ca3651ef','44719707-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:17'),('447d619f-a429-11f1-b5ab-6ed8ca3651ef','447259c9-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:17'),('447d61c1-a429-11f1-b5ab-6ed8ca3651ef','4472f0d9-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:17'),('447d61e8-a429-11f1-b5ab-6ed8ca3651ef','44739f32-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:17'),('447d620b-a429-11f1-b5ab-6ed8ca3651ef','44745a4a-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:17'),('447d622f-a429-11f1-b5ab-6ed8ca3651ef','44750e2b-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:17'),('447d6254-a429-11f1-b5ab-6ed8ca3651ef','4475c329-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:17'),('447d628a-a429-11f1-b5ab-6ed8ca3651ef','4476c70c-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:17'),('447d62c1-a429-11f1-b5ab-6ed8ca3651ef','447aeac6-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:17'),('447d62fa-a429-11f1-b5ab-6ed8ca3651ef','447cacb0-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:17'),('44903ffe-a429-11f1-b5ab-6ed8ca3651ef','448161e5-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:17'),('44904062-a429-11f1-b5ab-6ed8ca3651ef','448209fa-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:17'),('4490408e-a429-11f1-b5ab-6ed8ca3651ef','4482b4f8-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:17'),('449040b5-a429-11f1-b5ab-6ed8ca3651ef','448381cc-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:17'),('449040da-a429-11f1-b5ab-6ed8ca3651ef','448421f8-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:17'),('449040fc-a429-11f1-b5ab-6ed8ca3651ef','44852d06-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:17'),('44904120-a429-11f1-b5ab-6ed8ca3651ef','44860bdf-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:17'),('44904141-a429-11f1-b5ab-6ed8ca3651ef','4486ca07-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:17'),('44904165-a429-11f1-b5ab-6ed8ca3651ef','448760e9-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:17'),('44904187-a429-11f1-b5ab-6ed8ca3651ef','448881c0-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:17'),('449041aa-a429-11f1-b5ab-6ed8ca3651ef','4489286f-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:17'),('449041cd-a429-11f1-b5ab-6ed8ca3651ef','448c2bdf-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:17'),('449041f1-a429-11f1-b5ab-6ed8ca3651ef','448df8a5-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:17'),('44904214-a429-11f1-b5ab-6ed8ca3651ef','448eddfc-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:17'),('4490423c-a429-11f1-b5ab-6ed8ca3651ef','448f8b6f-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:17'),('449c7f4c-a429-11f1-b5ab-6ed8ca3651ef','44938f03-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:17'),('449c7fb7-a429-11f1-b5ab-6ed8ca3651ef','44945866-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:17'),('449c7fe0-a429-11f1-b5ab-6ed8ca3651ef','4494f8d7-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:17'),('449c8003-a429-11f1-b5ab-6ed8ca3651ef','4495d04a-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:17'),('449c8087-a429-11f1-b5ab-6ed8ca3651ef','4497c8f8-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:17'),('449c80aa-a429-11f1-b5ab-6ed8ca3651ef','44989dc7-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:17'),('449c80d1-a429-11f1-b5ab-6ed8ca3651ef','449940c1-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:17'),('449c80f5-a429-11f1-b5ab-6ed8ca3651ef','449a00b8-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:17'),('449c811c-a429-11f1-b5ab-6ed8ca3651ef','449aa440-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:17'),('449c813d-a429-11f1-b5ab-6ed8ca3651ef','449ba2fd-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:17'),('44b0dc58-a429-11f1-b5ab-6ed8ca3651ef','44a2a699-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:17'),('44b0dcba-a429-11f1-b5ab-6ed8ca3651ef','44a34542-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:17'),('44b0dce5-a429-11f1-b5ab-6ed8ca3651ef','44a3eeff-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:17'),('44b0dd09-a429-11f1-b5ab-6ed8ca3651ef','44a4df3a-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:17'),('44b0dd30-a429-11f1-b5ab-6ed8ca3651ef','44a7dc84-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:17'),('44b0dd55-a429-11f1-b5ab-6ed8ca3651ef','44a883a9-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:17'),('44b0dd7a-a429-11f1-b5ab-6ed8ca3651ef','44a93b7e-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:17'),('44b0dda0-a429-11f1-b5ab-6ed8ca3651ef','44a9d148-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:17'),('44b0ddc5-a429-11f1-b5ab-6ed8ca3651ef','44aa641c-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:17'),('44b0dde7-a429-11f1-b5ab-6ed8ca3651ef','44ab15fe-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:17'),('44b0de0b-a429-11f1-b5ab-6ed8ca3651ef','44abccc9-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:17'),('44b0de30-a429-11f1-b5ab-6ed8ca3651ef','44ac684f-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:17'),('44b0de52-a429-11f1-b5ab-6ed8ca3651ef','44ad11cb-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:17'),('44b0de75-a429-11f1-b5ab-6ed8ca3651ef','44af1490-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:17'),('44b0de99-a429-11f1-b5ab-6ed8ca3651ef','44b03a1b-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:17'),('44bf47c0-a429-11f1-b5ab-6ed8ca3651ef','44b431c4-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:17'),('44bf4826-a429-11f1-b5ab-6ed8ca3651ef','44b57413-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:17'),('44bf4850-a429-11f1-b5ab-6ed8ca3651ef','44b6de6d-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:17'),('44bf4876-a429-11f1-b5ab-6ed8ca3651ef','44b7be92-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:17'),('44bf489c-a429-11f1-b5ab-6ed8ca3651ef','44b876be-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:17'),('44bf48bd-a429-11f1-b5ab-6ed8ca3651ef','44b94fb9-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:17'),('44bf48e2-a429-11f1-b5ab-6ed8ca3651ef','44ba2026-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:17'),('44bf4906-a429-11f1-b5ab-6ed8ca3651ef','44bc2252-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:17'),('44bf492a-a429-11f1-b5ab-6ed8ca3651ef','44bcc0f3-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:17'),('44bf494f-a429-11f1-b5ab-6ed8ca3651ef','44bd5c17-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:17'),('44d277b1-a429-11f1-b5ab-6ed8ca3651ef','44c2f144-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:18'),('44d2780f-a429-11f1-b5ab-6ed8ca3651ef','44c3cc68-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:18'),('44d2783b-a429-11f1-b5ab-6ed8ca3651ef','44c49bff-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:18'),('44d2785f-a429-11f1-b5ab-6ed8ca3651ef','44c55f50-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:18'),('44d27889-a429-11f1-b5ab-6ed8ca3651ef','44c6c529-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:18'),('44d278ad-a429-11f1-b5ab-6ed8ca3651ef','44c7ffda-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:18'),('44d278cc-a429-11f1-b5ab-6ed8ca3651ef','44c8e048-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:18'),('44d278ef-a429-11f1-b5ab-6ed8ca3651ef','44ca0346-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:18'),('44d27916-a429-11f1-b5ab-6ed8ca3651ef','44cad141-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:18'),('44d2793d-a429-11f1-b5ab-6ed8ca3651ef','44cc2d5c-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:18'),('44d27962-a429-11f1-b5ab-6ed8ca3651ef','44cd57df-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:18'),('44d27982-a429-11f1-b5ab-6ed8ca3651ef','44ce12dd-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:18'),('44d279a6-a429-11f1-b5ab-6ed8ca3651ef','44cefaa0-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:18'),('44d279c7-a429-11f1-b5ab-6ed8ca3651ef','44d0f99a-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:18'),('44d279e6-a429-11f1-b5ab-6ed8ca3651ef','44d1c1dd-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:18'),('44e6aa8a-a429-11f1-b5ab-6ed8ca3651ef','44d62aa8-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:18'),('44e6aaf4-a429-11f1-b5ab-6ed8ca3651ef','44d75f1c-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:18'),('44e6ab23-a429-11f1-b5ab-6ed8ca3651ef','44d8ae34-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:18'),('44e6ab4b-a429-11f1-b5ab-6ed8ca3651ef','44d95a4f-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:18'),('44e6ab71-a429-11f1-b5ab-6ed8ca3651ef','44da8e92-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:18'),('44e6aba6-a429-11f1-b5ab-6ed8ca3651ef','44db645c-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:18'),('44e6abe1-a429-11f1-b5ab-6ed8ca3651ef','44dc2079-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:18'),('44e6ac18-a429-11f1-b5ab-6ed8ca3651ef','44dcb3bf-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:18'),('44e6ac4e-a429-11f1-b5ab-6ed8ca3651ef','44df7227-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:18'),('44e6ac84-a429-11f1-b5ab-6ed8ca3651ef','44e02d54-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:18'),('44e6acbd-a429-11f1-b5ab-6ed8ca3651ef','44e0e6cd-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:18'),('44e6acf1-a429-11f1-b5ab-6ed8ca3651ef','44e183f7-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:18'),('44e6ad2d-a429-11f1-b5ab-6ed8ca3651ef','44e26861-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:18'),('44e6ad65-a429-11f1-b5ab-6ed8ca3651ef','44e3a549-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:18'),('44e6ad93-a429-11f1-b5ab-6ed8ca3651ef','44e5b724-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:18'),('44f85531-a429-11f1-b5ab-6ed8ca3651ef','44e9f32a-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:18'),('44f855a5-a429-11f1-b5ab-6ed8ca3651ef','44eaacd0-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:18'),('44f855d1-a429-11f1-b5ab-6ed8ca3651ef','44eb525d-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:18'),('44f855fa-a429-11f1-b5ab-6ed8ca3651ef','44ec22ab-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:18'),('44f85621-a429-11f1-b5ab-6ed8ca3651ef','44ed2dbc-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:18'),('44f85645-a429-11f1-b5ab-6ed8ca3651ef','44edec33-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:18'),('44f8566b-a429-11f1-b5ab-6ed8ca3651ef','44ee8ec3-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:18'),('44f8568e-a429-11f1-b5ab-6ed8ca3651ef','44ef2fcb-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:18'),('44f856b2-a429-11f1-b5ab-6ed8ca3651ef','44efcd6c-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:18'),('44f856d5-a429-11f1-b5ab-6ed8ca3651ef','44f07753-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:18'),('44f856f6-a429-11f1-b5ab-6ed8ca3651ef','44f1e2d2-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:18'),('44f85718-a429-11f1-b5ab-6ed8ca3651ef','44f28c52-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:18'),('44f85739-a429-11f1-b5ab-6ed8ca3651ef','44f35266-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:18'),('44f8575b-a429-11f1-b5ab-6ed8ca3651ef','44f3f8c4-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:18'),('44f8577e-a429-11f1-b5ab-6ed8ca3651ef','44f79836-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:18'),('450b6576-a429-11f1-b5ab-6ed8ca3651ef','44fc34ba-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:18'),('450b65da-a429-11f1-b5ab-6ed8ca3651ef','44fce262-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:18'),('450b6616-a429-11f1-b5ab-6ed8ca3651ef','44ff9c91-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:18'),('450b664d-a429-11f1-b5ab-6ed8ca3651ef','450092a5-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:18'),('450b6685-a429-11f1-b5ab-6ed8ca3651ef','45015722-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:18'),('450b66b8-a429-11f1-b5ab-6ed8ca3651ef','45020d90-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:18'),('450b66e6-a429-11f1-b5ab-6ed8ca3651ef','4502afa9-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:18'),('450b671c-a429-11f1-b5ab-6ed8ca3651ef','4503ea87-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:18'),('450b674e-a429-11f1-b5ab-6ed8ca3651ef','45053b02-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:18'),('450b6781-a429-11f1-b5ab-6ed8ca3651ef','45060bc8-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:18'),('450b67af-a429-11f1-b5ab-6ed8ca3651ef','4506f061-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:18'),('450b67e2-a429-11f1-b5ab-6ed8ca3651ef','4507d60d-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:18'),('450b6815-a429-11f1-b5ab-6ed8ca3651ef','45091a78-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:18'),('450b6849-a429-11f1-b5ab-6ed8ca3651ef','4509ca6b-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:18'),('450b687c-a429-11f1-b5ab-6ed8ca3651ef','450a749f-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:18'),('452267fb-a429-11f1-b5ab-6ed8ca3651ef','450ff687-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:18'),('4522688f-a429-11f1-b5ab-6ed8ca3651ef','4510a503-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:18'),('452268c6-a429-11f1-b5ab-6ed8ca3651ef','45117b1c-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:18'),('452268fa-a429-11f1-b5ab-6ed8ca3651ef','451264e8-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:18'),('4522692c-a429-11f1-b5ab-6ed8ca3651ef','4515622b-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:18'),('4522695d-a429-11f1-b5ab-6ed8ca3651ef','451613ec-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:18'),('4522698f-a429-11f1-b5ab-6ed8ca3651ef','4516b2f0-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:18'),('452269c1-a429-11f1-b5ab-6ed8ca3651ef','45174f79-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:18'),('452269ee-a429-11f1-b5ab-6ed8ca3651ef','4517f3ea-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:18'),('45226a1b-a429-11f1-b5ab-6ed8ca3651ef','4518c0a3-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:18'),('45226a48-a429-11f1-b5ab-6ed8ca3651ef','4519e45b-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:18'),('45226a78-a429-11f1-b5ab-6ed8ca3651ef','451b2019-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:18'),('45226aac-a429-11f1-b5ab-6ed8ca3651ef','451d8f8c-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:18'),('45226ad6-a429-11f1-b5ab-6ed8ca3651ef','451e5ed9-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:18'),('45226b06-a429-11f1-b5ab-6ed8ca3651ef','452194cc-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:18'),('45355954-a429-11f1-b5ab-6ed8ca3651ef','452c49c0-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:18'),('453559bc-a429-11f1-b5ab-6ed8ca3651ef','452d042f-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:18'),('453559e7-a429-11f1-b5ab-6ed8ca3651ef','452dbf31-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:18'),('45355a0e-a429-11f1-b5ab-6ed8ca3651ef','452ee6c1-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:18'),('45355a35-a429-11f1-b5ab-6ed8ca3651ef','452fa232-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:18'),('45355a5a-a429-11f1-b5ab-6ed8ca3651ef','45305195-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:18'),('45355a7c-a429-11f1-b5ab-6ed8ca3651ef','45324131-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:18'),('45355a9f-a429-11f1-b5ab-6ed8ca3651ef','45330873-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:18'),('45355ac5-a429-11f1-b5ab-6ed8ca3651ef','4533edc7-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:18'),('45355ae7-a429-11f1-b5ab-6ed8ca3651ef','4534ae12-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:18'),('4547d97c-a429-11f1-b5ab-6ed8ca3651ef','45394b80-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:18'),('4547d9ea-a429-11f1-b5ab-6ed8ca3651ef','4539ef0e-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:18'),('4547da16-a429-11f1-b5ab-6ed8ca3651ef','453ab6fe-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:18'),('4547da3f-a429-11f1-b5ab-6ed8ca3651ef','453c037f-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:18'),('4547da66-a429-11f1-b5ab-6ed8ca3651ef','453cd78a-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:18'),('4547da8c-a429-11f1-b5ab-6ed8ca3651ef','453da7ea-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:18'),('4547dab4-a429-11f1-b5ab-6ed8ca3651ef','45418735-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:18'),('4547dadb-a429-11f1-b5ab-6ed8ca3651ef','45425605-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:18'),('4547db04-a429-11f1-b5ab-6ed8ca3651ef','4543017d-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:18'),('4547db2a-a429-11f1-b5ab-6ed8ca3651ef','4543ab99-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:18'),('4547db50-a429-11f1-b5ab-6ed8ca3651ef','45445fc7-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:18'),('4547dbd8-a429-11f1-b5ab-6ed8ca3651ef','45450d58-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:18'),('4547dbfd-a429-11f1-b5ab-6ed8ca3651ef','4545a872-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:18'),('4547dc21-a429-11f1-b5ab-6ed8ca3651ef','45466648-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:18'),('4547dc45-a429-11f1-b5ab-6ed8ca3651ef','45471fa2-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:18'),('455989b8-a429-11f1-b5ab-6ed8ca3651ef','454b601a-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:18'),('45598a22-a429-11f1-b5ab-6ed8ca3651ef','454c0aa5-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:18'),('45598a50-a429-11f1-b5ab-6ed8ca3651ef','454cad6b-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:18'),('45598a79-a429-11f1-b5ab-6ed8ca3651ef','454de18a-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:18'),('45598aa1-a429-11f1-b5ab-6ed8ca3651ef','454e8d5c-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:18'),('45598ac9-a429-11f1-b5ab-6ed8ca3651ef','454f5651-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:18'),('45598aed-a429-11f1-b5ab-6ed8ca3651ef','454ff350-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:18'),('45598b17-a429-11f1-b5ab-6ed8ca3651ef','45514ff6-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:18'),('45598b3f-a429-11f1-b5ab-6ed8ca3651ef','4552843b-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:18'),('45598b64-a429-11f1-b5ab-6ed8ca3651ef','45533c9a-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:18'),('45598b88-a429-11f1-b5ab-6ed8ca3651ef','4553e786-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:18'),('45598bad-a429-11f1-b5ab-6ed8ca3651ef','45549dba-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:18'),('45598bd1-a429-11f1-b5ab-6ed8ca3651ef','45555361-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:18'),('45598bf7-a429-11f1-b5ab-6ed8ca3651ef','4556df8d-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:18'),('45598c1b-a429-11f1-b5ab-6ed8ca3651ef','455892ac-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:18'),('456f668a-a429-11f1-b5ab-6ed8ca3651ef','455d937c-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:19'),('456f66f6-a429-11f1-b5ab-6ed8ca3651ef','455e4ea7-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:19'),('456f6723-a429-11f1-b5ab-6ed8ca3651ef','455ef8cb-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:19'),('456f674b-a429-11f1-b5ab-6ed8ca3651ef','45600a9c-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:19'),('456f6771-a429-11f1-b5ab-6ed8ca3651ef','4560cf1f-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:19'),('456f6794-a429-11f1-b5ab-6ed8ca3651ef','45641890-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:19'),('456f67b9-a429-11f1-b5ab-6ed8ca3651ef','4564bdc7-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:19'),('456f67df-a429-11f1-b5ab-6ed8ca3651ef','45659232-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:19'),('456f6806-a429-11f1-b5ab-6ed8ca3651ef','4566730f-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:19'),('456f682b-a429-11f1-b5ab-6ed8ca3651ef','456794fc-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:19'),('456f6852-a429-11f1-b5ab-6ed8ca3651ef','45690160-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:19'),('456f6875-a429-11f1-b5ab-6ed8ca3651ef','456b0d0e-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:19'),('456f6898-a429-11f1-b5ab-6ed8ca3651ef','456bef2e-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:19'),('456f68bf-a429-11f1-b5ab-6ed8ca3651ef','456d1687-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:19'),('456f68e3-a429-11f1-b5ab-6ed8ca3651ef','456e9d11-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:19'),('457fac30-a429-11f1-b5ab-6ed8ca3651ef','45740573-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:19'),('457fac90-a429-11f1-b5ab-6ed8ca3651ef','4574e233-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:19'),('457facbd-a429-11f1-b5ab-6ed8ca3651ef','45758a54-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:19'),('457face3-a429-11f1-b5ab-6ed8ca3651ef','45762d36-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:19'),('457fad0b-a429-11f1-b5ab-6ed8ca3651ef','45770f42-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:19'),('457fad33-a429-11f1-b5ab-6ed8ca3651ef','4577b86c-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:19'),('457fad59-a429-11f1-b5ab-6ed8ca3651ef','457852aa-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:19'),('457fad7b-a429-11f1-b5ab-6ed8ca3651ef','4578f0fb-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:19'),('457fada4-a429-11f1-b5ab-6ed8ca3651ef','457a264e-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:19'),('457fadc9-a429-11f1-b5ab-6ed8ca3651ef','457b22c5-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:19'),('457fadeb-a429-11f1-b5ab-6ed8ca3651ef','457c2630-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:19'),('457fae11-a429-11f1-b5ab-6ed8ca3651ef','457cb991-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:19'),('457fae35-a429-11f1-b5ab-6ed8ca3651ef','457d7865-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:19'),('457fae5a-a429-11f1-b5ab-6ed8ca3651ef','457e1fbe-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:19'),('457fae7c-a429-11f1-b5ab-6ed8ca3651ef','457ec6ba-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:19'),('458c333b-a429-11f1-b5ab-6ed8ca3651ef','45835176-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:19'),('458c3398-a429-11f1-b5ab-6ed8ca3651ef','4584b8a6-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:19'),('458c33c4-a429-11f1-b5ab-6ed8ca3651ef','45856a16-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:19'),('458c33f3-a429-11f1-b5ab-6ed8ca3651ef','4586087e-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:19'),('458c341c-a429-11f1-b5ab-6ed8ca3651ef','45873b5c-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:19'),('458c3445-a429-11f1-b5ab-6ed8ca3651ef','4587ec3c-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:19'),('458c346d-a429-11f1-b5ab-6ed8ca3651ef','45893fd0-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:19'),('458c3495-a429-11f1-b5ab-6ed8ca3651ef','458a07c7-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:19'),('458c34c0-a429-11f1-b5ab-6ed8ca3651ef','458acab5-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:19'),('458c34e4-a429-11f1-b5ab-6ed8ca3651ef','458b871d-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:19'),('4598d4dd-a429-11f1-b5ab-6ed8ca3651ef','458fc5cd-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:19'),('4598d548-a429-11f1-b5ab-6ed8ca3651ef','459088e1-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:19'),('4598d574-a429-11f1-b5ab-6ed8ca3651ef','45912b22-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:19'),('4598d59f-a429-11f1-b5ab-6ed8ca3651ef','4591e370-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:19'),('4598d5d7-a429-11f1-b5ab-6ed8ca3651ef','4592b9d5-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:19'),('4598d601-a429-11f1-b5ab-6ed8ca3651ef','459423f1-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:19'),('4598d626-a429-11f1-b5ab-6ed8ca3651ef','4594eb0f-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:19'),('4598d64a-a429-11f1-b5ab-6ed8ca3651ef','45966ce3-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:19'),('4598d66f-a429-11f1-b5ab-6ed8ca3651ef','459755b5-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:19'),('4598d695-a429-11f1-b5ab-6ed8ca3651ef','459813e3-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:19'),('45ab3325-a429-11f1-b5ab-6ed8ca3651ef','459f4fd1-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:19'),('45ab3399-a429-11f1-b5ab-6ed8ca3651ef','45a05c21-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:19'),('45ab33c6-a429-11f1-b5ab-6ed8ca3651ef','45a0f4d4-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:19'),('45ab33ef-a429-11f1-b5ab-6ed8ca3651ef','45a1c8c0-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:19'),('45ab3418-a429-11f1-b5ab-6ed8ca3651ef','45a2b1b9-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:19'),('45ab343f-a429-11f1-b5ab-6ed8ca3651ef','45a370a5-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:19'),('45ab3467-a429-11f1-b5ab-6ed8ca3651ef','45a42dc3-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:19'),('45ab348c-a429-11f1-b5ab-6ed8ca3651ef','45a4cf61-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:19'),('45ab34b4-a429-11f1-b5ab-6ed8ca3651ef','45a58c20-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:19'),('45ab34d9-a429-11f1-b5ab-6ed8ca3651ef','45a63089-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:19'),('45ab34fe-a429-11f1-b5ab-6ed8ca3651ef','45a6f89f-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:19'),('45ab3523-a429-11f1-b5ab-6ed8ca3651ef','45a818a0-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:19'),('45ab35ad-a429-11f1-b5ab-6ed8ca3651ef','45a8c476-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:19'),('45ab35d7-a429-11f1-b5ab-6ed8ca3651ef','45a983ba-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:19'),('45ab35fe-a429-11f1-b5ab-6ed8ca3651ef','45aa4ca9-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:19'),('45bcfc13-a429-11f1-b5ab-6ed8ca3651ef','45b30385-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:19'),('45bcfc85-a429-11f1-b5ab-6ed8ca3651ef','45b3ad3e-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:19'),('45bcfcc4-a429-11f1-b5ab-6ed8ca3651ef','45b443fc-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:19'),('45bcfd10-a429-11f1-b5ab-6ed8ca3651ef','45b4ed2b-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:19'),('45bcfd48-a429-11f1-b5ab-6ed8ca3651ef','45b5e3a4-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:19'),('45bcfd87-a429-11f1-b5ab-6ed8ca3651ef','45b7c62b-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:19'),('45bcfdbf-a429-11f1-b5ab-6ed8ca3651ef','45b8baff-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:19'),('45bcfde9-a429-11f1-b5ab-6ed8ca3651ef','45b96282-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:19'),('45bcfe10-a429-11f1-b5ab-6ed8ca3651ef','45ba1ef6-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:19'),('45bcfe35-a429-11f1-b5ab-6ed8ca3651ef','45bab8f0-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:19'),('45d24386-a429-11f1-b5ab-6ed8ca3651ef','45c28e3f-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:19'),('45d24412-a429-11f1-b5ab-6ed8ca3651ef','45c39c24-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:19'),('45d24453-a429-11f1-b5ab-6ed8ca3651ef','45c44d68-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:19'),('45d2448d-a429-11f1-b5ab-6ed8ca3651ef','45c516e9-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:19'),('45d244c7-a429-11f1-b5ab-6ed8ca3651ef','45c5cec3-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:19'),('45d24503-a429-11f1-b5ab-6ed8ca3651ef','45c8a003-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:19'),('45d2453d-a429-11f1-b5ab-6ed8ca3651ef','45c93e7c-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:19'),('45d24573-a429-11f1-b5ab-6ed8ca3651ef','45cc10a0-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:19'),('45d245ab-a429-11f1-b5ab-6ed8ca3651ef','45ccce11-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:19'),('45d245e7-a429-11f1-b5ab-6ed8ca3651ef','45cd673b-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:19'),('45d24622-a429-11f1-b5ab-6ed8ca3651ef','45ce08c7-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:19'),('45d2465d-a429-11f1-b5ab-6ed8ca3651ef','45cf5fd3-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:19'),('45d2469f-a429-11f1-b5ab-6ed8ca3651ef','45d013ae-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:19'),('45d246de-a429-11f1-b5ab-6ed8ca3651ef','45d0ff40-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:19'),('45d24719-a429-11f1-b5ab-6ed8ca3651ef','45d19ee7-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:19'),('45e0a635-a429-11f1-b5ab-6ed8ca3651ef','45d6408b-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:19'),('45e0a69b-a429-11f1-b5ab-6ed8ca3651ef','45d72b63-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:19'),('45e0a6c9-a429-11f1-b5ab-6ed8ca3651ef','45d8334d-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:19'),('45e0a6f4-a429-11f1-b5ab-6ed8ca3651ef','45d9776a-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:19'),('45e0a71c-a429-11f1-b5ab-6ed8ca3651ef','45da1543-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:19'),('45e0a744-a429-11f1-b5ab-6ed8ca3651ef','45db61b5-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:19'),('45e0a76b-a429-11f1-b5ab-6ed8ca3651ef','45dc2e7f-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:19'),('45e0a791-a429-11f1-b5ab-6ed8ca3651ef','45dcede8-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:19'),('45e0a7bb-a429-11f1-b5ab-6ed8ca3651ef','45df019d-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:19'),('45e0a7e2-a429-11f1-b5ab-6ed8ca3651ef','45dfb425-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:19'),('45f1da76-a429-11f1-b5ab-6ed8ca3651ef','45e4be13-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:19'),('45f1dacd-a429-11f1-b5ab-6ed8ca3651ef','45e5c461-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:19'),('45f1daf9-a429-11f1-b5ab-6ed8ca3651ef','45e66217-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:19'),('45f1db1e-a429-11f1-b5ab-6ed8ca3651ef','45e711fa-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:19'),('45f1db44-a429-11f1-b5ab-6ed8ca3651ef','45e7b506-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:19'),('45f1db66-a429-11f1-b5ab-6ed8ca3651ef','45e8571d-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:19'),('45f1db8b-a429-11f1-b5ab-6ed8ca3651ef','45e8efd1-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:19'),('45f1dbb0-a429-11f1-b5ab-6ed8ca3651ef','45e99cb0-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:19'),('45f1dbd6-a429-11f1-b5ab-6ed8ca3651ef','45eab50a-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:19'),('45f1dbf9-a429-11f1-b5ab-6ed8ca3651ef','45ec4ea5-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:19'),('45f1dc21-a429-11f1-b5ab-6ed8ca3651ef','45edabaf-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:19'),('45f1dc43-a429-11f1-b5ab-6ed8ca3651ef','45eebd2f-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:19'),('45f1dc6a-a429-11f1-b5ab-6ed8ca3651ef','45ef5eb3-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:19'),('45f1dc8b-a429-11f1-b5ab-6ed8ca3651ef','45f04a0a-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:19'),('45f1dcad-a429-11f1-b5ab-6ed8ca3651ef','45f10c6e-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:19'),('45ffd61d-a429-11f1-b5ab-6ed8ca3651ef','45f6537e-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:20'),('45ffd67e-a429-11f1-b5ab-6ed8ca3651ef','45f762d4-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:20'),('45ffd6a7-a429-11f1-b5ab-6ed8ca3651ef','45f886da-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:20'),('45ffd6cd-a429-11f1-b5ab-6ed8ca3651ef','45f9a7a5-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:20'),('45ffd6f1-a429-11f1-b5ab-6ed8ca3651ef','45fa4c49-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:20'),('45ffd716-a429-11f1-b5ab-6ed8ca3651ef','45fb18ac-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:20'),('45ffd737-a429-11f1-b5ab-6ed8ca3651ef','45fbc2a5-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:20'),('45ffd75a-a429-11f1-b5ab-6ed8ca3651ef','45fc7af2-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:20'),('45ffd77f-a429-11f1-b5ab-6ed8ca3651ef','45fd9997-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:20'),('45ffd7a2-a429-11f1-b5ab-6ed8ca3651ef','45ff2fa5-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:20'),('46103b63-a429-11f1-b5ab-6ed8ca3651ef','4604b946-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:20'),('46103bc4-a429-11f1-b5ab-6ed8ca3651ef','46060204-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:20'),('46103bf2-a429-11f1-b5ab-6ed8ca3651ef','4606990f-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:20'),('46103c1a-a429-11f1-b5ab-6ed8ca3651ef','46077611-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:20'),('46103c40-a429-11f1-b5ab-6ed8ca3651ef','46081f4e-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:20'),('46103c64-a429-11f1-b5ab-6ed8ca3651ef','46091b2a-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:20'),('46103c88-a429-11f1-b5ab-6ed8ca3651ef','4609b7b6-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:20'),('46103cae-a429-11f1-b5ab-6ed8ca3651ef','460a7b24-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:20'),('46103cd3-a429-11f1-b5ab-6ed8ca3651ef','460b2fff-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:20'),('46103cfa-a429-11f1-b5ab-6ed8ca3651ef','460bcbe7-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:20'),('46103d1f-a429-11f1-b5ab-6ed8ca3651ef','460c7d63-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:20'),('46103d45-a429-11f1-b5ab-6ed8ca3651ef','460dc325-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:20'),('46103d69-a429-11f1-b5ab-6ed8ca3651ef','460e5d25-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:20'),('46103d8c-a429-11f1-b5ab-6ed8ca3651ef','460ef4e6-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:20'),('46103db0-a429-11f1-b5ab-6ed8ca3651ef','460f960c-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:20'),('461f51c6-a429-11f1-b5ab-6ed8ca3651ef','4613f7bd-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:20'),('461f522f-a429-11f1-b5ab-6ed8ca3651ef','46158df3-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:20'),('461f525b-a429-11f1-b5ab-6ed8ca3651ef','46163340-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:20'),('461f5284-a429-11f1-b5ab-6ed8ca3651ef','4616d314-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:20'),('461f52ac-a429-11f1-b5ab-6ed8ca3651ef','461768a2-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:20'),('461f52d1-a429-11f1-b5ab-6ed8ca3651ef','461818a2-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:20'),('461f52f7-a429-11f1-b5ab-6ed8ca3651ef','4618ac13-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:20'),('461f531c-a429-11f1-b5ab-6ed8ca3651ef','46195452-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:20'),('461f5344-a429-11f1-b5ab-6ed8ca3651ef','461a866d-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:20'),('461f5367-a429-11f1-b5ab-6ed8ca3651ef','461b1ed0-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:20'),('461f538b-a429-11f1-b5ab-6ed8ca3651ef','461bfeb4-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:20'),('461f53ae-a429-11f1-b5ab-6ed8ca3651ef','461ce135-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:20'),('461f53d0-a429-11f1-b5ab-6ed8ca3651ef','461d7645-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:20'),('461f53f3-a429-11f1-b5ab-6ed8ca3651ef','461e123f-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:20'),('461f5418-a429-11f1-b5ab-6ed8ca3651ef','461eac3e-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:20'),('462e9585-a429-11f1-b5ab-6ed8ca3651ef','4622e079-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:20'),('462e95eb-a429-11f1-b5ab-6ed8ca3651ef','462372f0-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:20'),('462e9618-a429-11f1-b5ab-6ed8ca3651ef','462415a5-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:20'),('462e963d-a429-11f1-b5ab-6ed8ca3651ef','4624afc4-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:20'),('462e9665-a429-11f1-b5ab-6ed8ca3651ef','46254047-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:20'),('462e968b-a429-11f1-b5ab-6ed8ca3651ef','46266e80-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:20'),('462e96af-a429-11f1-b5ab-6ed8ca3651ef','462746ed-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:20'),('462e96d2-a429-11f1-b5ab-6ed8ca3651ef','4627e376-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:20'),('462e96f6-a429-11f1-b5ab-6ed8ca3651ef','462871e4-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:20'),('462e9718-a429-11f1-b5ab-6ed8ca3651ef','4629ae2d-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:20'),('462e973a-a429-11f1-b5ab-6ed8ca3651ef','462a62c5-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:20'),('462e975e-a429-11f1-b5ab-6ed8ca3651ef','462af71d-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:20'),('462e9780-a429-11f1-b5ab-6ed8ca3651ef','462ba79d-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:20'),('462e97a3-a429-11f1-b5ab-6ed8ca3651ef','462c3e04-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:20'),('462e97c8-a429-11f1-b5ab-6ed8ca3651ef','462db402-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:20'),('463a267a-a429-11f1-b5ab-6ed8ca3651ef','46315bd1-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:20'),('463a26e0-a429-11f1-b5ab-6ed8ca3651ef','46326b83-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:20'),('463a270c-a429-11f1-b5ab-6ed8ca3651ef','463305ce-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:20'),('463a2736-a429-11f1-b5ab-6ed8ca3651ef','46339c85-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:20'),('463a275f-a429-11f1-b5ab-6ed8ca3651ef','463430e8-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:20'),('463a2785-a429-11f1-b5ab-6ed8ca3651ef','4634d1a0-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:20'),('463a27ae-a429-11f1-b5ab-6ed8ca3651ef','463592d6-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:20'),('463a27d4-a429-11f1-b5ab-6ed8ca3651ef','463650a1-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:20'),('463a2800-a429-11f1-b5ab-6ed8ca3651ef','463718d1-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:20'),('463a2825-a429-11f1-b5ab-6ed8ca3651ef','46393bec-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:20'),('464b64e4-a429-11f1-b5ab-6ed8ca3651ef','463e4d5c-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:20'),('464b6551-a429-11f1-b5ab-6ed8ca3651ef','463f0f14-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:20'),('464b6580-a429-11f1-b5ab-6ed8ca3651ef','463fcafb-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:20'),('464b65ae-a429-11f1-b5ab-6ed8ca3651ef','464086cb-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:20'),('464b65d3-a429-11f1-b5ab-6ed8ca3651ef','46420fdb-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:20'),('464b65f9-a429-11f1-b5ab-6ed8ca3651ef','4642bf67-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:20'),('464b6622-a429-11f1-b5ab-6ed8ca3651ef','464397f5-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:20'),('464b6648-a429-11f1-b5ab-6ed8ca3651ef','46448250-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:20'),('464b6673-a429-11f1-b5ab-6ed8ca3651ef','46451fc4-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:20'),('464b6696-a429-11f1-b5ab-6ed8ca3651ef','4645d873-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:20'),('464b66bb-a429-11f1-b5ab-6ed8ca3651ef','46468e26-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:20'),('464b66e0-a429-11f1-b5ab-6ed8ca3651ef','46472dd4-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:20'),('464b6704-a429-11f1-b5ab-6ed8ca3651ef','4647fd9c-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:20'),('464b6728-a429-11f1-b5ab-6ed8ca3651ef','46495fbe-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:20'),('464b674a-a429-11f1-b5ab-6ed8ca3651ef','464ab9c6-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:20'),('4658f899-a429-11f1-b5ab-6ed8ca3651ef','464f60cb-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:20'),('4658f8fd-a429-11f1-b5ab-6ed8ca3651ef','465093a3-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:20'),('4658f928-a429-11f1-b5ab-6ed8ca3651ef','465135a9-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:20'),('4658f94d-a429-11f1-b5ab-6ed8ca3651ef','4651e147-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:20'),('4658f973-a429-11f1-b5ab-6ed8ca3651ef','4652afbf-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:20'),('4658f99a-a429-11f1-b5ab-6ed8ca3651ef','46536b35-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:20'),('4658f9bf-a429-11f1-b5ab-6ed8ca3651ef','46540ae0-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:20'),('4658f9e3-a429-11f1-b5ab-6ed8ca3651ef','4656f6d2-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:20'),('4658fa0c-a429-11f1-b5ab-6ed8ca3651ef','4657a335-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:20'),('4658fa31-a429-11f1-b5ab-6ed8ca3651ef','4658443f-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:20'),('466b6d51-a429-11f1-b5ab-6ed8ca3651ef','465d887e-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:20'),('466b6dbb-a429-11f1-b5ab-6ed8ca3651ef','465e538e-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:20'),('466b6de9-a429-11f1-b5ab-6ed8ca3651ef','465f29b9-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:20'),('466b6e17-a429-11f1-b5ab-6ed8ca3651ef','46605c36-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:20'),('466b6e3f-a429-11f1-b5ab-6ed8ca3651ef','46619f0a-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:20'),('466b6e66-a429-11f1-b5ab-6ed8ca3651ef','4662d97a-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:20'),('466b6e8f-a429-11f1-b5ab-6ed8ca3651ef','4663958a-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:20'),('466b6eb6-a429-11f1-b5ab-6ed8ca3651ef','466454bf-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:20'),('466b6edd-a429-11f1-b5ab-6ed8ca3651ef','46655816-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:20'),('466b6f04-a429-11f1-b5ab-6ed8ca3651ef','4665fed6-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:20'),('466b6f29-a429-11f1-b5ab-6ed8ca3651ef','4666ab70-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:20'),('466b6f4f-a429-11f1-b5ab-6ed8ca3651ef','46674773-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:20'),('466b6f73-a429-11f1-b5ab-6ed8ca3651ef','4667de7f-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:20'),('466b6f99-a429-11f1-b5ab-6ed8ca3651ef','4668936d-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:20'),('466b6fc0-a429-11f1-b5ab-6ed8ca3651ef','466a8320-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:20'),('46798384-a429-11f1-b5ab-6ed8ca3651ef','466f2232-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:20'),('467983e7-a429-11f1-b5ab-6ed8ca3651ef','46719e2e-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:20'),('46798413-a429-11f1-b5ab-6ed8ca3651ef','46725951-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:20'),('4679843b-a429-11f1-b5ab-6ed8ca3651ef','46730a53-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:20'),('46798465-a429-11f1-b5ab-6ed8ca3651ef','46742a49-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:20'),('4679848b-a429-11f1-b5ab-6ed8ca3651ef','46752684-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:20'),('467984b4-a429-11f1-b5ab-6ed8ca3651ef','4675e084-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:20'),('467984da-a429-11f1-b5ab-6ed8ca3651ef','4676f2de-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:20'),('467984ff-a429-11f1-b5ab-6ed8ca3651ef','4677b61a-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:20'),('46798526-a429-11f1-b5ab-6ed8ca3651ef','46788f50-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:20'),('468e983e-a429-11f1-b5ab-6ed8ca3651ef','467d81f1-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:20'),('468e98ae-a429-11f1-b5ab-6ed8ca3651ef','467eabb1-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:20'),('468e98dc-a429-11f1-b5ab-6ed8ca3651ef','467f89c5-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:20'),('468e9909-a429-11f1-b5ab-6ed8ca3651ef','46804119-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:20'),('468e9933-a429-11f1-b5ab-6ed8ca3651ef','46817375-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:20'),('468e995f-a429-11f1-b5ab-6ed8ca3651ef','4682fb27-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:20'),('468e9987-a429-11f1-b5ab-6ed8ca3651ef','4683c935-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:20'),('468e99ae-a429-11f1-b5ab-6ed8ca3651ef','46847264-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:20'),('468e99d7-a429-11f1-b5ab-6ed8ca3651ef','46850b03-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:20'),('468e99ff-a429-11f1-b5ab-6ed8ca3651ef','46872cfd-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:20'),('468e9a25-a429-11f1-b5ab-6ed8ca3651ef','4688eaa2-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:20'),('468e9a4f-a429-11f1-b5ab-6ed8ca3651ef','46899a9e-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:20'),('468e9a77-a429-11f1-b5ab-6ed8ca3651ef','468ab600-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:20'),('468e9a9f-a429-11f1-b5ab-6ed8ca3651ef','468b7c6d-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:20'),('468e9ac4-a429-11f1-b5ab-6ed8ca3651ef','468dc9c5-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:20'),('469bfff3-a429-11f1-b5ab-6ed8ca3651ef','46928730-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:21'),('469c006c-a429-11f1-b5ab-6ed8ca3651ef','46939263-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:21'),('469c00a9-a429-11f1-b5ab-6ed8ca3651ef','46943a07-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:21'),('469c00d1-a429-11f1-b5ab-6ed8ca3651ef','469603f0-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:21'),('469c00f7-a429-11f1-b5ab-6ed8ca3651ef','4696c2f5-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:21'),('469c011b-a429-11f1-b5ab-6ed8ca3651ef','4697c3c7-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:21'),('469c0146-a429-11f1-b5ab-6ed8ca3651ef','46985cc7-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:21'),('469c016d-a429-11f1-b5ab-6ed8ca3651ef','4698f93d-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:21'),('469c0196-a429-11f1-b5ab-6ed8ca3651ef','4699c9ed-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:21'),('469c01bb-a429-11f1-b5ab-6ed8ca3651ef','469a9633-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:21'),('46aab915-a429-11f1-b5ab-6ed8ca3651ef','469ffeb5-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:21'),('46aab9ab-a429-11f1-b5ab-6ed8ca3651ef','46a0fedb-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:21'),('46aab9f1-a429-11f1-b5ab-6ed8ca3651ef','46a43afc-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:21'),('46aaba31-a429-11f1-b5ab-6ed8ca3651ef','46a4ddf2-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:21'),('46aaba71-a429-11f1-b5ab-6ed8ca3651ef','46a576be-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:21'),('46aabaaf-a429-11f1-b5ab-6ed8ca3651ef','46a71ec9-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:21'),('46aabae9-a429-11f1-b5ab-6ed8ca3651ef','46a7c47d-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:21'),('46aabb24-a429-11f1-b5ab-6ed8ca3651ef','46a89eca-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:21'),('46aabb63-a429-11f1-b5ab-6ed8ca3651ef','46a939ea-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:21'),('46aabb9d-a429-11f1-b5ab-6ed8ca3651ef','46a9d1a2-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:21'),('46bdf99d-a429-11f1-b5ab-6ed8ca3651ef','46aee405-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:21'),('46bdfa36-a429-11f1-b5ab-6ed8ca3651ef','46afa309-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:21'),('46bdfa7d-a429-11f1-b5ab-6ed8ca3651ef','46b071f1-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:21'),('46bdfabd-a429-11f1-b5ab-6ed8ca3651ef','46b12000-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:21'),('46bdfafd-a429-11f1-b5ab-6ed8ca3651ef','46b22c57-a429-11f1-b5ab-6ed8ca3651ef',15.0000,'2026-08-30 04:14:21'),('46bdfb40-a429-11f1-b5ab-6ed8ca3651ef','46b35989-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:21'),('46bdfb7c-a429-11f1-b5ab-6ed8ca3651ef','46b450e6-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:21'),('46bdfbb9-a429-11f1-b5ab-6ed8ca3651ef','46b54eea-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:21'),('46bdfbfb-a429-11f1-b5ab-6ed8ca3651ef','46b64603-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:21'),('46bdfc3a-a429-11f1-b5ab-6ed8ca3651ef','46b70d08-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:21'),('46bdfc7b-a429-11f1-b5ab-6ed8ca3651ef','46b87341-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:21'),('46bdfcba-a429-11f1-b5ab-6ed8ca3651ef','46b95b6a-a429-11f1-b5ab-6ed8ca3651ef',7.0000,'2026-08-30 04:14:21'),('46bdfcf9-a429-11f1-b5ab-6ed8ca3651ef','46b9faff-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:21'),('46bdfd37-a429-11f1-b5ab-6ed8ca3651ef','46bb569a-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:21'),('46bdfd78-a429-11f1-b5ab-6ed8ca3651ef','46bd2a5c-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:21'),('46c9d9a1-a429-11f1-b5ab-6ed8ca3651ef','46c0d6bd-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:21'),('46c9da0d-a429-11f1-b5ab-6ed8ca3651ef','46c1d52a-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:21'),('46c9da3a-a429-11f1-b5ab-6ed8ca3651ef','46c26f3c-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:21'),('46c9da60-a429-11f1-b5ab-6ed8ca3651ef','46c376a4-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:21'),('46c9da8c-a429-11f1-b5ab-6ed8ca3651ef','46c434ef-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:21'),('46c9dab2-a429-11f1-b5ab-6ed8ca3651ef','46c4f346-a429-11f1-b5ab-6ed8ca3651ef',13.0000,'2026-08-30 04:14:21'),('46c9dad6-a429-11f1-b5ab-6ed8ca3651ef','46c5cd9a-a429-11f1-b5ab-6ed8ca3651ef',5.0000,'2026-08-30 04:14:21'),('46c9dafb-a429-11f1-b5ab-6ed8ca3651ef','46c6c2c0-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:21'),('46c9db22-a429-11f1-b5ab-6ed8ca3651ef','46c807e7-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:21'),('46c9db46-a429-11f1-b5ab-6ed8ca3651ef','46c8b926-a429-11f1-b5ab-6ed8ca3651ef',8.0000,'2026-08-30 04:14:21'),('46d728b2-a429-11f1-b5ab-6ed8ca3651ef','46cd4cd6-a429-11f1-b5ab-6ed8ca3651ef',12.0000,'2026-08-30 04:14:21'),('46d72917-a429-11f1-b5ab-6ed8ca3651ef','46cdea76-a429-11f1-b5ab-6ed8ca3651ef',20.0000,'2026-08-30 04:14:21'),('46d72945-a429-11f1-b5ab-6ed8ca3651ef','46ce875c-a429-11f1-b5ab-6ed8ca3651ef',21.0000,'2026-08-30 04:14:21'),('46d72971-a429-11f1-b5ab-6ed8ca3651ef','46cf3984-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:21'),('46d7299c-a429-11f1-b5ab-6ed8ca3651ef','46d0abf1-a429-11f1-b5ab-6ed8ca3651ef',23.0000,'2026-08-30 04:14:21'),('46d729c2-a429-11f1-b5ab-6ed8ca3651ef','46d17cc8-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:21'),('46d729e9-a429-11f1-b5ab-6ed8ca3651ef','46d411dc-a429-11f1-b5ab-6ed8ca3651ef',17.0000,'2026-08-30 04:14:21'),('46d72a0d-a429-11f1-b5ab-6ed8ca3651ef','46d4cd7f-a429-11f1-b5ab-6ed8ca3651ef',6.0000,'2026-08-30 04:14:21'),('46d72a36-a429-11f1-b5ab-6ed8ca3651ef','46d5be24-a429-11f1-b5ab-6ed8ca3651ef',14.0000,'2026-08-30 04:14:21'),('46d72a5c-a429-11f1-b5ab-6ed8ca3651ef','46d66f67-a429-11f1-b5ab-6ed8ca3651ef',9.0000,'2026-08-30 04:14:21'),('46ddb0d8-a429-11f1-b5ab-6ed8ca3651ef','46dc1749-a429-11f1-b5ab-6ed8ca3651ef',11.0000,'2026-08-30 04:14:21'),('46ddb159-a429-11f1-b5ab-6ed8ca3651ef','46dcd904-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:21'),('46e29daa-a429-11f1-b5ab-6ed8ca3651ef','46e0d865-a429-11f1-b5ab-6ed8ca3651ef',16.0000,'2026-08-30 04:14:21'),('46e29e56-a429-11f1-b5ab-6ed8ca3651ef','46e1f105-a429-11f1-b5ab-6ed8ca3651ef',22.0000,'2026-08-30 04:14:21'),('46e74d12-a429-11f1-b5ab-6ed8ca3651ef','46e6a68d-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:21'),('46ec1020-a429-11f1-b5ab-6ed8ca3651ef','46ea26dd-a429-11f1-b5ab-6ed8ca3651ef',24.0000,'2026-08-30 04:14:21'),('46ec10c5-a429-11f1-b5ab-6ed8ca3651ef','46eb6422-a429-11f1-b5ab-6ed8ca3651ef',18.0000,'2026-08-30 04:14:21'),('46f1a919-a429-11f1-b5ab-6ed8ca3651ef','46f0f703-a429-11f1-b5ab-6ed8ca3651ef',19.0000,'2026-08-30 04:14:21'),('46f67873-a429-11f1-b5ab-6ed8ca3651ef','46f46c30-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:21'),('46f678d8-a429-11f1-b5ab-6ed8ca3651ef','46f5d2bb-a429-11f1-b5ab-6ed8ca3651ef',10.0000,'2026-08-30 04:14:21');
/*!40000 ALTER TABLE `inv_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_inventory_level`
--

DROP TABLE IF EXISTS `inv_inventory_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_inventory_level` (
  `inv_inventory_level_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toÃ n cá»¥c dÃ²ng Tá»“n kho',
  `cat_product_variant_id` char(36) NOT NULL COMMENT 'KhÃ³a ngoáº¡i trá» tá»›i Biáº¿n thá»ƒ SKU',
  `inv_warehouse_id` char(36) NOT NULL COMMENT 'KhÃ³a ngoáº¡i trá» tá»›i Kho chá»©a',
  `inv_inventory_level_available` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Tá»“n kháº£ dá»¥ng (Sá»‘ lÆ°á»£ng cÃ³ thá»ƒ bÃ¡n ngay láº­p tá»©c)',
  `inv_inventory_level_locked` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Tá»“n Ä‘ang khÃ³a (KhÃ¡ch Ä‘Ã£ lÃªn Ä‘Æ¡n nhÆ°ng chÆ°a Ä‘Ã³ng gÃ³i/xuáº¥t kho)',
  PRIMARY KEY (`inv_inventory_level_id`),
  UNIQUE KEY `uix_invinventorylevel_catproductvariantid_invwarehouseid` (`cat_product_variant_id`,`inv_warehouse_id`),
  KEY `ix_invinventorylevel_invwarehouseid` (`inv_warehouse_id`),
  CONSTRAINT `fk_invinventorylevel_catproductvariant` FOREIGN KEY (`cat_product_variant_id`) REFERENCES `cat_product_variant` (`cat_product_variant_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_invinventorylevel_invwarehouse` FOREIGN KEY (`inv_warehouse_id`) REFERENCES `inv_warehouse` (`inv_warehouse_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Báº£ng chá»‘t sá»‘ Tá»“n kho cá»§a tá»«ng SKU táº¡i tá»«ng Kho cá»¥ thá»ƒ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_inventory_level`
--

LOCK TABLES `inv_inventory_level` WRITE;
/*!40000 ALTER TABLE `inv_inventory_level` DISABLE KEYS */;
/*!40000 ALTER TABLE `inv_inventory_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_inventory_log`
--

DROP TABLE IF EXISTS `inv_inventory_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_inventory_log` (
  `inv_inventory_log_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID log',
  `cat_product_variant_id` char(36) NOT NULL COMMENT 'FK bien the',
  `inv_warehouse_id` char(36) NOT NULL COMMENT 'FK kho',
  `inv_inventory_log_qty` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'So luong thay doi (+ nhap, - xuat)',
  `inv_inventory_log_type` varchar(20) NOT NULL COMMENT 'Loai: sale, return, adjustment, import',
  `inv_inventory_log_reason` varchar(50) DEFAULT NULL COMMENT 'Ly do: import, damage, lost, correction, order',
  `inv_inventory_log_note` text COMMENT 'Ghi chu chi tiet',
  `inv_inventory_log_ref_id` char(36) DEFAULT NULL COMMENT 'ID tham chieu (order_id, etc)',
  `sys_user_id` char(36) DEFAULT NULL COMMENT 'Nguoi thuc hien (null = system)',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Thoi diem',
  PRIMARY KEY (`inv_inventory_log_id`),
  KEY `ix_invinventorylog_catproductvariantid` (`cat_product_variant_id`),
  KEY `ix_invinventorylog_invwarehouseid` (`inv_warehouse_id`),
  KEY `ix_invinventorylog_createddate` (`created_date`),
  CONSTRAINT `fk_invinventorylog_catproductvariant` FOREIGN KEY (`cat_product_variant_id`) REFERENCES `cat_product_variant` (`cat_product_variant_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_invinventorylog_invwarehouse` FOREIGN KEY (`inv_warehouse_id`) REFERENCES `inv_warehouse` (`inv_warehouse_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Lich su thay doi ton kho';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_inventory_log`
--

LOCK TABLES `inv_inventory_log` WRITE;
/*!40000 ALTER TABLE `inv_inventory_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `inv_inventory_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_purchase_order`
--

DROP TABLE IF EXISTS `inv_purchase_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_purchase_order` (
  `inv_purchase_order_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID Don dat hang NCC',
  `inv_purchase_order_code` varchar(20) NOT NULL COMMENT 'Ma PO (VD: PO-20260410-001)',
  `inv_supplier_id` char(36) NOT NULL COMMENT 'Khoa ngoai NCC',
  `inv_warehouse_id` char(36) NOT NULL COMMENT 'Kho nhan hang',
  `inv_purchase_order_status` tinyint NOT NULL DEFAULT '0' COMMENT '0: Draft, 1: Pending Approval, 2: Ordered, 3: Partially Received, 4: Received, 5: Completed, 6: Cancelled',
  `inv_purchase_order_total` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Tong gia tri PO',
  `inv_purchase_order_shipping_cost` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Chi phi van chuyen lo hang',
  `inv_purchase_order_notes` text COMMENT 'Ghi chu',
  `inv_purchase_order_expected_date` date DEFAULT NULL COMMENT 'Ngay du kien nhan hang',
  `inv_purchase_order_tracking_number` varchar(100) DEFAULT NULL COMMENT 'Ma van don (neu co)',
  `sys_user_id` char(36) DEFAULT NULL COMMENT 'Nguoi tao PO',
  `sys_user_approved_id` char(36) DEFAULT NULL COMMENT 'Nguoi duyet PO',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay tao',
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Ngay cap nhat',
  PRIMARY KEY (`inv_purchase_order_id`),
  UNIQUE KEY `uix_invpurchaseorder_code` (`inv_purchase_order_code`),
  KEY `ix_invpurchaseorder_invsupplierid` (`inv_supplier_id`),
  KEY `ix_invpurchaseorder_status` (`inv_purchase_order_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Don dat hang tu Nha cung cap (Purchase Order)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_purchase_order`
--

LOCK TABLES `inv_purchase_order` WRITE;
/*!40000 ALTER TABLE `inv_purchase_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `inv_purchase_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_purchase_order_item`
--

DROP TABLE IF EXISTS `inv_purchase_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_purchase_order_item` (
  `inv_purchase_order_item_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID dong PO',
  `inv_purchase_order_id` char(36) NOT NULL COMMENT 'Khoa ngoai PO',
  `cat_product_variant_id` char(36) NOT NULL COMMENT 'Khoa ngoai Variant',
  `inv_purchase_order_item_qty` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'So luong dat',
  `inv_purchase_order_item_received_qty` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'So luong da nhan',
  `inv_purchase_order_item_unit_cost` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Don gia mua',
  `inv_purchase_order_item_supplier_sku` varchar(50) DEFAULT NULL COMMENT 'Ma SKU NCC',
  PRIMARY KEY (`inv_purchase_order_item_id`),
  KEY `ix_invpurchaseorderitem_poid` (`inv_purchase_order_id`),
  KEY `ix_invpurchaseorderitem_variantid` (`cat_product_variant_id`),
  CONSTRAINT `fk_invpurchaseorderitem_invpurchaseorder` FOREIGN KEY (`inv_purchase_order_id`) REFERENCES `inv_purchase_order` (`inv_purchase_order_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_invpurchaseorderitem_variant` FOREIGN KEY (`cat_product_variant_id`) REFERENCES `cat_product_variant` (`cat_product_variant_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Chi tiet dong san pham trong PO';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_purchase_order_item`
--

LOCK TABLES `inv_purchase_order_item` WRITE;
/*!40000 ALTER TABLE `inv_purchase_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `inv_purchase_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_supplier`
--

DROP TABLE IF EXISTS `inv_supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_supplier` (
  `inv_supplier_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID nha cung cap',
  `inv_supplier_code` varchar(20) NOT NULL COMMENT 'Ma NCC (VD: NCC-001)',
  `inv_supplier_name` varchar(255) NOT NULL COMMENT 'Ten NCC',
  `inv_supplier_tax_code` varchar(50) DEFAULT NULL COMMENT 'Ma so thue',
  `inv_supplier_address` varchar(255) DEFAULT NULL COMMENT 'Dia chi',
  `inv_supplier_contact_name` varchar(100) DEFAULT NULL COMMENT 'Nguoi lien he',
  `inv_supplier_phone` varchar(50) DEFAULT NULL COMMENT 'SDT lien he',
  `inv_supplier_email` varchar(100) DEFAULT NULL COMMENT 'Email lien he',
  `inv_supplier_payment_terms` varchar(50) DEFAULT NULL COMMENT 'Dieu khoan TT (Net 30, COD...)',
  `inv_supplier_status` tinyint NOT NULL DEFAULT '1' COMMENT '0: Ngung hop tac, 1: Dang hop tac',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay tao',
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Ngay cap nhat',
  PRIMARY KEY (`inv_supplier_id`),
  UNIQUE KEY `uix_invsupplier_code` (`inv_supplier_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Danh sach Nha cung cap';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_supplier`
--

LOCK TABLES `inv_supplier` WRITE;
/*!40000 ALTER TABLE `inv_supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `inv_supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_supplier_product`
--

DROP TABLE IF EXISTS `inv_supplier_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_supplier_product` (
  `inv_supplier_product_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID lien ket NCC-SP',
  `inv_supplier_id` char(36) NOT NULL COMMENT 'Khoa ngoai NCC',
  `cat_product_variant_id` char(36) NOT NULL COMMENT 'Khoa ngoai Variant',
  `inv_supplier_product_sku` varchar(50) DEFAULT NULL COMMENT 'Ma SKU cua NCC',
  `inv_supplier_product_cost` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Gia mua tu NCC',
  `inv_supplier_product_lead_days` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'So ngay giao hang trung binh',
  `inv_supplier_product_is_primary` tinyint NOT NULL DEFAULT '0' COMMENT '1: NCC mac dinh cho variant nay',
  PRIMARY KEY (`inv_supplier_product_id`),
  UNIQUE KEY `uix_invsupplierproduct_supplier_variant` (`inv_supplier_id`,`cat_product_variant_id`),
  KEY `ix_invsupplierproduct_invsupplierid` (`inv_supplier_id`),
  KEY `ix_invsupplierproduct_variantid` (`cat_product_variant_id`),
  CONSTRAINT `fk_invsupplierproduct_invsupplier` FOREIGN KEY (`inv_supplier_id`) REFERENCES `inv_supplier` (`inv_supplier_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_invsupplierproduct_variant` FOREIGN KEY (`cat_product_variant_id`) REFERENCES `cat_product_variant` (`cat_product_variant_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Lien ket NCC voi Variant san pham';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_supplier_product`
--

LOCK TABLES `inv_supplier_product` WRITE;
/*!40000 ALTER TABLE `inv_supplier_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `inv_supplier_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_warehouse`
--

DROP TABLE IF EXISTS `inv_warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_warehouse` (
  `inv_warehouse_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toÃ n cá»¥c cá»§a Kho hÃ ng/Cá»­a hÃ ng',
  `inv_warehouse_code` varchar(20) NOT NULL COMMENT 'MÃ£ kho (VÃ­ dá»¥: KHO-HCM-01)',
  `inv_warehouse_name` varchar(255) NOT NULL COMMENT 'TÃªn gá»i Kho hoáº·c Cá»­a hÃ ng váº­t lÃ½',
  `inv_warehouse_address` varchar(255) DEFAULT NULL COMMENT 'Äá»‹a chá»‰ chi tiáº¿t cá»§a Ä‘iá»ƒm lÆ°u trá»¯',
  `inv_warehouse_status` tinyint NOT NULL DEFAULT '1' COMMENT 'Tráº¡ng thÃ¡i: 0: ÄÃ³ng cá»­a, 1: Äang hoáº¡t Ä‘á»™ng',
  PRIMARY KEY (`inv_warehouse_id`),
  UNIQUE KEY `uix_invwarehouse_invwarehousecode` (`inv_warehouse_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Danh sÃ¡ch Kho chá»©a hÃ ng vÃ  Cá»­a hÃ ng Offline';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_warehouse`
--

LOCK TABLES `inv_warehouse` WRITE;
/*!40000 ALTER TABLE `inv_warehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `inv_warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_warehouse_transfer`
--

DROP TABLE IF EXISTS `inv_warehouse_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_warehouse_transfer` (
  `inv_warehouse_transfer_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID phieu dieu chuyen kho',
  `inv_warehouse_transfer_code` varchar(20) NOT NULL COMMENT 'Ma phieu (VD: WTR-20260410-001)',
  `inv_warehouse_from_id` char(36) NOT NULL COMMENT 'Kho xuat',
  `inv_warehouse_to_id` char(36) NOT NULL COMMENT 'Kho nhan',
  `inv_warehouse_transfer_status` tinyint NOT NULL DEFAULT '0' COMMENT '0: Draft, 1: Pending Pickup, 2: In Transit, 3: Received, 4: Partially Received, 5: Completed',
  `inv_warehouse_transfer_reason` varchar(255) DEFAULT NULL COMMENT 'Ly do dieu chuyen',
  `sys_user_id` char(36) DEFAULT NULL COMMENT 'Nguoi tao phieu',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay tao',
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Ngay cap nhat',
  PRIMARY KEY (`inv_warehouse_transfer_id`),
  UNIQUE KEY `uix_invwarehousetransfer_code` (`inv_warehouse_transfer_code`),
  KEY `ix_invwarehousetransfer_fromid` (`inv_warehouse_from_id`),
  KEY `ix_invwarehousetransfer_toid` (`inv_warehouse_to_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Phieu dieu chuyen hang giua cac kho';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_warehouse_transfer`
--

LOCK TABLES `inv_warehouse_transfer` WRITE;
/*!40000 ALTER TABLE `inv_warehouse_transfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `inv_warehouse_transfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_warehouse_transfer_item`
--

DROP TABLE IF EXISTS `inv_warehouse_transfer_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_warehouse_transfer_item` (
  `inv_warehouse_transfer_item_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID dong dieu chuyen',
  `inv_warehouse_transfer_id` char(36) NOT NULL COMMENT 'Khoa ngoai phieu dieu chuyen',
  `cat_product_variant_id` char(36) NOT NULL COMMENT 'Khoa ngoai Variant',
  `inv_warehouse_transfer_item_qty` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'So luong dieu chuyen',
  `inv_warehouse_transfer_item_received_qty` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'So luong thuc nhan',
  PRIMARY KEY (`inv_warehouse_transfer_item_id`),
  KEY `ix_invwarehousetransferitem_transferid` (`inv_warehouse_transfer_id`),
  CONSTRAINT `fk_invwarehousetransferitem_transfer` FOREIGN KEY (`inv_warehouse_transfer_id`) REFERENCES `inv_warehouse_transfer` (`inv_warehouse_transfer_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Chi tiet dong dieu chuyen kho';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_warehouse_transfer_item`
--

LOCK TABLES `inv_warehouse_transfer_item` WRITE;
/*!40000 ALTER TABLE `inv_warehouse_transfer_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `inv_warehouse_transfer_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_access`
--

DROP TABLE IF EXISTS `log_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_access` (
  `log_access_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID log dang nhap',
  `sys_user_id` char(36) DEFAULT NULL COMMENT 'User (NULL neu login failed)',
  `log_access_email` varchar(100) NOT NULL COMMENT 'Email dang nhap',
  `log_access_success` tinyint NOT NULL DEFAULT '0' COMMENT '0: That bai, 1: Thanh cong',
  `log_access_ip` varchar(50) NOT NULL COMMENT 'IP address',
  `log_access_user_agent` varchar(500) DEFAULT NULL COMMENT 'Browser User-Agent',
  `log_access_geo` varchar(100) DEFAULT NULL COMMENT 'Geo location (tinh/thanh tu IP)',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Thoi diem dang nhap',
  PRIMARY KEY (`log_access_id`),
  KEY `ix_logaccess_email` (`log_access_email`),
  KEY `ix_logaccess_sysuserid` (`sys_user_id`),
  KEY `ix_logaccess_createddate` (`created_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Nhat ky dang nhap he thong (bao gom that bai)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_access`
--

LOCK TABLES `log_access` WRITE;
/*!40000 ALTER TABLE `log_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_analytics_event`
--

DROP TABLE IF EXISTS `log_analytics_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_analytics_event` (
  `log_analytics_event_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'PK â€” UUID',
  `log_analytics_event_type` varchar(50) NOT NULL COMMENT 'Event type: page_view, product_view, add_to_cart, remove_from_cart, begin_checkout, enter_shipping, select_payment, complete_order, search, wishlist_add, review_submit',
  `log_analytics_event_data` json DEFAULT NULL COMMENT 'Payload tu do (product_id, variant_id, search_term, ...)',
  `log_analytics_event_session_id` varchar(100) NOT NULL COMMENT 'Session tracking UUID (client-side)',
  `sys_customer_id` char(36) DEFAULT NULL COMMENT 'FK â†’ sys_customer. NULL neu chua dang nhap',
  `log_analytics_event_device` varchar(20) DEFAULT NULL COMMENT 'mobile / tablet / desktop',
  `log_analytics_event_source` varchar(50) DEFAULT NULL COMMENT 'utm_source / referrer',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Thoi diem event',
  PRIMARY KEY (`log_analytics_event_id`),
  KEY `ix_loganalyticsevent_eventtype_createddate` (`log_analytics_event_type`,`created_date`),
  KEY `ix_loganalyticsevent_sessionid` (`log_analytics_event_session_id`),
  KEY `ix_loganalyticsevent_syscustomerid` (`sys_customer_id`),
  KEY `ix_loganalyticsevent_createddate` (`created_date`),
  CONSTRAINT `fk_loganalyticsevent_syscustomer` FOREIGN KEY (`sys_customer_id`) REFERENCES `sys_customer` (`sys_customer_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Raw analytics events â€” page views, cart, checkout, search. Retention: 12 thang';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_analytics_event`
--

LOCK TABLES `log_analytics_event` WRITE;
/*!40000 ALTER TABLE `log_analytics_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_analytics_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_audit`
--

DROP TABLE IF EXISTS `log_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_audit` (
  `log_audit_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID audit log',
  `log_audit_action` varchar(20) NOT NULL COMMENT 'create, update, delete',
  `log_audit_entity_type` varchar(50) NOT NULL COMMENT 'product, order, customer, user, category, inventory',
  `log_audit_entity_id` char(36) NOT NULL COMMENT 'ID cua entity bi thay doi',
  `log_audit_entity_name` varchar(255) DEFAULT NULL COMMENT 'Ten doi tuong (de doc log khong can join)',
  `log_audit_changes` text COMMENT 'JSON diff { field: { old, new } }',
  `log_audit_ip` varchar(45) DEFAULT NULL COMMENT 'IP nguoi thuc hien',
  `log_audit_user_agent` varchar(500) DEFAULT NULL COMMENT 'Browser User-Agent',
  `sys_user_id` char(36) NOT NULL COMMENT 'Admin user thuc hien',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_audit_id`),
  KEY `ix_logaudit_entitytype_entityid` (`log_audit_entity_type`,`log_audit_entity_id`),
  KEY `ix_logaudit_sysuserid` (`sys_user_id`),
  KEY `ix_logaudit_createddate` (`created_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Nhat ky hanh dong admin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_audit`
--

LOCK TABLES `log_audit` WRITE;
/*!40000 ALTER TABLE `log_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_customer_rfm`
--

DROP TABLE IF EXISTS `log_customer_rfm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_customer_rfm` (
  `log_customer_rfm_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'PK â€” UUID',
  `sys_customer_id` char(36) NOT NULL COMMENT 'FK â†’ sys_customer (UNIQUE â€” 1 record per customer)',
  `log_customer_rfm_recency` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'So ngay tu don cuoi',
  `log_customer_rfm_frequency` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Tong so don hoan thanh',
  `log_customer_rfm_monetary` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Tong gia tri don hoan thanh',
  `log_customer_rfm_r_score` tinyint NOT NULL DEFAULT '1' COMMENT 'Score R (1-5)',
  `log_customer_rfm_f_score` tinyint NOT NULL DEFAULT '1' COMMENT 'Score F (1-5)',
  `log_customer_rfm_m_score` tinyint NOT NULL DEFAULT '1' COMMENT 'Score M (1-5)',
  `log_customer_rfm_segment` varchar(50) NOT NULL DEFAULT 'Lost' COMMENT 'Ten segment: Champions, Loyal Customers, Potential Loyalists, New Customers, At Risk, Cant Lose Them, Hibernating, Lost',
  `log_customer_rfm_calculated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Thoi diem tinh',
  PRIMARY KEY (`log_customer_rfm_id`),
  UNIQUE KEY `uix_logcustomerrfm_syscustomerid` (`sys_customer_id`),
  KEY `ix_logcustomerrfm_segment` (`log_customer_rfm_segment`),
  CONSTRAINT `fk_logcustomerrfm_syscustomer` FOREIGN KEY (`sys_customer_id`) REFERENCES `sys_customer` (`sys_customer_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='RFM scores per customer â€” recalc daily 01:00';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_customer_rfm`
--

LOCK TABLES `log_customer_rfm` WRITE;
/*!40000 ALTER TABLE `log_customer_rfm` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_customer_rfm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_inventory_snapshot`
--

DROP TABLE IF EXISTS `log_inventory_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_inventory_snapshot` (
  `log_inventory_snapshot_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'PK â€” UUID',
  `cat_product_variant_id` char(36) NOT NULL COMMENT 'FK â†’ cat_product_variant (SKU)',
  `inv_warehouse_id` char(36) NOT NULL COMMENT 'FK â†’ inv_warehouse (Kho)',
  `log_inventory_snapshot_available` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Ton kha dung tai thoi diem chot',
  `log_inventory_snapshot_cost` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Gia von tai thoi diem chot',
  `snapshot_date` date NOT NULL COMMENT 'Ngay chot',
  PRIMARY KEY (`log_inventory_snapshot_id`),
  UNIQUE KEY `uix_loginventorysnapshot_variant_warehouse_date` (`cat_product_variant_id`,`inv_warehouse_id`,`snapshot_date`),
  KEY `ix_loginventorysnapshot_snapshotdate` (`snapshot_date`),
  KEY `fk_loginventorysnapshot_invwarehouse` (`inv_warehouse_id`),
  CONSTRAINT `fk_loginventorysnapshot_catproductvariant` FOREIGN KEY (`cat_product_variant_id`) REFERENCES `cat_product_variant` (`cat_product_variant_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_loginventorysnapshot_invwarehouse` FOREIGN KEY (`inv_warehouse_id`) REFERENCES `inv_warehouse` (`inv_warehouse_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Chot ton kho daily 00:05 â€” de tinh turnover rate. Retention: 6 thang';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_inventory_snapshot`
--

LOCK TABLES `log_inventory_snapshot` WRITE;
/*!40000 ALTER TABLE `log_inventory_snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_inventory_snapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_payment_fee_config`
--

DROP TABLE IF EXISTS `log_payment_fee_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_payment_fee_config` (
  `log_payment_fee_config_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'PK â€” UUID',
  `log_payment_fee_config_payment_type` tinyint NOT NULL COMMENT '0:COD, 1:Bank Transfer, 2:MoMo/VNPay',
  `log_payment_fee_config_rate` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Ty le phi (VD: 0.015 = 1.5%)',
  `log_payment_fee_config_fixed` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Phi co dinh (neu co)',
  `effective_from` date NOT NULL COMMENT 'Ngay bat dau ap dung',
  `effective_to` date DEFAULT NULL COMMENT 'Ngay het hieu luc (NULL = hien tai)',
  PRIMARY KEY (`log_payment_fee_config_id`),
  KEY `ix_logpaymentfeeconfig_paymenttype` (`log_payment_fee_config_payment_type`),
  KEY `ix_logpaymentfeeconfig_effectivefrom` (`effective_from`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Ty le phi cong thanh toan â€” dung trong bao cao Lo/Lai';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_payment_fee_config`
--

LOCK TABLES `log_payment_fee_config` WRITE;
/*!40000 ALTER TABLE `log_payment_fee_config` DISABLE KEYS */;
INSERT INTO `log_payment_fee_config` VALUES ('fb85cfde-a41d-11f1-b0a9-762043079894',0,0.0100,0.0000,'2026-01-01',NULL),('fb85d3fb-a41d-11f1-b0a9-762043079894',1,0.0000,0.0000,'2026-01-01',NULL),('fb85d513-a41d-11f1-b0a9-762043079894',2,0.0150,0.0000,'2026-01-01',NULL);
/*!40000 ALTER TABLE `log_payment_fee_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_system`
--

DROP TABLE IF EXISTS `log_system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_system` (
  `log_system_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'UUID PK',
  `log_system_level` varchar(10) NOT NULL COMMENT 'Log level: DEBUG, INFO, WARN, ERROR, FATAL',
  `log_system_method` varchar(10) NOT NULL COMMENT 'HTTP method: GET, POST, PUT, DELETE, PATCH',
  `log_system_url` varchar(500) NOT NULL COMMENT 'URL path (khong bao gom host)',
  `log_system_status` smallint NOT NULL COMMENT 'HTTP status code: 200, 400, 401, 404, 500...',
  `log_system_duration` int NOT NULL DEFAULT '0' COMMENT 'Response time (ms)',
  `log_system_request_body` text COMMENT 'Request body (truncated 2KB, bo sensitive fields)',
  `log_system_error` text COMMENT 'Error message (cho 4xx/5xx)',
  `log_system_stack` text COMMENT 'Stack trace (chi ghi cho 5xx)',
  `sys_user_id` char(36) DEFAULT NULL COMMENT 'FK user da dang nhap (null neu anonymous)',
  `log_system_ip` varchar(45) DEFAULT NULL COMMENT 'Client IP address',
  `log_system_user_agent` varchar(500) DEFAULT NULL COMMENT 'Browser/client user agent',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Thoi diem ghi log',
  PRIMARY KEY (`log_system_id`),
  KEY `ix_log_system_level` (`log_system_level`),
  KEY `ix_log_system_status` (`log_system_status`),
  KEY `ix_log_system_created` (`created_date`),
  KEY `ix_log_system_method_url` (`log_system_method`,`log_system_url`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='HTTP request/response log â€” NLog style, luu 4xx/5xx + mutating 2xx';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_system`
--

LOCK TABLES `log_system` WRITE;
/*!40000 ALTER TABLE `log_system` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_system` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prm_discount_code`
--

DROP TABLE IF EXISTS `prm_discount_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prm_discount_code` (
  `prm_discount_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toan cuc cua Ma giam gia',
  `prm_discount_code` varchar(20) NOT NULL COMMENT 'Ma code (uppercase, unique)',
  `prm_discount_type` tinyint NOT NULL DEFAULT '1' COMMENT 'Loai giam: 1: Phan tram, 2: So tien co dinh',
  `prm_discount_value` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Gia tri giam (% hoac VND)',
  `prm_discount_max_amount` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Giam toi da (VND, chi ap dung khi type=1)',
  `prm_discount_conditions_json` json DEFAULT NULL COMMENT 'Dieu kien ap dung: min_order, categories, products, ...',
  `prm_discount_usage_count` int NOT NULL DEFAULT '0' COMMENT 'So lan da su dung',
  `prm_discount_max_usage` int DEFAULT NULL COMMENT 'Gioi han tong so lan su dung (NULL = unlimited)',
  `prm_discount_max_per_customer` int DEFAULT NULL COMMENT 'Gioi han moi KH (NULL = unlimited)',
  `prm_discount_start_date` datetime DEFAULT NULL COMMENT 'Ngay bat dau hieu luc',
  `prm_discount_end_date` datetime DEFAULT NULL COMMENT 'Ngay het han (NULL = vinh vien)',
  `prm_discount_stackable` tinyint NOT NULL DEFAULT '0' COMMENT 'Ket hop voi ma khac: 0: Khong, 1: Co',
  `prm_discount_status` tinyint NOT NULL DEFAULT '1' COMMENT 'Trang thai: 0: An, 1: Active',
  `prm_discount_customer_scope` tinyint NOT NULL DEFAULT '0' COMMENT 'Pham vi KH: 0: Tat ca, 1: Da dang nhap, 2: KH cu the',
  `prm_discount_customer_ids` json DEFAULT NULL COMMENT 'Danh sach sys_customer_id khi scope=2',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay tao ma',
  PRIMARY KEY (`prm_discount_id`),
  UNIQUE KEY `uix_prmdiscountcode_code` (`prm_discount_code`),
  KEY `ix_prmdiscountcode_status` (`prm_discount_status`),
  KEY `ix_prmdiscountcode_dates` (`prm_discount_start_date`,`prm_discount_end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Ma giam gia (Voucher/Coupon) cho don hang';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prm_discount_code`
--

LOCK TABLES `prm_discount_code` WRITE;
/*!40000 ALTER TABLE `prm_discount_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `prm_discount_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prm_discount_usage`
--

DROP TABLE IF EXISTS `prm_discount_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prm_discount_usage` (
  `prm_discount_usage_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toan cuc',
  `prm_discount_id` char(36) NOT NULL COMMENT 'FK tro toi Ma giam gia',
  `sys_customer_id` char(36) NOT NULL COMMENT 'FK tro toi Khach hang',
  `sal_order_id` char(36) NOT NULL COMMENT 'FK tro toi Don hang da ap dung',
  `prm_discount_usage_amount` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'So tien duoc giam',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Thoi diem su dung',
  PRIMARY KEY (`prm_discount_usage_id`),
  UNIQUE KEY `uix_prmdiscountusage_discount_order` (`prm_discount_id`,`sal_order_id`),
  KEY `ix_prmdiscountusage_discountid` (`prm_discount_id`),
  KEY `ix_prmdiscountusage_customerid` (`sys_customer_id`),
  CONSTRAINT `fk_prmdiscountusage_prmdiscount` FOREIGN KEY (`prm_discount_id`) REFERENCES `prm_discount_code` (`prm_discount_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Lich su su dung ma giam gia theo KH va don hang';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prm_discount_usage`
--

LOCK TABLES `prm_discount_usage` WRITE;
/*!40000 ALTER TABLE `prm_discount_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `prm_discount_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prm_flash_sale`
--

DROP TABLE IF EXISTS `prm_flash_sale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prm_flash_sale` (
  `prm_flash_sale_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toan cuc cua Flash Sale',
  `prm_flash_sale_title` varchar(255) NOT NULL COMMENT 'Tieu de flash sale',
  `prm_flash_sale_start_date` datetime NOT NULL COMMENT 'Thoi diem bat dau',
  `prm_flash_sale_end_date` datetime NOT NULL COMMENT 'Thoi diem ket thuc',
  `prm_flash_sale_status` tinyint NOT NULL DEFAULT '0' COMMENT 'Trang thai: 0: Draft, 1: Scheduled, 2: Active, 3: Ended',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay tao',
  PRIMARY KEY (`prm_flash_sale_id`),
  KEY `ix_prmflashsale_status` (`prm_flash_sale_status`),
  KEY `ix_prmflashsale_dates` (`prm_flash_sale_start_date`,`prm_flash_sale_end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Chuong trinh Flash Sale (giam gia co thoi han)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prm_flash_sale`
--

LOCK TABLES `prm_flash_sale` WRITE;
/*!40000 ALTER TABLE `prm_flash_sale` DISABLE KEYS */;
/*!40000 ALTER TABLE `prm_flash_sale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prm_flash_sale_item`
--

DROP TABLE IF EXISTS `prm_flash_sale_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prm_flash_sale_item` (
  `prm_flash_sale_item_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toan cuc cua Flash Sale Item',
  `prm_flash_sale_id` char(36) NOT NULL COMMENT 'FK tro toi Flash Sale',
  `cat_product_id` char(36) NOT NULL COMMENT 'FK tro toi San pham',
  `cat_product_variant_id` char(36) DEFAULT NULL COMMENT 'FK variant cu the. NULL = ap dung tat ca variant cua product',
  `prm_flash_sale_item_discount_pct` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Phan tram giam gia (10 = giam 10%)',
  `prm_flash_sale_item_sale_price` decimal(22,4) DEFAULT NULL COMMENT 'Gia sale co dinh (override discount_pct). NULL = tinh tu %',
  `prm_flash_sale_item_max_qty` int NOT NULL DEFAULT '0' COMMENT 'So luong gioi han ban trong flash sale',
  `prm_flash_sale_item_sold_qty` int NOT NULL DEFAULT '0' COMMENT 'So luong da ban',
  PRIMARY KEY (`prm_flash_sale_item_id`),
  UNIQUE KEY `uix_prmflashsaleitem_sale_product` (`prm_flash_sale_id`,`cat_product_id`),
  KEY `ix_prmflashsaleitem_flashsaleid` (`prm_flash_sale_id`),
  KEY `ix_prmflashsaleitem_productid` (`cat_product_id`),
  KEY `ix_prmflashsaleitem_variantid` (`cat_product_variant_id`),
  CONSTRAINT `fk_prmflashsaleitem_flashsale` FOREIGN KEY (`prm_flash_sale_id`) REFERENCES `prm_flash_sale` (`prm_flash_sale_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Chi tiet San pham trong Flash Sale';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prm_flash_sale_item`
--

LOCK TABLES `prm_flash_sale_item` WRITE;
/*!40000 ALTER TABLE `prm_flash_sale_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `prm_flash_sale_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prm_loyalty_config`
--

DROP TABLE IF EXISTS `prm_loyalty_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prm_loyalty_config` (
  `prm_loyalty_config_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID cau hinh loyalty',
  `prm_loyalty_config_earn_rate` decimal(18,4) NOT NULL DEFAULT '10000.0000' COMMENT 'So VND de tich 1 diem (mac dinh 10,000)',
  `prm_loyalty_config_redeem_rate` decimal(18,4) NOT NULL DEFAULT '100.0000' COMMENT 'So diem de doi 10,000 VND (mac dinh 100)',
  `prm_loyalty_config_max_redeem_percent` decimal(18,4) NOT NULL DEFAULT '50.0000' COMMENT '% toi da gia tri don duoc dung diem',
  `prm_loyalty_config_min_redeem_points` decimal(18,4) NOT NULL DEFAULT '50.0000' COMMENT 'So diem toi thieu de doi',
  `prm_loyalty_config_expiry_months` decimal(18,4) NOT NULL DEFAULT '12.0000' COMMENT 'So thang het han diem',
  `prm_loyalty_config_pending_days` decimal(18,4) NOT NULL DEFAULT '7.0000' COMMENT 'So ngay cho truoc khi diem duoc confirmed',
  `prm_loyalty_config_silver_threshold` decimal(22,4) NOT NULL DEFAULT '2000000.0000' COMMENT 'Nguong len Silver (VND/12 thang)',
  `prm_loyalty_config_gold_threshold` decimal(22,4) NOT NULL DEFAULT '5000000.0000' COMMENT 'Nguong len Gold',
  `prm_loyalty_config_platinum_threshold` decimal(22,4) NOT NULL DEFAULT '15000000.0000' COMMENT 'Nguong len Platinum',
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Ngay cap nhat',
  PRIMARY KEY (`prm_loyalty_config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Cau hinh chuong trinh Loyalty (1 record duy nhat)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prm_loyalty_config`
--

LOCK TABLES `prm_loyalty_config` WRITE;
/*!40000 ALTER TABLE `prm_loyalty_config` DISABLE KEYS */;
INSERT INTO `prm_loyalty_config` VALUES ('l0000000-0000-0000-0000-000000000001',10000.0000,100.0000,50.0000,50.0000,12.0000,7.0000,2000000.0000,5000000.0000,10000000.0000,'2026-08-30 02:53:46');
/*!40000 ALTER TABLE `prm_loyalty_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prm_loyalty_transaction`
--

DROP TABLE IF EXISTS `prm_loyalty_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prm_loyalty_transaction` (
  `prm_loyalty_transaction_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID giao dich diem',
  `sys_customer_id` char(36) NOT NULL COMMENT 'Khoa ngoai tro toi KH',
  `prm_loyalty_transaction_type` tinyint NOT NULL COMMENT 'Loai: 0: Earn, 1: Redeem, 2: Expire, 3: Refund, 4: Adjust',
  `prm_loyalty_transaction_points` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'So diem (+ tich, - tieu)',
  `prm_loyalty_transaction_balance` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'So du sau giao dich',
  `prm_loyalty_transaction_ref_type` varchar(50) DEFAULT NULL COMMENT 'Loai tham chieu: order, return, admin_adjust, birthday, event',
  `prm_loyalty_transaction_ref_id` char(36) DEFAULT NULL COMMENT 'ID doi tuong tham chieu',
  `prm_loyalty_transaction_description` varchar(255) DEFAULT NULL COMMENT 'Mo ta giao dich',
  `prm_loyalty_transaction_expires_at` datetime DEFAULT NULL COMMENT 'Ngay het han diem (chi cho type=earn)',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay giao dich',
  PRIMARY KEY (`prm_loyalty_transaction_id`),
  KEY `ix_prmloyaltytransaction_syscustomerid` (`sys_customer_id`),
  KEY `ix_prmloyaltytransaction_createddate` (`created_date`),
  KEY `ix_prmloyaltytransaction_expiresdate` (`prm_loyalty_transaction_expires_at`),
  CONSTRAINT `fk_prmloyaltytransaction_syscustomer` FOREIGN KEY (`sys_customer_id`) REFERENCES `sys_customer` (`sys_customer_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Lich su giao dich diem Loyalty';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prm_loyalty_transaction`
--

LOCK TABLES `prm_loyalty_transaction` WRITE;
/*!40000 ALTER TABLE `prm_loyalty_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `prm_loyalty_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prm_sale_campaign`
--

DROP TABLE IF EXISTS `prm_sale_campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prm_sale_campaign` (
  `prm_sale_campaign_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID chuong trinh sale',
  `prm_sale_campaign_name` varchar(255) NOT NULL COMMENT 'Ten chuong trinh (VD: Sale He 2026)',
  `prm_sale_campaign_desc` text COMMENT 'Mo ta chuong trinh',
  `prm_sale_campaign_start_date` datetime NOT NULL COMMENT 'Thoi diem bat dau',
  `prm_sale_campaign_end_date` datetime NOT NULL COMMENT 'Thoi diem ket thuc',
  `prm_sale_campaign_discount_type` tinyint NOT NULL DEFAULT '1' COMMENT 'Loai giam gia mac dinh: 1=Phan tram, 2=Gia co dinh',
  `prm_sale_campaign_discount_value` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Gia tri giam mac dinh (% hoac so tien). Ap dung cho tat ca variant trong campaign neu khong co override',
  `prm_sale_campaign_priority` tinyint NOT NULL DEFAULT '0' COMMENT 'Do uu tien (cao hon = uu tien hon khi SP thuoc nhieu campaign)',
  `prm_sale_campaign_status` tinyint NOT NULL DEFAULT '0' COMMENT '0: Draft, 1: Scheduled, 2: Active, 3: Paused, 4: Ended',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay tao',
  `modified_date` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'Ngay sua cuoi',
  PRIMARY KEY (`prm_sale_campaign_id`),
  KEY `ix_prmsalecampaign_status` (`prm_sale_campaign_status`),
  KEY `ix_prmsalecampaign_dates` (`prm_sale_campaign_start_date`,`prm_sale_campaign_end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Chuong trinh sale â€” giam gia theo dot, co thoi gian bat dau/ket thuc';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prm_sale_campaign`
--

LOCK TABLES `prm_sale_campaign` WRITE;
/*!40000 ALTER TABLE `prm_sale_campaign` DISABLE KEYS */;
/*!40000 ALTER TABLE `prm_sale_campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prm_sale_campaign_variant`
--

DROP TABLE IF EXISTS `prm_sale_campaign_variant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prm_sale_campaign_variant` (
  `prm_sale_campaign_variant_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID chi tiet',
  `prm_sale_campaign_id` char(36) NOT NULL COMMENT 'FK chuong trinh sale',
  `cat_product_variant_id` char(36) NOT NULL COMMENT 'FK variant san pham',
  `prm_sale_cv_discount_type` tinyint DEFAULT NULL COMMENT 'Override loai giam: NULL=dung default campaign, 1=%, 2=gia co dinh',
  `prm_sale_cv_discount_value` decimal(22,4) DEFAULT NULL COMMENT 'Override gia tri giam: NULL=dung default campaign',
  `prm_sale_cv_sale_price` decimal(22,4) DEFAULT NULL COMMENT 'Gia sale cuoi cung (tinh san hoac set truc tiep). NULL=tu dong tinh tu % + gia goc',
  `prm_sale_cv_status` tinyint NOT NULL DEFAULT '1' COMMENT '0: Bo qua variant nay, 1: Active trong campaign',
  PRIMARY KEY (`prm_sale_campaign_variant_id`),
  UNIQUE KEY `uix_prmsalecv_campaign_variant` (`prm_sale_campaign_id`,`cat_product_variant_id`),
  KEY `ix_prmsalecv_campaignid` (`prm_sale_campaign_id`),
  KEY `ix_prmsalecv_variantid` (`cat_product_variant_id`),
  CONSTRAINT `fk_prmsalecv_campaign` FOREIGN KEY (`prm_sale_campaign_id`) REFERENCES `prm_sale_campaign` (`prm_sale_campaign_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_prmsalecv_variant` FOREIGN KEY (`cat_product_variant_id`) REFERENCES `cat_product_variant` (`cat_product_variant_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Chi tiet gia sale per variant trong campaign â€” override hoac dung default';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prm_sale_campaign_variant`
--

LOCK TABLES `prm_sale_campaign_variant` WRITE;
/*!40000 ALTER TABLE `prm_sale_campaign_variant` DISABLE KEYS */;
/*!40000 ALTER TABLE `prm_sale_campaign_variant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sal_cart`
--

DROP TABLE IF EXISTS `sal_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sal_cart` (
  `sal_cart_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID gio hang',
  `sys_customer_id` char(36) DEFAULT NULL COMMENT 'KH (NULL = guest)',
  `sal_cart_status` tinyint NOT NULL DEFAULT '0' COMMENT '0: Active, 1: Converted, 2: Abandoned, 3: Recovered',
  `sal_cart_recovery_email_count` tinyint NOT NULL DEFAULT '0' COMMENT 'So email recovery da gui (0-3)',
  `sal_cart_last_activity` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Lan cuoi cap nhat gio hang',
  `sal_cart_recovery_discount_code` varchar(20) DEFAULT NULL COMMENT 'Ma giam gia auto-gen cho recovery',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay tao gio hang',
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Ngay cap nhat',
  PRIMARY KEY (`sal_cart_id`),
  KEY `ix_salcart_syscustomerid` (`sys_customer_id`),
  KEY `ix_salcart_status` (`sal_cart_status`),
  KEY `ix_salcart_lastactivity` (`sal_cart_last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Gio hang (theo doi abandoned cart recovery)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sal_cart`
--

LOCK TABLES `sal_cart` WRITE;
/*!40000 ALTER TABLE `sal_cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `sal_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sal_order`
--

DROP TABLE IF EXISTS `sal_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sal_order` (
  `sal_order_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toÃ n cá»¥c cá»§a ÄÆ¡n hÃ ng',
  `sal_order_code` varchar(20) NOT NULL COMMENT 'MÃ£ Ä‘Æ¡n hÃ ng hiá»ƒn thá»‹ (VÃ­ dá»¥: ORD-20240501-001)',
  `sys_customer_id` char(36) NOT NULL COMMENT 'KhÃ³a ngoáº¡i trá» tá»›i ngÆ°á»i mua',
  `sal_order_subtotal` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Tá»•ng tiá»n hÃ ng trÆ°á»›c chiáº¿t kháº¥u',
  `sal_order_discount` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Sá»‘ tiá»n Ä‘Æ°á»£c giáº£m giÃ¡ (Voucher/Flash Sale)',
  `sal_order_shipping_fee` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Chi phÃ­ váº­n chuyá»ƒn bÃ¡o khÃ¡ch',
  `sal_order_shipping_cost_actual` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Chi phi ship thuc te tra hang van chuyen (VND)',
  `sal_order_free_ship` tinyint NOT NULL DEFAULT '0' COMMENT '1=don duoc mien phi ship (subtotal >= threshold)',
  `sal_order_total` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Tá»•ng tiá»n cuá»‘i cÃ¹ng khÃ¡ch pháº£i thanh toÃ¡n',
  `sal_order_payment_type` tinyint NOT NULL DEFAULT '0' COMMENT 'Loáº¡i thanh toÃ¡n: 0: COD, 1: Chuyá»ƒn khoáº£n, 2: MoMo/VNPay',
  `sal_order_status` tinyint NOT NULL DEFAULT '0' COMMENT 'Tráº¡ng thÃ¡i Ä‘Æ¡n: 0: Chá» xÃ¡c nháº­n, 1: ÄÃ£ xÃ¡c nháº­n, 2: Äang Ä‘Ã³ng gÃ³i, 3: Äang giao, 4: HoÃ n thÃ nh, 5: ÄÃ£ há»§y, 6: Äá»•i tráº£',
  `sal_order_payment_status` tinyint NOT NULL DEFAULT '0' COMMENT 'Tráº¡ng thÃ¡i thanh toÃ¡n: 0: ChÆ°a thanh toÃ¡n, 1: ÄÃ£ thanh toÃ¡n, 2: ÄÃ£ hoÃ n tiá»n',
  `sal_order_shipping_name` varchar(100) DEFAULT NULL COMMENT 'Ten nguoi nhan',
  `sal_order_shipping_phone` varchar(50) DEFAULT NULL COMMENT 'SDT nguoi nhan',
  `sal_order_shipping_province` varchar(100) DEFAULT NULL COMMENT 'Tinh/TP',
  `sal_order_shipping_district` varchar(100) DEFAULT NULL COMMENT 'Quan/Huyen',
  `sal_order_shipping_ward` varchar(100) DEFAULT NULL COMMENT 'Phuong/Xa',
  `sal_order_shipping_address` varchar(255) DEFAULT NULL COMMENT 'Dia chi chi tiet',
  `sal_order_note` text COMMENT 'Ghi chu cua khach hang',
  `sal_order_internal_note` text COMMENT 'Ghi chu noi bo (admin)',
  `sal_order_tracking_code` varchar(50) DEFAULT NULL COMMENT 'Ma van don (GHN/GHTK)',
  `sal_order_shipping_provider` varchar(20) DEFAULT NULL COMMENT 'Ma don vi VC: GHN, GHTK, NINJA_VAN',
  `sal_order_shipping_status` tinyint NOT NULL DEFAULT '0' COMMENT '0=chua_giao, 1=cho_lay_hang, 2=da_lay_hang, 3=dang_van_chuyen, 4=dang_giao, 5=giao_thanh_cong, 6=giao_that_bai, 7=dang_giao_lai, 8=hoan_hang, 9=mat_hang, 10=hu_hong',
  `sal_order_delivery_attempts` int NOT NULL DEFAULT '1' COMMENT 'So lan giao hang (1=binh thuong, 2+=giao lai)',
  `sal_order_shipping_extra_cost` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Tong phu phi ship phat sinh (giao lai, ...)',
  `sal_order_has_incident` tinyint NOT NULL DEFAULT '0' COMMENT '1=don co su co van chuyen',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'NgÃ y giá» phÃ¡t sinh Ä‘Æ¡n hÃ ng',
  `modified_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Ngay cap nhat',
  PRIMARY KEY (`sal_order_id`),
  UNIQUE KEY `uix_salorder_salordercode` (`sal_order_code`),
  KEY `ix_salorder_syscustomerid` (`sys_customer_id`),
  KEY `ix_salorder_createddate` (`created_date`),
  KEY `ix_sal_order_status_created` (`sal_order_status`,`created_date`),
  FULLTEXT KEY `ftx_sal_order_code` (`sal_order_code`),
  CONSTRAINT `fk_salorder_syscustomer` FOREIGN KEY (`sys_customer_id`) REFERENCES `sys_customer` (`sys_customer_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='ThÃ´ng tin Header cá»§a ÄÆ¡n hÃ ng bÃ¡n ra';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sal_order`
--

LOCK TABLES `sal_order` WRITE;
/*!40000 ALTER TABLE `sal_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `sal_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sal_order_item`
--

DROP TABLE IF EXISTS `sal_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sal_order_item` (
  `sal_order_item_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toÃ n cá»¥c cá»§a Chi tiáº¿t ÄÆ¡n hÃ ng',
  `sal_order_id` char(36) NOT NULL COMMENT 'KhÃ³a ngoáº¡i trá» tá»›i ÄÆ¡n hÃ ng gá»‘c',
  `cat_product_variant_id` char(36) NOT NULL COMMENT 'KhÃ³a ngoáº¡i trá» tá»›i Biáº¿n thá»ƒ SKU Ä‘Ã£ mua',
  `sal_order_item_qty` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Sá»‘ lÆ°á»£ng sáº£n pháº©m khÃ¡ch mua',
  `sal_order_item_price` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'ÄÆ¡n giÃ¡ lÃºc chá»‘t Ä‘Æ¡n (Báº£o toÃ n lá»‹ch sá»­ giÃ¡)',
  `sal_order_item_cost` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'GiÃ¡ vá»‘n COGS lÃºc chá»‘t Ä‘Æ¡n (DÃ¹ng tÃ­nh Lá»—/LÃ£i chÃ­nh xÃ¡c)',
  PRIMARY KEY (`sal_order_item_id`),
  KEY `ix_salorderitem_salorderid` (`sal_order_id`),
  KEY `ix_salorderitem_catproductvariantid` (`cat_product_variant_id`),
  CONSTRAINT `fk_salorderitem_catproductvariant` FOREIGN KEY (`cat_product_variant_id`) REFERENCES `cat_product_variant` (`cat_product_variant_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_salorderitem_salorder` FOREIGN KEY (`sal_order_id`) REFERENCES `sal_order` (`sal_order_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Chi tiáº¿t Sáº£n pháº©m trong ÄÆ¡n hÃ ng (DÃ²ng Ä‘Æ¡n)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sal_order_item`
--

LOCK TABLES `sal_order_item` WRITE;
/*!40000 ALTER TABLE `sal_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sal_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sal_order_timeline`
--

DROP TABLE IF EXISTS `sal_order_timeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sal_order_timeline` (
  `sal_order_timeline_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID timeline entry',
  `sal_order_id` char(36) NOT NULL COMMENT 'FK don hang',
  `sal_order_timeline_step` tinyint NOT NULL COMMENT 'Buoc timeline (0-6)',
  `sal_order_timeline_status` varchar(30) NOT NULL COMMENT 'Trang thai text',
  `sal_order_timeline_label` varchar(100) NOT NULL COMMENT 'Nhan hien thi',
  `sal_order_timeline_note` text COMMENT 'Ghi chu',
  `sal_order_timeline_actor` varchar(100) DEFAULT NULL COMMENT 'Nguoi thuc hien (email hoac system)',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Thoi diem',
  PRIMARY KEY (`sal_order_timeline_id`),
  KEY `ix_salordertimeline_salorderid` (`sal_order_id`),
  CONSTRAINT `fk_salordertimeline_salorder` FOREIGN KEY (`sal_order_id`) REFERENCES `sal_order` (`sal_order_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Hanh trinh don hang theo thoi gian';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sal_order_timeline`
--

LOCK TABLES `sal_order_timeline` WRITE;
/*!40000 ALTER TABLE `sal_order_timeline` DISABLE KEYS */;
/*!40000 ALTER TABLE `sal_order_timeline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sal_payment`
--

DROP TABLE IF EXISTS `sal_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sal_payment` (
  `sal_payment_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toan cuc giao dich thanh toan',
  `sal_order_id` char(36) NOT NULL COMMENT 'Khoa ngoai tro toi Don hang',
  `sal_payment_method` tinyint NOT NULL DEFAULT '0' COMMENT 'Phuong thuc: 0: COD, 1: Bank Transfer, 2: MoMo, 3: VNPAY, 4: Payoo, 5: ZaloPay',
  `sal_payment_amount` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'So tien giao dich',
  `sal_payment_fee` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Phi cong thanh toan (tinh vao P&L)',
  `sal_payment_status` tinyint NOT NULL DEFAULT '0' COMMENT 'Trang thai: 0: Pending, 1: Success, 2: Failed, 3: Refunded, 4: Expired',
  `sal_payment_transaction_id` varchar(100) DEFAULT NULL COMMENT 'Ma giao dich tu gateway (momo transId, vnpay TransactionNo...)',
  `sal_payment_gateway_response` text COMMENT 'Raw JSON response tu gateway (debug)',
  `sal_payment_proof_image` varchar(500) DEFAULT NULL COMMENT 'URL anh chung minh da chuyen khoan (KH upload)',
  `sal_payment_admin_note` text COMMENT 'Ghi chu admin khi duyet/tu choi',
  `sal_payment_reviewed_by` char(36) DEFAULT NULL COMMENT 'Admin ID nguoi duyet',
  `sal_payment_reviewed_at` datetime DEFAULT NULL COMMENT 'Thoi diem duyet',
  `sal_payment_redirect_url` varchar(500) DEFAULT NULL COMMENT 'URL redirect sang gateway',
  `sal_payment_expires_at` datetime DEFAULT NULL COMMENT 'Thoi diem het han giao dich (15 phut)',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay tao giao dich',
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Ngay cap nhat cuoi',
  PRIMARY KEY (`sal_payment_id`),
  UNIQUE KEY `uix_salpayment_salpaymenttransactionid` (`sal_payment_transaction_id`),
  KEY `ix_salpayment_salorderid` (`sal_order_id`),
  KEY `ix_salpayment_salpaymentstatus` (`sal_payment_status`),
  CONSTRAINT `fk_salpayment_salorder` FOREIGN KEY (`sal_order_id`) REFERENCES `sal_order` (`sal_order_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Giao dich thanh toan online (MoMo, VNPAY, Payoo, ZaloPay)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sal_payment`
--

LOCK TABLES `sal_payment` WRITE;
/*!40000 ALTER TABLE `sal_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `sal_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sal_payment_method_config`
--

DROP TABLE IF EXISTS `sal_payment_method_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sal_payment_method_config` (
  `sal_payment_method_config_id` char(36) NOT NULL DEFAULT (uuid()),
  `sal_payment_method_config_method` tinyint NOT NULL COMMENT '0=COD, 1=BankTransfer, 2=MoMo, 3=VNPAY, 4=Payoo, 5=ZaloPay',
  `sal_payment_method_config_name` varchar(50) NOT NULL COMMENT 'Ten hien thi: Chuyen khoan, MoMo, ...',
  `sal_payment_method_config_qr_image` varchar(500) DEFAULT NULL COMMENT 'URL anh QR thanh toan',
  `sal_payment_method_config_account_name` varchar(100) DEFAULT NULL COMMENT 'Ten tai khoan',
  `sal_payment_method_config_account_number` varchar(50) DEFAULT NULL COMMENT 'So tai khoan / SDT',
  `sal_payment_method_config_bank_name` varchar(100) DEFAULT NULL COMMENT 'Ten ngan hang (neu CK)',
  `sal_payment_method_config_instructions` text COMMENT 'Huong dan thanh toan (HTML/text)',
  `sal_payment_method_config_status` tinyint NOT NULL DEFAULT '1' COMMENT '0=tat, 1=bat',
  `sal_payment_method_config_sort_order` int NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sal_payment_method_config_id`),
  UNIQUE KEY `uix_payment_method_config_method` (`sal_payment_method_config_method`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Cau hinh QR + tai khoan cho tung phuong thuc thanh toan';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sal_payment_method_config`
--

LOCK TABLES `sal_payment_method_config` WRITE;
/*!40000 ALTER TABLE `sal_payment_method_config` DISABLE KEYS */;
INSERT INTO `sal_payment_method_config` VALUES ('008f3305-a41e-11f1-b0a9-762043079894',0,'Thanh toÃ¡n khi nháº­n hÃ ng (COD)',NULL,NULL,NULL,NULL,NULL,1,0,'2026-08-30 02:53:39',NULL),('008f36cd-a41e-11f1-b0a9-762043079894',1,'Chuyá»ƒn khoáº£n ngÃ¢n hÃ ng',NULL,'CONG TY TNHH FASHION ECOM','1234567890','Vietcombank',NULL,1,1,'2026-08-30 02:53:39',NULL),('008f385f-a41e-11f1-b0a9-762043079894',2,'VÃ­ MoMo',NULL,'FASHION ECOM','0901234567',NULL,NULL,1,2,'2026-08-30 02:53:39',NULL),('008f3928-a41e-11f1-b0a9-762043079894',3,'VNPay',NULL,'FASHION ECOM',NULL,NULL,NULL,1,3,'2026-08-30 02:53:39',NULL);
/*!40000 ALTER TABLE `sal_payment_method_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sal_return_request`
--

DROP TABLE IF EXISTS `sal_return_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sal_return_request` (
  `sal_return_request_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID yeu cau doi tra',
  `sal_return_request_code` varchar(20) NOT NULL COMMENT 'Ma RMA hien thi (VD: RMA-20260410-001)',
  `sal_order_id` char(36) NOT NULL COMMENT 'Khoa ngoai tro toi Don hang goc',
  `sys_customer_id` char(36) NOT NULL COMMENT 'Khoa ngoai tro toi Khach hang',
  `sal_return_request_type` tinyint NOT NULL DEFAULT '0' COMMENT 'Loai: 0: Doi hang, 1: Hoan tien, 2: Doi size',
  `sal_return_request_reason` tinyint NOT NULL DEFAULT '0' COMMENT 'Ly do: 0: Loi hang, 1: Sai SP, 2: Khong vua, 3: Doi y, 4: Khac',
  `sal_return_request_reason_detail` varchar(500) DEFAULT NULL COMMENT 'Mo ta chi tiet ly do',
  `sal_return_request_status` tinyint NOT NULL DEFAULT '0' COMMENT 'Trang thai: 0: Requested, 1: Reviewing, 2: Approved, 3: Rejected, 4: Refunding, 5: Refunded, 6: Exchanging, 7: Exchanged',
  `sal_return_request_refund_amount` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'So tien hoan (neu type=refund)',
  `sal_return_request_staff_notes` text COMMENT 'Ghi chu noi bo (KH khong thay)',
  `sal_return_request_customer_notes` text COMMENT 'Ghi chu tu KH',
  `sys_user_id` char(36) DEFAULT NULL COMMENT 'Nhan vien xu ly',
  `sal_exchange_order_id` char(36) DEFAULT NULL COMMENT 'Don hang moi (neu type=exchange)',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay tao yeu cau',
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Ngay cap nhat cuoi',
  PRIMARY KEY (`sal_return_request_id`),
  UNIQUE KEY `uix_salreturnrequest_code` (`sal_return_request_code`),
  KEY `ix_salreturnrequest_salorderid` (`sal_order_id`),
  KEY `ix_salreturnrequest_syscustomerid` (`sys_customer_id`),
  KEY `ix_salreturnrequest_status` (`sal_return_request_status`),
  CONSTRAINT `fk_salreturnrequest_salorder` FOREIGN KEY (`sal_order_id`) REFERENCES `sal_order` (`sal_order_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_salreturnrequest_syscustomer` FOREIGN KEY (`sys_customer_id`) REFERENCES `sys_customer` (`sys_customer_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Yeu cau doi tra hang (RMA)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sal_return_request`
--

LOCK TABLES `sal_return_request` WRITE;
/*!40000 ALTER TABLE `sal_return_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `sal_return_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sal_return_request_item`
--

DROP TABLE IF EXISTS `sal_return_request_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sal_return_request_item` (
  `sal_return_request_item_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID chi tiet RMA',
  `sal_return_request_id` char(36) NOT NULL COMMENT 'Khoa ngoai tro toi RMA',
  `sal_order_item_id` char(36) NOT NULL COMMENT 'Dong don hang goc',
  `cat_product_variant_id` char(36) NOT NULL COMMENT 'Variant tra ve',
  `sal_return_request_item_qty` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'So luong tra',
  `sal_return_request_item_exchange_variant_id` char(36) DEFAULT NULL COMMENT 'Variant doi sang (neu exchange)',
  PRIMARY KEY (`sal_return_request_item_id`),
  KEY `fk_salreturnrequestitem_salorderitem` (`sal_order_item_id`),
  KEY `ix_salreturnrequestitem_salreturnrequestid` (`sal_return_request_id`),
  CONSTRAINT `fk_salreturnrequestitem_salorderitem` FOREIGN KEY (`sal_order_item_id`) REFERENCES `sal_order_item` (`sal_order_item_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_salreturnrequestitem_salreturnrequest` FOREIGN KEY (`sal_return_request_id`) REFERENCES `sal_return_request` (`sal_return_request_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Chi tiet san pham trong yeu cau doi tra';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sal_return_request_item`
--

LOCK TABLES `sal_return_request_item` WRITE;
/*!40000 ALTER TABLE `sal_return_request_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sal_return_request_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sal_return_request_media`
--

DROP TABLE IF EXISTS `sal_return_request_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sal_return_request_media` (
  `sal_return_request_media_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID anh minh chung RMA',
  `sal_return_request_id` char(36) NOT NULL COMMENT 'Khoa ngoai tro toi RMA',
  `sal_return_request_media_path` varchar(255) NOT NULL COMMENT 'Duong dan file',
  `sal_return_request_media_type` tinyint NOT NULL DEFAULT '1' COMMENT '1: Image, 2: Video',
  PRIMARY KEY (`sal_return_request_media_id`),
  KEY `ix_salreturnrequestmedia_salreturnrequestid` (`sal_return_request_id`),
  CONSTRAINT `fk_salreturnrequestmedia_salreturnrequest` FOREIGN KEY (`sal_return_request_id`) REFERENCES `sal_return_request` (`sal_return_request_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Anh/video minh chung RMA';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sal_return_request_media`
--

LOCK TABLES `sal_return_request_media` WRITE;
/*!40000 ALTER TABLE `sal_return_request_media` DISABLE KEYS */;
/*!40000 ALTER TABLE `sal_return_request_media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sal_review`
--

DROP TABLE IF EXISTS `sal_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sal_review` (
  `sal_review_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toÃ n cá»¥c ÄÃ¡nh giÃ¡ sáº£n pháº©m',
  `sal_order_item_id` char(36) NOT NULL COMMENT 'KhÃ³a ngoáº¡i trá» tá»›i DÃ²ng ÄÆ¡n hÃ ng (Äáº£m báº£o khÃ¡ch Ä‘Ã£ mua má»›i Ä‘Æ°á»£c Review)',
  `cat_product_id` char(36) DEFAULT NULL COMMENT 'FK san pham duoc danh gia',
  `sys_customer_id` char(36) NOT NULL COMMENT 'KhÃ³a ngoáº¡i trá» tá»›i KhÃ¡ch hÃ ng',
  `sal_review_rating` decimal(18,4) NOT NULL DEFAULT '5.0000' COMMENT 'Sá»‘ Ä‘iá»ƒm sao Ä‘Ã¡nh giÃ¡ (Tá»« 1 Ä‘áº¿n 5)',
  `sal_review_content` text COMMENT 'Ná»™i dung bÃ¬nh luáº­n cá»§a khÃ¡ch',
  `sal_review_admin_reply` text COMMENT 'Phan hoi tu Admin (Official Reply)',
  `sal_review_admin_reply_date` datetime DEFAULT NULL COMMENT 'Ngay admin phan hoi',
  `sal_review_admin_reply_by` char(36) DEFAULT NULL COMMENT 'Admin ID phan hoi',
  `sal_review_status` tinyint NOT NULL DEFAULT '0' COMMENT 'Tráº¡ng thÃ¡i kiá»ƒm duyá»‡t: 0: Chá» duyá»‡t, 1: ÄÃ£ duyá»‡t hiá»‡n lÃªn Web, 2: ÄÃ£ áº©n (Tá»« chá»‘i)',
  `sal_review_photos` json DEFAULT NULL COMMENT 'Danh sach anh danh gia (JSON array URL)',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'NgÃ y giá» khÃ¡ch gá»­i Ä‘Ã¡nh giÃ¡',
  PRIMARY KEY (`sal_review_id`),
  KEY `ix_salreview_salorderitemid` (`sal_order_item_id`),
  KEY `ix_salreview_syscustomerid` (`sys_customer_id`),
  KEY `ix_sal_review_cat_product_id` (`cat_product_id`),
  CONSTRAINT `fk_salreview_salorderitem` FOREIGN KEY (`sal_order_item_id`) REFERENCES `sal_order_item` (`sal_order_item_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_salreview_syscustomer` FOREIGN KEY (`sys_customer_id`) REFERENCES `sys_customer` (`sys_customer_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Báº£ng lÆ°u trá»¯ thÃ´ng tin ÄÃ¡nh giÃ¡, BÃ¬nh luáº­n (Comment) cá»§a khÃ¡ch hÃ ng';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sal_review`
--

LOCK TABLES `sal_review` WRITE;
/*!40000 ALTER TABLE `sal_review` DISABLE KEYS */;
/*!40000 ALTER TABLE `sal_review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sal_review_media`
--

DROP TABLE IF EXISTS `sal_review_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sal_review_media` (
  `sal_review_media_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toÃ n cá»¥c HÃ¬nh áº£nh cá»§a ÄÃ¡nh giÃ¡',
  `sal_review_id` char(36) NOT NULL COMMENT 'KhÃ³a ngoáº¡i trá» tá»›i ÄÃ¡nh giÃ¡ gá»‘c',
  `sal_review_media_path` varchar(255) NOT NULL COMMENT 'ÄÆ°á»ng dáº«n thÆ° má»¥c váº­t lÃ½ (VD: /reviews/2024/05/xyz.webp)',
  `cat_product_media_type` tinyint NOT NULL DEFAULT '1' COMMENT 'Loáº¡i file Ä‘Ã­nh kÃ¨m: 1: Image, 2: Video ngáº¯n',
  PRIMARY KEY (`sal_review_media_id`),
  KEY `ix_salreviewmedia_salreviewid` (`sal_review_id`),
  CONSTRAINT `fk_salreviewmedia_salreview` FOREIGN KEY (`sal_review_id`) REFERENCES `sal_review` (`sal_review_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Báº£ng lÆ°u trá»¯ hÃ¬nh áº£nh/video khÃ¡ch hÃ ng Upload khi Comment';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sal_review_media`
--

LOCK TABLES `sal_review_media` WRITE;
/*!40000 ALTER TABLE `sal_review_media` DISABLE KEYS */;
/*!40000 ALTER TABLE `sal_review_media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sal_shipping_config`
--

DROP TABLE IF EXISTS `sal_shipping_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sal_shipping_config` (
  `sal_shipping_config_id` char(36) NOT NULL DEFAULT (uuid()),
  `sal_shipping_config_provider` varchar(20) NOT NULL COMMENT 'Ma don vi: GHN, GHTK, NINJA_VAN, J&T, BEST, MANUAL',
  `sal_shipping_config_name` varchar(100) NOT NULL COMMENT 'Ten hien thi: Giao Hang Nhanh, ...',
  `sal_shipping_config_flat_rate` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Phi ship dong gia thu KH (VND)',
  `sal_shipping_config_actual_cost` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Chi phi thuc te tra hang van chuyen (VND)',
  `sal_shipping_config_free_ship_threshold` decimal(22,4) NOT NULL DEFAULT '500000.0000' COMMENT 'Nguong mien phi ship (VND). 0 = khong mien phi',
  `sal_shipping_config_status` tinyint NOT NULL DEFAULT '1' COMMENT '0=inactive, 1=active',
  `sal_shipping_config_sort_order` int NOT NULL DEFAULT '0' COMMENT 'Thu tu hien thi',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sal_shipping_config_id`),
  UNIQUE KEY `uix_sal_shipping_config_provider` (`sal_shipping_config_provider`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Cau hinh phi van chuyen dong gia theo don vi';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sal_shipping_config`
--

LOCK TABLES `sal_shipping_config` WRITE;
/*!40000 ALTER TABLE `sal_shipping_config` DISABLE KEYS */;
INSERT INTO `sal_shipping_config` VALUES ('01322386-a41e-11f1-b0a9-762043079894','GHN','Giao HÃ ng Nhanh',30000.0000,22000.0000,500000.0000,1,1,'2026-08-30 02:53:40',NULL),('01322710-a41e-11f1-b0a9-762043079894','GHTK','Giao HÃ ng Tiáº¿t Kiá»‡m',25000.0000,18000.0000,500000.0000,1,2,'2026-08-30 02:53:40',NULL),('01322824-a41e-11f1-b0a9-762043079894','NINJA_VAN','Ninja Van',35000.0000,25000.0000,500000.0000,1,3,'2026-08-30 02:53:40',NULL),('0132289d-a41e-11f1-b0a9-762043079894','JT','J&T Express',28000.0000,20000.0000,500000.0000,1,4,'2026-08-30 02:53:40',NULL);
/*!40000 ALTER TABLE `sal_shipping_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sal_shipping_incident`
--

DROP TABLE IF EXISTS `sal_shipping_incident`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sal_shipping_incident` (
  `sal_shipping_incident_id` char(36) NOT NULL DEFAULT (uuid()),
  `sal_order_id` char(36) NOT NULL COMMENT 'Don hang lien quan',
  `sal_shipping_incident_type` tinyint NOT NULL COMMENT 'Loai su co: 1-6',
  `sal_shipping_incident_status` tinyint NOT NULL DEFAULT '0' COMMENT 'Trang thai: 0-3',
  `sal_shipping_incident_delivery_attempts` int NOT NULL DEFAULT '1' COMMENT 'So lan giao hang (2+ = phat sinh phu phi giao lai)',
  `sal_shipping_incident_extra_cost` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Phu phi phat sinh (giao lai, luu kho, ...)',
  `sal_shipping_incident_product_loss` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Gia tri hang bi hu hong hoac mat (COGS)',
  `sal_shipping_incident_refund_amount` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'So tien hoan tra KH',
  `sal_shipping_incident_carrier_compensation` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'So tien DVVC boi thuong',
  `sal_shipping_incident_revenue_impact` tinyint NOT NULL DEFAULT '0' COMMENT '0=binh thuong, 1=mat toan bo DT, 2=giam 1 phan',
  `sal_shipping_incident_note` text COMMENT 'Ghi chu chi tiet su co',
  `sal_shipping_incident_photos` json DEFAULT NULL COMMENT 'Anh chung minh hu hong / mat hang',
  `sal_shipping_incident_resolved_date` datetime DEFAULT NULL,
  `sys_user_id` char(36) DEFAULT NULL COMMENT 'Nguoi tao / xu ly su co',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sal_shipping_incident_id`),
  KEY `ix_sal_shipping_incident_order` (`sal_order_id`),
  KEY `ix_sal_shipping_incident_type` (`sal_shipping_incident_type`),
  KEY `ix_sal_shipping_incident_status` (`sal_shipping_incident_status`),
  KEY `ix_sal_shipping_incident_date` (`created_date`),
  CONSTRAINT `fk_shipping_incident_order` FOREIGN KEY (`sal_order_id`) REFERENCES `sal_order` (`sal_order_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Su co van chuyen â€” mat hang, hu hong, hoan, giao lai';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sal_shipping_incident`
--

LOCK TABLES `sal_shipping_incident` WRITE;
/*!40000 ALTER TABLE `sal_shipping_incident` DISABLE KEYS */;
/*!40000 ALTER TABLE `sal_shipping_incident` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_changelog`
--

DROP TABLE IF EXISTS `schema_changelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schema_changelog` (
  `version` varchar(50) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `checksum` varchar(64) NOT NULL,
  `applied_by` varchar(100) NOT NULL DEFAULT 'ci',
  `applied_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_ms` int DEFAULT NULL,
  PRIMARY KEY (`version`,`filename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_changelog`
--

LOCK TABLES `schema_changelog` WRITE;
/*!40000 ALTER TABLE `schema_changelog` DISABLE KEYS */;
INSERT INTO `schema_changelog` VALUES ('_init','001__schema_changelog_table.sql','schema changelog table','6a297b7743b4aaaf960352fd23338c8233af9b345d3e9dda7caa24c80f2438b7','ci','2026-08-30 02:53:40',NULL),('1.0.0','001__core_schema.sql','core schema','dec976c782fbcf47e307da97c07aa936dfb5c3178c0ed475bc3c515f1caf7f51','ci','2026-08-30 02:53:28',NULL),('1.0.0','002__customer_address_wishlist_seo.sql','customer address wishlist seo','fe4e61b01000d18c73a96551afc330f1ab72b7ec755b73dc2197845217b455f7','ci','2026-08-30 02:53:28',NULL),('1.1.0','001__sys_user_extend.sql','sys user extend','b92dc93b40fac652bbe703a5f093dff30bab1108806a2bc6adee6b53f04d07d2','ci','2026-08-30 02:53:28',NULL),('1.1.0','002__cat_color.sql','cat color','9f3ef1fe3db3e8aec79f8b5628c5c787a7107fc90e57325df12e86703cb686aa','ci','2026-08-30 02:53:28',NULL),('1.1.0','003__cat_size_group.sql','cat size group','9f1bc0fd20163f12f9b3e857dde64d7b4e52b5411b921f69b087c21c7af0fe66','ci','2026-08-30 02:53:29',NULL),('1.1.0','004__cat_product_variant_extend.sql','cat product variant extend','14c4a207bdea9317d59320c26d5c89ba971e1664cba44e5bafed1d34438f7ffc','ci','2026-08-30 02:53:29',NULL),('1.1.0','005__sal_order_extend.sql','sal order extend','fdffff6e4c8141c3104127c60c97f8619f9e5b5cf2f813d371fd6a7d87663d37','ci','2026-08-30 02:53:29',NULL),('1.1.0','006__sal_order_timeline.sql','sal order timeline','9480325b8f126ab88b5c94a7a132d5ca654987d4f473a33a2e45177c6b523127','ci','2026-08-30 02:53:29',NULL),('1.1.0','007__inv_inventory_log.sql','inv inventory log','bcf2d251d9db99804c8e2ca28fc12668e225557b622009d4cb1881af52f2dcb2','ci','2026-08-30 02:53:29',NULL),('1.1.0','008__sys_media.sql','sys media','4dfb5f27f26cf6213afeac83370b4cdb4f8282434753a7b0b781cd6ab5cfcc00','ci','2026-08-30 02:53:29',NULL),('1.1.0','009__sys_setting.sql','sys setting','3801729086b14c93bee12184c019fac79cf86f3b27bdc788804a59fbe680d159','ci','2026-08-30 02:53:29',NULL),('1.1.0','010__sys_refresh_token.sql','sys refresh token','378bcc2ff221827faf747fbb8369861ff855353d615ea2851ea4216221533110','ci','2026-08-30 02:53:29',NULL),('1.1.0','011__log_audit.sql','log audit','d4bb9d19bdf8ea26842049b676d69c9ff422cca1d094bf650d60d129076659aa','ci','2026-08-30 02:53:29',NULL),('1.1.0','012__cat_product_extend_phase2.sql','cat product extend phase2','2b6be5deaed535bdb6e2decbe5af6b94bc70da4061aad0c7d8178bd1502ac6bb','ci','2026-08-30 02:53:30',NULL),('1.2.0','001__create_log_analytics_event.sql','create log analytics event','f0ebc0adb29e6250c9492b6d0639be3cdb3fbc35b1c9acf16cae3622baddad34','ci','2026-08-30 02:53:30',NULL),('1.2.0','002__create_log_customer_rfm.sql','create log customer rfm','db58614e3cf674508272d2871508ffbec1f84c693f23a0506ad6b25825d0b40b','ci','2026-08-30 02:53:30',NULL),('1.2.0','003__create_log_inventory_snapshot.sql','create log inventory snapshot','073871cb52f61a9b3bbda2d8f61d1c5d944b22ffc8e82bfa3d4e5e94b6daa540','ci','2026-08-30 02:53:30',NULL),('1.2.0','004__create_log_payment_fee_config.sql','create log payment fee config','c7bd2b04ae940c964fda1f6490a730c9e4377c9036b09f1f108c50baf87811c2','ci','2026-08-30 02:53:30',NULL),('1.2.0','005__seed_payment_fee_config.sql','seed payment fee config','a8dea17dc5b3d239c02ae994307c56642b79d3252b9474b913581db2327b3c7a','ci','2026-08-30 02:53:30',NULL),('1.3.0','001__cms_layout_section.sql','cms layout section','f157512ae19f95b80fc7a4283af15a9afbc74cd69014a17f647a990ce3dc3ebd','ci','2026-08-30 02:53:30',NULL),('1.3.0','002__cms_banner.sql','cms banner','3c860df4efb22b1be77f372e28cf03f0aec9fadecfdcce5c528007654139de45','ci','2026-08-30 02:53:30',NULL),('1.3.0','003__cms_menu.sql','cms menu','b16bbbe7ab9f110bedbdfe84f2f9f928fb903ae3a13f260c3804662d56a69199','ci','2026-08-30 02:53:31',NULL),('1.3.0','004__cms_theme_config.sql','cms theme config','36cc523e940b1e83d7d4ab0f3ac54a73e0ed04476dcc5ee251084e9171d45324','ci','2026-08-30 02:53:31',NULL),('1.3.0','005__cms_email_template.sql','cms email template','fc11d36680f37a9708830404816119c9c123508092ba7d1c0c84a693dccfc2d6','ci','2026-08-30 02:53:31',NULL),('1.3.0','006__prm_discount_code.sql','prm discount code','34a27edf579a9ce8eec44d85b152473a4e5fdce5f37364351f328fa84f9881c1','ci','2026-08-30 02:53:31',NULL),('1.3.0','007__prm_flash_sale.sql','prm flash sale','30c18ad17e13a0f8bef75171b1e5bc0ef0d9b1c62b417c3d26d1ddb458decfa9','ci','2026-08-30 02:53:31',NULL),('1.3.0','008__cms_menu_seed.sql','cms menu seed','d6cdaa0155ade39d8acf29f002d579648e374d29c5d6cadbb904118a44ec4c8d','ci','2026-08-30 02:53:31',NULL),('1.3.0','009__cms_layout_default_seed.sql','cms layout default seed','1a8fa24ed6d98eff9f55803408d8a1f713dc9a9dc0c6281ae405f22056ecaf46','ci','2026-08-30 02:53:31',NULL),('1.4.0','001__payment_gateway.sql','payment gateway','a895d2bb22de1ba76d6826a2d7c136771524b25fb47d88d31f8883e0e78f8c61','ci','2026-08-30 02:53:32',NULL),('1.4.0','001__performance_indexes.sql','performance indexes','affa30cfec69ca44e0828cc5880871ac7e9e911700537edea54abd3c3b80b33e','ci','2026-08-30 02:53:32',NULL),('1.4.0','002__return_rma.sql','return rma','d1e932a4522c7b0f42a01d94345ae6a5945ce630abb77834ba708cfa831c17c8','ci','2026-08-30 02:53:33',NULL),('1.4.0','003__loyalty.sql','loyalty','b331605023e3cce23af7422127c7607e8465f286d12e92cd4fe5d3509c0ad2d3','ci','2026-08-30 02:53:33',NULL),('1.4.0','004__suppliers_purchase_orders.sql','suppliers purchase orders','57a8b2abb3476f6e93c87ab18f99e4b2eb8c3b8d48482d0dc634ec38ed6809bc','ci','2026-08-30 02:53:34',NULL),('1.4.0','005__warehouse_transfer.sql','warehouse transfer','2ec050518dae2738ec75206834ca690d629208ff3744dc150e6cba0492afb04d','ci','2026-08-30 02:53:34',NULL),('1.4.0','006__audit_log.sql','audit log','88d46d2032e6054cca909f6a9044e5a8c0af67b566a3851f33aefef38b9f3f97','ci','2026-08-30 02:53:34',NULL),('1.4.0','007__notifications.sql','notifications','14649470393f061675b6cbcc58190f8d1eaafd8c28e85c6698be0f2aeef02a85','ci','2026-08-30 02:53:34',NULL),('1.4.0','008__reviews_enhancement.sql','reviews enhancement','b8aa3f2293543cc0683fce82686d2f0a4ee3ce3870746367a7efd250fb47216b','ci','2026-08-30 02:53:35',NULL),('1.4.0','009__security.sql','security','71cb08f187ceb9987f8c73c4fa450d87cd0d97cc167bf8c3d3b3e3956b77ef80','ci','2026-08-30 02:53:35',NULL),('1.4.0','010__guide_tour.sql','guide tour','48267cf8e28852445bdb9b9b9e770b54e7723b9840985f26778deed0b13255d0','ci','2026-08-30 02:53:35',NULL),('1.4.0','011__abandoned_cart.sql','abandoned cart','298ad638a8ca47124696383c7c4f5ad7bcf4f8b4b4a8715ff2d794ce7a3d1237','ci','2026-08-30 02:53:35',NULL),('1.5.0','001__sync_entity_columns.sql','sync entity columns','10ea5a22892ea6935733a516ba0e30d624ed93f52a78844d6f9025f338846ab1','ci','2026-08-30 02:53:35',NULL),('1.6.0','001__create_log_system_table.sql','create log system table','de9ecbfb21a10981ad26303ad7ceb4692b059c9d764d2b6e50d351fd4f19e1d9','ci','2026-08-30 02:53:36',NULL),('1.7.0','001__cat_size_normalize.sql','cat size normalize','5da00ece36b052e8f85b29d1db2337a839a6bdc00fd31ba7e22b1198cf4def8f','ci','2026-08-30 02:53:36',NULL),('1.7.0','002__variant_color_size_fk.sql','variant color size fk','ec6cacadf13739ab6858aa7e415a33b6bb08328e3d2251eab2c25cf3f3bd4d24','ci','2026-08-30 02:53:36',NULL),('1.7.0','003__migrate_variant_text_to_fk.sql','migrate variant text to fk','d4ed11a452bfcda78dbcbc0684e990f721f1f5d26af5111ffeb9a4548acf4857','ci','2026-08-30 02:53:36',NULL),('1.7.0','004__seed_colors_sizes.sql','seed colors sizes','b1fd89df86b25905c0886b838cc422a09c398d7cf2ee43c7b88e7abefaa20179','ci','2026-08-30 02:53:36',NULL),('1.7.0','005__prm_sale_campaign.sql','prm sale campaign','f5481e61da60f3d778a11d2a45c0669072559df93c5ad0654ebf2c764158a187','ci','2026-08-30 02:53:37',NULL),('1.7.0','006__flash_sale_variant_level.sql','flash sale variant level','0716a6409470840327650c595f043806cad26decfd4585892bf273881284fb6a','ci','2026-08-30 02:53:37',NULL),('1.8.0','000__create_inv_inventory.sql','create inv inventory','832b0191ff624ade0bb1fa6e681f93298c0a3750c4740577079f84dea98e8d5a','ci','2026-08-30 02:53:37',NULL),('1.8.0','001__seed_catalog_data.sql','seed catalog data','6da9531862ffe3b1d2c6fd765bea7359376ecf8a4827b3e7ba1424de185f5567','ci','2026-08-30 14:21:25',NULL),('root','20260415_add_product_attributes.sql','20260415 add product attributes','81a24718b3eb7bc2ca00036d7489a2d8253ea501628664dfafb9f4927516ec3c','ci','2026-08-30 02:53:37',NULL),('root','20260415_admin_notification.sql','20260415 admin notification','185395da3f98b5a713da0490f9dbf1bb7230831ffc4e05297bb7c13355198fce','ci','2026-08-30 02:53:38',NULL),('root','20260415_import_sync.sql','20260415 import sync','98ef8c9bae9d429980b4e79c582a158cbc0e98fde0c0886340fa00025fbe94a4','ci','2026-08-30 02:53:38',NULL),('root','20260415_order_shipping_status.sql','20260415 order shipping status','56cb5dd4e0eea52c1121c32edc0109fd7b4897d2018961928909e5517fcbe998','ci','2026-08-30 02:53:38',NULL),('root','20260415_payment_bank_transfer.sql','20260415 payment bank transfer','aa399d23bc7a3fa4deeccb50a3c087aaeb764418bb9bbe08f4d5477c1b73ae96','ci','2026-08-30 02:53:38',NULL),('root','20260415_payment_method_config.sql','20260415 payment method config','ec7bc9c145018df2a1a808c39ae1856850f0d04c2e76e1819cae4c7167889095','ci','2026-08-30 02:53:39',NULL),('root','20260415_shipping_incident.sql','20260415 shipping incident','cecf0343ad4533b3a12c0eae994b59aff9a96130b049237e8cd983895805df0e','ci','2026-08-30 02:53:39',NULL),('root','20260415_shipping_management.sql','20260415 shipping management','45eacd1fda35c8247ca083bdbe5d193e0b3996e2e328d27b7a93a213003ff702','ci','2026-08-30 02:53:40',NULL);
/*!40000 ALTER TABLE `schema_changelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_changelog_old`
--

DROP TABLE IF EXISTS `schema_changelog_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schema_changelog_old` (
  `schema_changelog_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'UUID PK â€” MISA convention',
  `filename` varchar(255) NOT NULL,
  `applied_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `checksum` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`schema_changelog_id`),
  UNIQUE KEY `uix_schema_changelog_filename` (`filename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Theo doi cac file SQL changelog da chay';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_changelog_old`
--

LOCK TABLES `schema_changelog_old` WRITE;
/*!40000 ALTER TABLE `schema_changelog_old` DISABLE KEYS */;
INSERT INTO `schema_changelog_old` VALUES ('000a20d0-a41e-11f1-b0a9-762043079894','20260415_import_sync.sql','2026-08-30 02:53:38','98ef8c9bae9d429980b4e79c582a158cbc0e98fde0c0886340fa00025fbe94a4'),('0072cff0-a41e-11f1-b0a9-762043079894','20260415_order_shipping_status.sql','2026-08-30 02:53:38','56cb5dd4e0eea52c1121c32edc0109fd7b4897d2018961928909e5517fcbe998'),('008581dd-a41e-11f1-b0a9-762043079894','20260415_payment_bank_transfer.sql','2026-08-30 02:53:38','aa399d23bc7a3fa4deeccb50a3c087aaeb764418bb9bbe08f4d5477c1b73ae96'),('0092c395-a41e-11f1-b0a9-762043079894','20260415_payment_method_config.sql','2026-08-30 02:53:39','ec7bc9c145018df2a1a808c39ae1856850f0d04c2e76e1819cae4c7167889095'),('00e5bc77-a41e-11f1-b0a9-762043079894','20260415_shipping_incident.sql','2026-08-30 02:53:39','cecf0343ad4533b3a12c0eae994b59aff9a96130b049237e8cd983895805df0e'),('0135c6e0-a41e-11f1-b0a9-762043079894','20260415_shipping_management.sql','2026-08-30 02:53:40','45eacd1fda35c8247ca083bdbe5d193e0b3996e2e328d27b7a93a213003ff702'),('013ced2d-a41e-11f1-b0a9-762043079894','001__schema_changelog_table.sql','2026-08-30 02:53:40','6a297b7743b4aaaf960352fd23338c8233af9b345d3e9dda7caa24c80f2438b7'),('fa121e02-a41d-11f1-b0a9-762043079894','001__core_schema.sql','2026-08-30 02:53:28','dec976c782fbcf47e307da97c07aa936dfb5c3178c0ed475bc3c515f1caf7f51'),('fa6984f4-a41d-11f1-b0a9-762043079894','002__customer_address_wishlist_seo.sql','2026-08-30 02:53:28','fe4e61b01000d18c73a96551afc330f1ab72b7ec755b73dc2197845217b455f7'),('fa7a325b-a41d-11f1-b0a9-762043079894','001__sys_user_extend.sql','2026-08-30 02:53:28','b92dc93b40fac652bbe703a5f093dff30bab1108806a2bc6adee6b53f04d07d2'),('fa873c46-a41d-11f1-b0a9-762043079894','002__cat_color.sql','2026-08-30 02:53:28','9f3ef1fe3db3e8aec79f8b5628c5c787a7107fc90e57325df12e86703cb686aa'),('fa956d8a-a41d-11f1-b0a9-762043079894','003__cat_size_group.sql','2026-08-30 02:53:29','9f1bc0fd20163f12f9b3e857dde64d7b4e52b5411b921f69b087c21c7af0fe66'),('faa7bb3b-a41d-11f1-b0a9-762043079894','004__cat_product_variant_extend.sql','2026-08-30 02:53:29','14c4a207bdea9317d59320c26d5c89ba971e1664cba44e5bafed1d34438f7ffc'),('fabe0089-a41d-11f1-b0a9-762043079894','005__sal_order_extend.sql','2026-08-30 02:53:29','fdffff6e4c8141c3104127c60c97f8619f9e5b5cf2f813d371fd6a7d87663d37'),('face71fa-a41d-11f1-b0a9-762043079894','006__sal_order_timeline.sql','2026-08-30 02:53:29','9480325b8f126ab88b5c94a7a132d5ca654987d4f473a33a2e45177c6b523127'),('fae5817b-a41d-11f1-b0a9-762043079894','007__inv_inventory_log.sql','2026-08-30 02:53:29','bcf2d251d9db99804c8e2ca28fc12668e225557b622009d4cb1881af52f2dcb2'),('faf68816-a41d-11f1-b0a9-762043079894','008__sys_media.sql','2026-08-30 02:53:29','4dfb5f27f26cf6213afeac83370b4cdb4f8282434753a7b0b781cd6ab5cfcc00'),('fb03c3d6-a41d-11f1-b0a9-762043079894','009__sys_setting.sql','2026-08-30 02:53:29','3801729086b14c93bee12184c019fac79cf86f3b27bdc788804a59fbe680d159'),('fb14a943-a41d-11f1-b0a9-762043079894','010__sys_refresh_token.sql','2026-08-30 02:53:29','378bcc2ff221827faf747fbb8369861ff855353d615ea2851ea4216221533110'),('fb28cd7d-a41d-11f1-b0a9-762043079894','011__log_audit.sql','2026-08-30 02:53:29','d4bb9d19bdf8ea26842049b676d69c9ff422cca1d094bf650d60d129076659aa'),('fb3b8f31-a41d-11f1-b0a9-762043079894','012__cat_product_extend_phase2.sql','2026-08-30 02:53:30','2b6be5deaed535bdb6e2decbe5af6b94bc70da4061aad0c7d8178bd1502ac6bb'),('fb4a5c7d-a41d-11f1-b0a9-762043079894','001__create_log_analytics_event.sql','2026-08-30 02:53:30','f0ebc0adb29e6250c9492b6d0639be3cdb3fbc35b1c9acf16cae3622baddad34'),('fb6708d2-a41d-11f1-b0a9-762043079894','002__create_log_customer_rfm.sql','2026-08-30 02:53:30','db58614e3cf674508272d2871508ffbec1f84c693f23a0506ad6b25825d0b40b'),('fb751d73-a41d-11f1-b0a9-762043079894','003__create_log_inventory_snapshot.sql','2026-08-30 02:53:30','073871cb52f61a9b3bbda2d8f61d1c5d944b22ffc8e82bfa3d4e5e94b6daa540'),('fb80fe35-a41d-11f1-b0a9-762043079894','004__create_log_payment_fee_config.sql','2026-08-30 02:53:30','c7bd2b04ae940c964fda1f6490a730c9e4377c9036b09f1f108c50baf87811c2'),('fb8978f1-a41d-11f1-b0a9-762043079894','005__seed_payment_fee_config.sql','2026-08-30 02:53:30','a8dea17dc5b3d239c02ae994307c56642b79d3252b9474b913581db2327b3c7a'),('fb9a4d02-a41d-11f1-b0a9-762043079894','001__cms_layout_section.sql','2026-08-30 02:53:30','f157512ae19f95b80fc7a4283af15a9afbc74cd69014a17f647a990ce3dc3ebd'),('fbaeec82-a41d-11f1-b0a9-762043079894','002__cms_banner.sql','2026-08-30 02:53:30','3c860df4efb22b1be77f372e28cf03f0aec9fadecfdcce5c528007654139de45'),('fbd3910c-a41d-11f1-b0a9-762043079894','003__cms_menu.sql','2026-08-30 02:53:31','b16bbbe7ab9f110bedbdfe84f2f9f928fb903ae3a13f260c3804662d56a69199'),('fbe8218a-a41d-11f1-b0a9-762043079894','004__cms_theme_config.sql','2026-08-30 02:53:31','36cc523e940b1e83d7d4ab0f3ac54a73e0ed04476dcc5ee251084e9171d45324'),('fbf6e190-a41d-11f1-b0a9-762043079894','005__cms_email_template.sql','2026-08-30 02:53:31','fc11d36680f37a9708830404816119c9c123508092ba7d1c0c84a693dccfc2d6'),('fc1c73ce-a41d-11f1-b0a9-762043079894','006__prm_discount_code.sql','2026-08-30 02:53:31','34a27edf579a9ce8eec44d85b152473a4e5fdce5f37364351f328fa84f9881c1'),('fc3b8e91-a41d-11f1-b0a9-762043079894','007__prm_flash_sale.sql','2026-08-30 02:53:31','30c18ad17e13a0f8bef75171b1e5bc0ef0d9b1c62b417c3d26d1ddb458decfa9'),('fc4290f6-a41d-11f1-b0a9-762043079894','008__cms_menu_seed.sql','2026-08-30 02:53:31','d6cdaa0155ade39d8acf29f002d579648e374d29c5d6cadbb904118a44ec4c8d'),('fc4fe4e4-a41d-11f1-b0a9-762043079894','009__cms_layout_default_seed.sql','2026-08-30 02:53:31','1a8fa24ed6d98eff9f55803408d8a1f713dc9a9dc0c6281ae405f22056ecaf46'),('fc66d43d-a41d-11f1-b0a9-762043079894','001__payment_gateway.sql','2026-08-30 02:53:32','a895d2bb22de1ba76d6826a2d7c136771524b25fb47d88d31f8883e0e78f8c61'),('fceb3253-a41d-11f1-b0a9-762043079894','001__performance_indexes.sql','2026-08-30 02:53:32','affa30cfec69ca44e0828cc5880871ac7e9e911700537edea54abd3c3b80b33e'),('fd1f4a21-a41d-11f1-b0a9-762043079894','002__return_rma.sql','2026-08-30 02:53:33','d1e932a4522c7b0f42a01d94345ae6a5945ce630abb77834ba708cfa831c17c8'),('fd3997e7-a41d-11f1-b0a9-762043079894','003__loyalty.sql','2026-08-30 02:53:33','b331605023e3cce23af7422127c7607e8465f286d12e92cd4fe5d3509c0ad2d3'),('fd8ca1df-a41d-11f1-b0a9-762043079894','004__suppliers_purchase_orders.sql','2026-08-30 02:53:34','57a8b2abb3476f6e93c87ab18f99e4b2eb8c3b8d48482d0dc634ec38ed6809bc'),('fdcf53f3-a41d-11f1-b0a9-762043079894','005__warehouse_transfer.sql','2026-08-30 02:53:34','2ec050518dae2738ec75206834ca690d629208ff3744dc150e6cba0492afb04d'),('fdf65a60-a41d-11f1-b0a9-762043079894','006__audit_log.sql','2026-08-30 02:53:34','88d46d2032e6054cca909f6a9044e5a8c0af67b566a3851f33aefef38b9f3f97'),('fe1627d2-a41d-11f1-b0a9-762043079894','007__notifications.sql','2026-08-30 02:53:34','14649470393f061675b6cbcc58190f8d1eaafd8c28e85c6698be0f2aeef02a85'),('fe4a094a-a41d-11f1-b0a9-762043079894','008__reviews_enhancement.sql','2026-08-30 02:53:35','b8aa3f2293543cc0683fce82686d2f0a4ee3ce3870746367a7efd250fb47216b'),('fe67987e-a41d-11f1-b0a9-762043079894','009__security.sql','2026-08-30 02:53:35','71cb08f187ceb9987f8c73c4fa450d87cd0d97cc167bf8c3d3b3e3956b77ef80'),('fe8198c0-a41d-11f1-b0a9-762043079894','010__guide_tour.sql','2026-08-30 02:53:35','48267cf8e28852445bdb9b9b9e770b54e7723b9840985f26778deed0b13255d0'),('fe97a604-a41d-11f1-b0a9-762043079894','011__abandoned_cart.sql','2026-08-30 02:53:35','298ad638a8ca47124696383c7c4f5ad7bcf4f8b4b4a8715ff2d794ce7a3d1237'),('febb3fdc-a41d-11f1-b0a9-762043079894','001__sync_entity_columns.sql','2026-08-30 02:53:35','10ea5a22892ea6935733a516ba0e30d624ed93f52a78844d6f9025f338846ab1'),('fec9c87c-a41d-11f1-b0a9-762043079894','001__create_log_system_table.sql','2026-08-30 02:53:36','de9ecbfb21a10981ad26303ad7ceb4692b059c9d764d2b6e50d351fd4f19e1d9'),('fee9541b-a41d-11f1-b0a9-762043079894','001__cat_size_normalize.sql','2026-08-30 02:53:36','5da00ece36b052e8f85b29d1db2337a839a6bdc00fd31ba7e22b1198cf4def8f'),('ff42c4e9-a41d-11f1-b0a9-762043079894','002__variant_color_size_fk.sql','2026-08-30 02:53:36','ec6cacadf13739ab6858aa7e415a33b6bb08328e3d2251eab2c25cf3f3bd4d24'),('ff499ec7-a41d-11f1-b0a9-762043079894','003__migrate_variant_text_to_fk.sql','2026-08-30 02:53:36','d4ed11a452bfcda78dbcbc0684e990f721f1f5d26af5111ffeb9a4548acf4857'),('ff54d360-a41d-11f1-b0a9-762043079894','004__seed_colors_sizes.sql','2026-08-30 02:53:36','b1fd89df86b25905c0886b838cc422a09c398d7cf2ee43c7b88e7abefaa20179'),('ff7969cf-a41d-11f1-b0a9-762043079894','005__prm_sale_campaign.sql','2026-08-30 02:53:37','f5481e61da60f3d778a11d2a45c0669072559df93c5ad0654ebf2c764158a187'),('ff8c75c5-a41d-11f1-b0a9-762043079894','006__flash_sale_variant_level.sql','2026-08-30 02:53:37','0716a6409470840327650c595f043806cad26decfd4585892bf273881284fb6a'),('ff9e2fb0-a41d-11f1-b0a9-762043079894','000__create_inv_inventory.sql','2026-08-30 02:53:37','832b0191ff624ade0bb1fa6e681f93298c0a3750c4740577079f84dea98e8d5a'),('ffe10f74-a41d-11f1-b0a9-762043079894','20260415_add_product_attributes.sql','2026-08-30 02:53:37','81a24718b3eb7bc2ca00036d7489a2d8253ea501628664dfafb9f4927516ec3c'),('fff2fd93-a41d-11f1-b0a9-762043079894','20260415_admin_notification.sql','2026-08-30 02:53:38','185395da3f98b5a713da0490f9dbf1bb7230831ffc4e05297bb7c13355198fce');
/*!40000 ALTER TABLE `schema_changelog_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_admin_notification`
--

DROP TABLE IF EXISTS `sys_admin_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_admin_notification` (
  `sys_admin_notification_id` char(36) NOT NULL DEFAULT (uuid()),
  `sys_user_id` char(36) DEFAULT NULL COMMENT 'Admin cu the, NULL = tat ca admin',
  `sys_admin_notification_type` varchar(30) NOT NULL,
  `sys_admin_notification_title` varchar(255) NOT NULL,
  `sys_admin_notification_body` text NOT NULL,
  `sys_admin_notification_data` json DEFAULT NULL COMMENT 'Du lieu kem theo (orderId, counts, ...)',
  `sys_admin_notification_read` tinyint NOT NULL DEFAULT '0',
  `sys_admin_notification_read_at` datetime DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sys_admin_notification_id`),
  KEY `ix_admin_notif_user` (`sys_user_id`),
  KEY `ix_admin_notif_read` (`sys_admin_notification_read`),
  KEY `ix_admin_notif_type` (`sys_admin_notification_type`),
  KEY `ix_admin_notif_date` (`created_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Notification he thong cho admin â€” don moi, nhac chua duyet';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_admin_notification`
--

LOCK TABLES `sys_admin_notification` WRITE;
/*!40000 ALTER TABLE `sys_admin_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_admin_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_customer`
--

DROP TABLE IF EXISTS `sys_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_customer` (
  `sys_customer_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toÃ n cá»¥c cá»§a KhÃ¡ch hÃ ng',
  `sys_user_id` char(36) NOT NULL COMMENT 'KhÃ³a ngoáº¡i trá» tá»›i tÃ i khoáº£n Ä‘Äƒng nháº­p',
  `sys_customer_name` varchar(100) NOT NULL COMMENT 'Há» vÃ  tÃªn khÃ¡ch hÃ ng',
  `sys_customer_mobile` varchar(50) NOT NULL COMMENT 'Sá»‘ Ä‘iá»‡n thoáº¡i di Ä‘á»™ng',
  `sys_customer_dob` date DEFAULT NULL COMMENT 'NgÃ y thÃ¡ng nÄƒm sinh',
  `sys_customer_loyalty_point` decimal(18,4) NOT NULL DEFAULT '0.0000' COMMENT 'Tá»•ng Ä‘iá»ƒm thÆ°á»Ÿng Loyalty hiá»‡n cÃ³',
  `sys_customer_tier` tinyint NOT NULL DEFAULT '1' COMMENT 'PhÃ¢n háº¡ng: 1: Member, 2: Silver, 3: Gold, 4: Platinum',
  PRIMARY KEY (`sys_customer_id`),
  UNIQUE KEY `uix_syscustomer_syscustomermobile` (`sys_customer_mobile`),
  KEY `ix_syscustomer_sysuserid` (`sys_user_id`),
  CONSTRAINT `fk_syscustomer_sysuser` FOREIGN KEY (`sys_user_id`) REFERENCES `sys_user` (`sys_user_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Há»“ sÆ¡ thÃ´ng tin chi tiáº¿t KhÃ¡ch hÃ ng';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_customer`
--

LOCK TABLES `sys_customer` WRITE;
/*!40000 ALTER TABLE `sys_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_customer_address`
--

DROP TABLE IF EXISTS `sys_customer_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_customer_address` (
  `sys_customer_address_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toan cuc dia chi',
  `sys_customer_id` char(36) NOT NULL COMMENT 'Khoa ngoai tro toi khach hang',
  `sys_customer_address_name` varchar(100) NOT NULL COMMENT 'Ten nguoi nhan',
  `sys_customer_address_phone` varchar(50) NOT NULL COMMENT 'SDT nguoi nhan',
  `sys_customer_address_province` varchar(100) NOT NULL COMMENT 'Tinh/Thanh pho',
  `sys_customer_address_district` varchar(100) NOT NULL COMMENT 'Quan/Huyen',
  `sys_customer_address_ward` varchar(100) NOT NULL COMMENT 'Phuong/Xa',
  `sys_customer_address_detail` varchar(255) NOT NULL COMMENT 'Dia chi chi tiet (so nha, duong)',
  `sys_customer_address_is_default` tinyint NOT NULL DEFAULT '0' COMMENT '1: Dia chi mac dinh, 0: Khong',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay tao',
  PRIMARY KEY (`sys_customer_address_id`),
  KEY `ix_syscustomeraddress_syscustomerid` (`sys_customer_id`),
  CONSTRAINT `fk_syscustomeraddress_syscustomer` FOREIGN KEY (`sys_customer_id`) REFERENCES `sys_customer` (`sys_customer_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Danh sach dia chi giao hang cua khach';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_customer_address`
--

LOCK TABLES `sys_customer_address` WRITE;
/*!40000 ALTER TABLE `sys_customer_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_customer_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_guide_tour`
--

DROP TABLE IF EXISTS `sys_guide_tour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_guide_tour` (
  `sys_guide_tour_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID guide tour',
  `sys_guide_tour_screen_id` varchar(50) NOT NULL COMMENT 'Screen identifier (VD: admin.orders, admin.products.create)',
  `sys_guide_tour_title` varchar(255) NOT NULL COMMENT 'Tieu de tour',
  `sys_guide_tour_roles` json NOT NULL COMMENT 'Danh sach role duoc hien thi: [1, 2, 3]',
  `sys_guide_tour_steps` json NOT NULL COMMENT 'Cac buoc: [{ title, description, selector, position }]',
  `sys_guide_tour_status` tinyint NOT NULL DEFAULT '1' COMMENT '0: Tat, 1: Bat',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay tao',
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Ngay cap nhat',
  PRIMARY KEY (`sys_guide_tour_id`),
  UNIQUE KEY `uix_sysguidetour_screenid` (`sys_guide_tour_screen_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Cau hinh Guided Tour cho tung man hinh Admin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_guide_tour`
--

LOCK TABLES `sys_guide_tour` WRITE;
/*!40000 ALTER TABLE `sys_guide_tour` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_guide_tour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_guide_tour_completion`
--

DROP TABLE IF EXISTS `sys_guide_tour_completion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_guide_tour_completion` (
  `sys_guide_tour_completion_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID da xem tour',
  `sys_user_id` char(36) NOT NULL COMMENT 'Admin da xem',
  `sys_guide_tour_screen_id` varchar(50) NOT NULL COMMENT 'Man hinh da xem',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay hoan thanh/skip',
  PRIMARY KEY (`sys_guide_tour_completion_id`),
  UNIQUE KEY `uix_sysguidetourcompletion_user_screen` (`sys_user_id`,`sys_guide_tour_screen_id`),
  CONSTRAINT `fk_sysguidetourcompletion_sysuser` FOREIGN KEY (`sys_user_id`) REFERENCES `sys_user` (`sys_user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Trang thai hoan thanh Guide Tour cua tung admin user';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_guide_tour_completion`
--

LOCK TABLES `sys_guide_tour_completion` WRITE;
/*!40000 ALTER TABLE `sys_guide_tour_completion` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_guide_tour_completion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_import_job`
--

DROP TABLE IF EXISTS `sys_import_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_import_job` (
  `sys_import_job_id` char(36) COLLATE utf8mb4_0900_as_ci NOT NULL DEFAULT (uuid()),
  `sys_sync_config_id` char(36) COLLATE utf8mb4_0900_as_ci DEFAULT NULL COMMENT 'FK toi sync_config (NULL neu upload file thu cong)',
  `sys_import_job_source` varchar(20) COLLATE utf8mb4_0900_as_ci NOT NULL COMMENT 'file_upload | google_sheets | google_drive',
  `sys_import_job_target` varchar(50) COLLATE utf8mb4_0900_as_ci NOT NULL DEFAULT 'product' COMMENT 'product | inventory | customer | price',
  `sys_import_job_file_name` varchar(255) COLLATE utf8mb4_0900_as_ci DEFAULT NULL COMMENT 'Ten file goc (neu upload)',
  `sys_import_job_status` varchar(20) COLLATE utf8mb4_0900_as_ci NOT NULL DEFAULT 'pending' COMMENT 'pending | processing | completed | failed | cancelled',
  `sys_import_job_total_rows` int NOT NULL DEFAULT '0' COMMENT 'Tong so dong',
  `sys_import_job_created` int NOT NULL DEFAULT '0' COMMENT 'So dong tao moi',
  `sys_import_job_updated` int NOT NULL DEFAULT '0' COMMENT 'So dong cap nhat',
  `sys_import_job_skipped` int NOT NULL DEFAULT '0' COMMENT 'So dong bo qua',
  `sys_import_job_errors` int NOT NULL DEFAULT '0' COMMENT 'So dong loi',
  `sys_import_job_error_details` json DEFAULT NULL COMMENT 'Chi tiet loi tung dong [{row, field, message}]',
  `sys_import_job_started_at` datetime DEFAULT NULL,
  `sys_import_job_finished_at` datetime DEFAULT NULL,
  `created_by` char(36) COLLATE utf8mb4_0900_as_ci DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sys_import_job_id`),
  KEY `ix_sys_import_job_config` (`sys_sync_config_id`),
  KEY `ix_sys_import_job_status` (`sys_import_job_status`),
  KEY `ix_sys_import_job_created` (`created_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_ci COMMENT='Lich su cac lan import/sync du lieu';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_import_job`
--

LOCK TABLES `sys_import_job` WRITE;
/*!40000 ALTER TABLE `sys_import_job` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_import_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_media`
--

DROP TABLE IF EXISTS `sys_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_media` (
  `sys_media_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID media',
  `sys_media_filename` varchar(255) NOT NULL COMMENT 'Ten file goc',
  `sys_media_path` varchar(255) NOT NULL COMMENT 'Duong dan storage',
  `sys_media_type` tinyint NOT NULL DEFAULT '1' COMMENT '1: Image, 2: Video',
  `sys_media_size` int NOT NULL DEFAULT '0' COMMENT 'Kich thuoc file (bytes)',
  `sys_media_width` int DEFAULT NULL COMMENT 'Chieu rong (px)',
  `sys_media_height` int DEFAULT NULL COMMENT 'Chieu cao (px)',
  `sys_media_alt` varchar(255) DEFAULT NULL COMMENT 'Alt text',
  `sys_user_id` char(36) DEFAULT NULL COMMENT 'Nguoi upload',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sys_media_id`),
  KEY `ix_sysmedia_createddate` (`created_date`),
  KEY `ix_sysmedia_sysmediatype` (`sys_media_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Thu vien media toan he thong';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_media`
--

LOCK TABLES `sys_media` WRITE;
/*!40000 ALTER TABLE `sys_media` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_notification`
--

DROP TABLE IF EXISTS `sys_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_notification` (
  `sys_notification_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID notification',
  `sys_customer_id` char(36) DEFAULT NULL COMMENT 'KH nhan (NULL = broadcast)',
  `sys_notification_type` varchar(50) NOT NULL COMMENT 'Loai: order_status, flash_sale, abandoned_cart, loyalty, review_reminder',
  `sys_notification_title` varchar(255) NOT NULL COMMENT 'Tieu de',
  `sys_notification_body` text NOT NULL COMMENT 'Noi dung',
  `sys_notification_data` json DEFAULT NULL COMMENT 'Payload data (link, order_id, ...)',
  `sys_notification_channel` tinyint NOT NULL DEFAULT '0' COMMENT '0: Push, 1: Email, 2: Both',
  `sys_notification_status` tinyint NOT NULL DEFAULT '0' COMMENT '0: Queued, 1: Sent, 2: Failed, 3: Read',
  `sys_notification_sent_at` datetime DEFAULT NULL COMMENT 'Thoi diem gui thanh cong',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay tao',
  PRIMARY KEY (`sys_notification_id`),
  KEY `ix_sysnotification_syscustomerid` (`sys_customer_id`),
  KEY `ix_sysnotification_status` (`sys_notification_status`),
  KEY `ix_sysnotification_createddate` (`created_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Hang doi thong bao (push + email)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_notification`
--

LOCK TABLES `sys_notification` WRITE;
/*!40000 ALTER TABLE `sys_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_password_history`
--

DROP TABLE IF EXISTS `sys_password_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_password_history` (
  `sys_password_history_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID lich su mat khau',
  `sys_user_id` char(36) NOT NULL COMMENT 'Khoa ngoai User',
  `sys_password_history_hash` varchar(255) NOT NULL COMMENT 'Hash mat khau cu',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay doi mat khau',
  PRIMARY KEY (`sys_password_history_id`),
  KEY `ix_syspasswordhistory_sysuserid` (`sys_user_id`),
  CONSTRAINT `fk_syspasswordhistory_sysuser` FOREIGN KEY (`sys_user_id`) REFERENCES `sys_user` (`sys_user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Lich su mat khau (chong dung lai 5 mat khau gan nhat)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_password_history`
--

LOCK TABLES `sys_password_history` WRITE;
/*!40000 ALTER TABLE `sys_password_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_password_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_push_subscription`
--

DROP TABLE IF EXISTS `sys_push_subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_push_subscription` (
  `sys_push_subscription_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID dang ky push',
  `sys_customer_id` char(36) NOT NULL COMMENT 'Khoa ngoai KH',
  `sys_push_subscription_endpoint` varchar(500) NOT NULL COMMENT 'Push endpoint URL',
  `sys_push_subscription_keys` json NOT NULL COMMENT '{ p256dh, auth } keys',
  `sys_push_subscription_user_agent` varchar(255) DEFAULT NULL COMMENT 'Browser info',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay dang ky',
  PRIMARY KEY (`sys_push_subscription_id`),
  KEY `ix_syspushsubscription_syscustomerid` (`sys_customer_id`),
  CONSTRAINT `fk_syspushsubscription_syscustomer` FOREIGN KEY (`sys_customer_id`) REFERENCES `sys_customer` (`sys_customer_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Danh sach dang ky nhan Push Notification';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_push_subscription`
--

LOCK TABLES `sys_push_subscription` WRITE;
/*!40000 ALTER TABLE `sys_push_subscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_push_subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refresh_token`
--

DROP TABLE IF EXISTS `sys_refresh_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refresh_token` (
  `sys_refresh_token_id` char(36) NOT NULL DEFAULT (uuid()),
  `sys_user_id` char(36) NOT NULL,
  `sys_refresh_token_hash` varchar(255) NOT NULL COMMENT 'Hash cua refresh token',
  `sys_refresh_token_expires` datetime NOT NULL,
  `sys_refresh_token_revoked` tinyint NOT NULL DEFAULT '0',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sys_refresh_token_id`),
  KEY `ix_sysrefreshtoken_sysuserid` (`sys_user_id`),
  CONSTRAINT `fk_sysrefreshtoken_sysuser` FOREIGN KEY (`sys_user_id`) REFERENCES `sys_user` (`sys_user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Luu tru refresh tokens';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refresh_token`
--

LOCK TABLES `sys_refresh_token` WRITE;
/*!40000 ALTER TABLE `sys_refresh_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_refresh_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_setting`
--

DROP TABLE IF EXISTS `sys_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_setting` (
  `sys_setting_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID setting',
  `sys_setting_group` varchar(50) NOT NULL COMMENT 'Nhom: shop, shipping, payment, seo',
  `sys_setting_key` varchar(100) NOT NULL COMMENT 'Key: shop_name, shop_logo, low_stock_threshold',
  `sys_setting_value` text COMMENT 'Gia tri (JSON string)',
  `modified_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sys_setting_id`),
  UNIQUE KEY `uix_syssetting_group_key` (`sys_setting_group`,`sys_setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Cai dat he thong dang key-value';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_setting`
--

LOCK TABLES `sys_setting` WRITE;
/*!40000 ALTER TABLE `sys_setting` DISABLE KEYS */;
INSERT INTO `sys_setting` VALUES ('00822df9-a41e-11f1-b0a9-762043079894','bank_transfer','bank_name','Vietcombank','2026-08-30 02:53:38'),('008232ed-a41e-11f1-b0a9-762043079894','bank_transfer','bank_account_number','1234567890','2026-08-30 02:53:38'),('0082349e-a41e-11f1-b0a9-762043079894','bank_transfer','bank_account_name','CONG TY TNHH FASHION ECOM','2026-08-30 02:53:38'),('0082355f-a41e-11f1-b0a9-762043079894','bank_transfer','bank_branch','Ho Chi Minh','2026-08-30 02:53:38'),('008235f3-a41e-11f1-b0a9-762043079894','bank_transfer','bank_qr_image','','2026-08-30 02:53:38'),('00823681-a41e-11f1-b0a9-762043079894','bank_transfer','transfer_note_template','DH {orderCode}','2026-08-30 02:53:38'),('s0000000-0000-0000-0000-000000000001','shop','site_name','Fashion Ecom','2026-08-30 02:53:46'),('s0000000-0000-0000-0000-000000000002','shop','site_phone','0901234567','2026-08-30 02:53:46'),('s0000000-0000-0000-0000-000000000003','shipping','shipping_fee','30000','2026-08-30 02:53:46'),('s0000000-0000-0000-0000-000000000004','shipping','free_ship_threshold','500000','2026-08-30 02:53:46');
/*!40000 ALTER TABLE `sys_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_sync_config`
--

DROP TABLE IF EXISTS `sys_sync_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_sync_config` (
  `sys_sync_config_id` char(36) COLLATE utf8mb4_0900_as_ci NOT NULL DEFAULT (uuid()),
  `sys_sync_config_name` varchar(255) COLLATE utf8mb4_0900_as_ci NOT NULL COMMENT 'Ten cau hinh, VD: "Catalog chinh"',
  `sys_sync_config_type` varchar(20) COLLATE utf8mb4_0900_as_ci NOT NULL DEFAULT 'google_sheets' COMMENT 'google_sheets | google_drive | manual',
  `sys_sync_config_source_url` varchar(500) COLLATE utf8mb4_0900_as_ci DEFAULT NULL COMMENT 'URL Google Sheet hoac folder Drive',
  `sys_sync_config_sheet_id` varchar(100) COLLATE utf8mb4_0900_as_ci DEFAULT NULL COMMENT 'Google Sheet ID (trich tu URL)',
  `sys_sync_config_sheet_name` varchar(100) COLLATE utf8mb4_0900_as_ci DEFAULT 'Sheet1' COMMENT 'Ten tab sheet',
  `sys_sync_config_target` varchar(50) COLLATE utf8mb4_0900_as_ci NOT NULL DEFAULT 'product' COMMENT 'product | inventory | customer | price',
  `sys_sync_config_column_mapping` json DEFAULT NULL COMMENT 'Map cot sheet â†’ field DB, VD: {"A":"product_name","B":"sku"}',
  `sys_sync_config_auto_sync` tinyint NOT NULL DEFAULT '0' COMMENT 'Bat/tat tu dong sync',
  `sys_sync_config_interval_minutes` int NOT NULL DEFAULT '30' COMMENT 'Khoang cach giua cac lan sync (phut)',
  `sys_sync_config_last_sync_at` datetime DEFAULT NULL COMMENT 'Lan sync cuoi',
  `sys_sync_config_status` varchar(20) COLLATE utf8mb4_0900_as_ci NOT NULL DEFAULT 'active' COMMENT 'active | paused | error',
  `sys_sync_config_error_message` text COLLATE utf8mb4_0900_as_ci COMMENT 'Loi gan nhat neu co',
  `created_by` char(36) COLLATE utf8mb4_0900_as_ci DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sys_sync_config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_ci COMMENT='Cau hinh dong bo du lieu tu Google Sheets/Drive';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_sync_config`
--

LOCK TABLES `sys_sync_config` WRITE;
/*!40000 ALTER TABLE `sys_sync_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_sync_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user`
--

DROP TABLE IF EXISTS `sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user` (
  `sys_user_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toÃ n cá»¥c cá»§a User',
  `sys_user_email` varchar(100) NOT NULL COMMENT 'Email Ä‘Äƒng nháº­p há»‡ thá»‘ng',
  `sys_user_name` varchar(100) DEFAULT NULL COMMENT 'Ho ten hien thi',
  `sys_user_avatar` varchar(255) DEFAULT NULL COMMENT 'Duong dan avatar',
  `sys_user_password` varchar(255) NOT NULL COMMENT 'Máº­t kháº©u Ä‘Ã£ mÃ£ hÃ³a',
  `sys_user_role` tinyint NOT NULL DEFAULT '0' COMMENT 'Nghiá»‡p vá»¥: 0: KhÃ¡ch hÃ ng, 1: Admin, 2: Cá»­a hÃ ng trÆ°á»Ÿng, 3: CSKH',
  `sys_user_status` tinyint NOT NULL DEFAULT '1' COMMENT 'Tráº¡ng thÃ¡i: 0: KhÃ³a, 1: Hoáº¡t Ä‘á»™ng',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'NgÃ y giá» táº¡o tÃ i khoáº£n',
  `sys_user_last_login` datetime DEFAULT NULL COMMENT 'Lan dang nhap gan nhat',
  `sys_user_login_count` int NOT NULL DEFAULT '0' COMMENT 'So lan dang nhap',
  `modified_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Ngay cap nhat',
  PRIMARY KEY (`sys_user_id`),
  UNIQUE KEY `uix_sysuser_sysuseremail` (`sys_user_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Danh sÃ¡ch tÃ i khoáº£n Ä‘Äƒng nháº­p há»‡ thá»‘ng';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user`
--

LOCK TABLES `sys_user` WRITE;
/*!40000 ALTER TABLE `sys_user` DISABLE KEYS */;
INSERT INTO `sys_user` VALUES ('a0000000-0000-0000-0000-000000000001','admin@fashionecom.vn','Super Admin',NULL,'$2a$10$N9qo8uLOickgx2ZMRZoMye5/Yq8w3T8dLN8X2s7.OYzYE2n/6Kk.O',1,1,'2026-08-30 02:53:46',NULL,0,'2026-08-30 02:53:46');
/*!40000 ALTER TABLE `sys_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_wishlist`
--

DROP TABLE IF EXISTS `sys_wishlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_wishlist` (
  `sys_wishlist_id` char(36) NOT NULL DEFAULT (uuid()) COMMENT 'ID toan cuc wishlist',
  `sys_customer_id` char(36) NOT NULL COMMENT 'Khoa ngoai tro toi khach hang',
  `cat_product_id` char(36) NOT NULL COMMENT 'Khoa ngoai tro toi san pham',
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngay them vao wishlist',
  PRIMARY KEY (`sys_wishlist_id`),
  UNIQUE KEY `uix_syswishlist_customer_product` (`sys_customer_id`,`cat_product_id`),
  KEY `fk_syswishlist_catproduct` (`cat_product_id`),
  CONSTRAINT `fk_syswishlist_catproduct` FOREIGN KEY (`cat_product_id`) REFERENCES `cat_product` (`cat_product_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_syswishlist_syscustomer` FOREIGN KEY (`sys_customer_id`) REFERENCES `sys_customer` (`sys_customer_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='San pham yeu thich cua khach hang';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_wishlist`
--

LOCK TABLES `sys_wishlist` WRITE;
/*!40000 ALTER TABLE `sys_wishlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_wishlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'fashion_ecom'
--
/*!50003 DROP PROCEDURE IF EXISTS `proc_seed_product` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`fashionecom`@`%` PROCEDURE `proc_seed_product`(
    IN p_cat_code VARCHAR(20),
    IN p_code VARCHAR(20),
    IN p_name VARCHAR(255),
    IN p_slug VARCHAR(255),
    IN p_price DECIMAL(22,4),
    IN p_compare_price DECIMAL(22,4),
    IN p_image VARCHAR(255),
    IN p_image_hover VARCHAR(255),
    IN p_is_new TINYINT,
    IN p_is_bestseller TINYINT,
    IN p_brand VARCHAR(100),
    IN p_colors_csv VARCHAR(500),
    IN p_size_group VARCHAR(100)
)
BEGIN
    DECLARE v_product_id CHAR(36);
    DECLARE v_cat_id CHAR(36);
    DECLARE v_color_id CHAR(36);
    DECLARE v_color_name VARCHAR(50);
    DECLARE v_size_id CHAR(36);
    DECLARE v_size_value VARCHAR(50);
    DECLARE v_variant_sku VARCHAR(20);
    DECLARE v_done_c INT DEFAULT 0;
    DECLARE v_done_s INT DEFAULT 0;
    DECLARE v_stock_qty INT;
    DECLARE v_sort INT DEFAULT 0;

    -- Tim category
    SELECT cat_category_id INTO v_cat_id
    FROM cat_category WHERE cat_category_code = p_cat_code LIMIT 1;

    IF v_cat_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Category not found';
    END IF;

    -- Xoa product cu (neu re-run)
    DELETE FROM cat_product WHERE cat_product_code = p_code;

    -- Tao product
    SET v_product_id = UUID();
    INSERT INTO cat_product (
        cat_product_id, cat_category_id, cat_product_code, cat_product_name,
        cat_product_slug, cat_product_brand, cat_product_status,
        cat_product_is_featured, cat_product_is_new
    ) VALUES (
        v_product_id, v_cat_id, p_code, p_name,
        p_slug, p_brand, 1,
        p_is_bestseller, p_is_new
    );

    -- Insert main image
    INSERT INTO cat_product_media (cat_product_media_id, cat_product_id, cat_product_media_path, cat_product_media_type, cat_product_media_sort) VALUES
    (UUID(), v_product_id, p_image, 1, 1);

    -- Insert hover image
    IF p_image_hover IS NOT NULL AND p_image_hover != '' THEN
        INSERT INTO cat_product_media (cat_product_media_id, cat_product_id, cat_product_media_path, cat_product_media_type, cat_product_media_sort) VALUES
        (UUID(), v_product_id, p_image_hover, 1, 2);
    END IF;

    -- Tao variants: moi color x moi size trong group
    -- Parse colors CSV va loop
    BEGIN
        DECLARE v_remaining VARCHAR(500);
        DECLARE v_current VARCHAR(50);
        DECLARE v_pos INT;

        SET v_remaining = p_colors_csv;

        color_loop: WHILE LENGTH(v_remaining) > 0 DO
            SET v_pos = LOCATE(',', v_remaining);
            IF v_pos > 0 THEN
                SET v_current = TRIM(SUBSTRING(v_remaining, 1, v_pos - 1));
                SET v_remaining = SUBSTRING(v_remaining, v_pos + 1);
            ELSE
                SET v_current = TRIM(v_remaining);
                SET v_remaining = '';
            END IF;

            -- Tim color ID
            SELECT cat_color_id, cat_color_name INTO v_color_id, v_color_name
            FROM cat_color WHERE cat_color_name = v_current LIMIT 1;

            IF v_color_id IS NOT NULL THEN
                -- Loop qua sizes trong group
                BEGIN
                    DECLARE cur_sizes CURSOR FOR
                        SELECT cs.cat_size_id, cs.cat_size_value
                        FROM cat_size cs
                        JOIN cat_size_group sg ON cs.cat_size_group_id = sg.cat_size_group_id
                        WHERE sg.cat_size_group_name = p_size_group
                        ORDER BY cs.cat_size_sort;
                    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done_s = 1;

                    SET v_done_s = 0;
                    OPEN cur_sizes;

                    size_loop: LOOP
                        FETCH cur_sizes INTO v_size_id, v_size_value;
                        IF v_done_s THEN LEAVE size_loop; END IF;

                        SET v_sort = v_sort + 1;
                        SET v_variant_sku = CONCAT(p_code, '-', LEFT(REPLACE(v_color_name, ' ', ''), 3), '-', v_size_value);
                        SET v_stock_qty = FLOOR(5 + RAND() * 20);

                        INSERT INTO cat_product_variant (
                            cat_product_variant_id, cat_product_id,
                            cat_product_variant_sku, cat_product_variant_color, cat_product_variant_size,
                            cat_product_variant_price, cat_product_variant_compare_price,
                            cat_product_variant_status
                        ) VALUES (
                            UUID(), v_product_id,
                            v_variant_sku, v_color_name, v_size_value,
                            p_price, p_compare_price,
                            1
                        );
                    END LOOP size_loop;
                    CLOSE cur_sizes;
                END;
            END IF;

            SET v_color_id = NULL;
        END WHILE color_loop;
    END;

    -- Insert inventory cho moi variant
    INSERT INTO inv_inventory (inv_inventory_id, cat_product_variant_id, inv_inventory_qty)
    SELECT UUID(), cpv.cat_product_variant_id, FLOOR(5 + RAND() * 20)
    FROM cat_product_variant cpv
    WHERE cpv.cat_product_id = v_product_id
      AND NOT EXISTS (
          SELECT 1 FROM inv_inventory ii
          WHERE ii.cat_product_variant_id = cpv.cat_product_variant_id
      );
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-03 21:40:18
